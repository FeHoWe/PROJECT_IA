# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                       MECATRACK  v3.0                                        ║
# ║           Sistema de LOCALIZAÇÃO FÍSICA de Autopeças                          ║
# ║  Objetivo principal: encontrar instantaneamente ONDE a peça está no galpão   ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
#
#  HIERARQUIA DE LOCALIZAÇÃO:
#     Prateleira  →  Setor  →  Posição/Caixa
#     Ex: "Prateleira 1 · Setor A · Caixa 03"   →  código: P1-A-03
#
#  FLUXO PRINCIPAL:
#     1. Funcionário digita qualquer coisa (nome, carro, código, marca...)
#     2. Sistema mostra PRIMEIRO e GRANDE onde a peça está
#     3. Funcionário vai buscar
#
#  pip install customtkinter python-barcode Pillow matplotlib openpyxl reportlab

import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk, filedialog
import customtkinter as ctk
import os, sys, io, shutil, datetime, hashlib, csv, threading, re
from typing import Optional, List, Tuple, Dict

APP_NAME    = "Mecatrack"
APP_VERSION = "v3.0"
APP_TITLE   = f"{APP_NAME}  ·  Localizador de Autopeças  {APP_VERSION}"
DB_FILE     = "mecatrack_estoque.db"
BACKUP_DIR  = "mecatrack_backups"
LOG_FILE    = "mecatrack_auditoria.log"

# ── Deps opcionais ─────────────────────────────────────────────────────────────
def _checar_deps():
    m = []
    for mod, pkg in [("barcode","python-barcode"),("PIL","Pillow"),
                     ("matplotlib","matplotlib"),("openpyxl","openpyxl"),
                     ("reportlab","reportlab")]:
        try: __import__(mod)
        except ImportError: m.append(pkg)
    return m

DEPS_FALTANDO = _checar_deps()

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Força tema escuro no Windows (evita herdar tema claro do sistema)
try:
    import darkdetect  # noqa — só tenta, não obrigatório
except ImportError:
    pass

# ── Paleta ─────────────────────────────────────────────────────────────────────
BG    = "#0f1117"
CARD  = "#1a1d27"
CARD2 = "#22263a"
ACC   = "#3b82f6"
ACC2  = "#6366f1"
OK    = "#22c55e"
WARN  = "#f59e0b"
ERR   = "#ef4444"
TXT   = "#e2e8f0"
MUTED = "#64748b"
BRD   = "#2d3148"

# ── Localização: cor por prateleira ────────────────────────────────────────────
CORES_PRAT = ["#3b82f6","#22c55e","#f59e0b","#ef4444","#8b5cf6",
               "#06b6d4","#ec4899","#f97316","#84cc16","#64748b"]

# ══════════════════════════════════════════════════════════════════════════════
#  UTILITÁRIOS
# ══════════════════════════════════════════════════════════════════════════════
def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def agora():   return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def hoje():    return datetime.date.today().isoformat()

def fmt_brl(v):
    try:
        return f"R$ {float(v):,.2f}".replace(",","X").replace(".",",").replace("X",".")
    except: return "R$ 0,00"

def parse_float(s):
    try: return float(str(s).strip().replace("R$","").replace(" ","").replace(".","").replace(",","."))
    except: return 0.0

def parse_int(s):
    try: return int(str(s).strip())
    except: return 0

def auditar(usuario, acao, detalhe=""):
    try:
        with open(LOG_FILE,"a",encoding="utf-8") as f:
            f.write(f"{agora()} | {usuario:12s} | {acao:30s} | {detalhe}\n")
    except: pass

def _cor_prateleira(nome_local: str) -> str:
    """Retorna cor baseada no número/nome da prateleira."""
    match = re.search(r'\d+', str(nome_local))
    if match:
        idx = (int(match.group()) - 1) % len(CORES_PRAT)
        return CORES_PRAT[idx]
    h = abs(hash(str(nome_local))) % len(CORES_PRAT)
    return CORES_PRAT[h]

def _hex_claro(hex_cor: str, fator: float = 0.15) -> str:
    """
    Mistura a cor hex com o fundo escuro (CARD=#1a1d27) para simular transparência.
    Retorna cor sólida válida para tkinter — sem sufixo de opacidade.
    fator: 0.0 = fundo puro, 1.0 = cor pura
    """
    try:
        h = hex_cor.lstrip("#")
        r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
        # Mistura com CARD (#1a1d27 = 26,29,39)
        br, bg, bb = 26, 29, 39
        nr = int(br + (r - br) * fator)
        ng = int(bg + (g - bg) * fator)
        nb = int(bb + (b - bb) * fator)
        return f"#{nr:02x}{ng:02x}{nb:02x}"
    except Exception:
        return CARD

def _formatar_local(local: str) -> str:
    """Torna a localização mais legível: 'p1-a-03' → 'Prat 1 · Set A · Cx 03'"""
    if not local: return "—"
    # Aceita P1-A-03, Prat1-A-05, Prateleira1-B-07
    m = re.match(r'^[Pp][a-zA-Z]*(\d+)[-\s]([A-Za-z]+)[-\s](\w+)$', local.strip())
    if m:
        return f"Prat {m.group(1)} · Set {m.group(2).upper()} · Cx {m.group(3)}"
    return local


# ══════════════════════════════════════════════════════════════════════════════
#  BANCO DE DADOS
# ══════════════════════════════════════════════════════════════════════════════
class Database:
    def __init__(self, path=DB_FILE):
        self.path = path
        self._local = threading.local()
        self._main = self._new_conn()
        self._criar_tabelas_base()
        self._migrar()
        self._criar_indices()

    def _new_conn(self):
        c = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=5000")
        c.row_factory = sqlite3.Row
        return c

    @property
    def conn(self):
        if not hasattr(self._local,"c") or not self._local.c:
            self._local.c = self._new_conn()
        return self._local.c

    def _criar_tabelas_base(self):
        """Cria as tabelas SEM índices — índices são criados depois da migração."""
        self._main.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            login   TEXT UNIQUE NOT NULL,
            senha   TEXT NOT NULL,
            perfil  TEXT DEFAULT 'operador',
            ativo   INTEGER DEFAULT 1,
            criado  TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS pecas (
            codigo          TEXT PRIMARY KEY,
            nome            TEXT NOT NULL,
            localizacao     TEXT DEFAULT '',
            prateleira      TEXT DEFAULT '',
            setor           TEXT DEFAULT '',
            posicao         TEXT DEFAULT '',
            quantidade      INTEGER DEFAULT 0,
            qtd_minima      INTEGER DEFAULT 2,
            preco_venda     REAL DEFAULT 0.0,
            preco_custo     REAL DEFAULT 0.0,
            fornecedor      TEXT DEFAULT '',
            marca           TEXT DEFAULT '',
            cod_fabricante  TEXT DEFAULT '',
            observacoes     TEXT DEFAULT '',
            atualizado      TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS aplicacoes (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo  TEXT NOT NULL REFERENCES pecas(codigo) ON DELETE CASCADE,
            veiculo TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS movimentacoes (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo     TEXT NOT NULL,
            tipo       TEXT NOT NULL,
            quantidade INTEGER NOT NULL,
            motivo     TEXT DEFAULT '',
            usuario    TEXT DEFAULT '',
            data_hora  TEXT NOT NULL
        );
        """)
        self._main.execute(
            "INSERT OR IGNORE INTO usuarios(login,senha,perfil) VALUES(?,?,?)",
            ("admin", sha256("admin123"), "admin"))
        self._main.commit()

    def _criar_indices(self):
        """Cria índices depois da migração (colunas já existem com certeza)."""
        indices = [
            "CREATE INDEX IF NOT EXISTS idx_pecas_local  ON pecas(localizacao)",
            "CREATE INDEX IF NOT EXISTS idx_pecas_prat   ON pecas(prateleira)",
            "CREATE INDEX IF NOT EXISTS idx_pecas_nome   ON pecas(nome)",
            "CREATE INDEX IF NOT EXISTS idx_mov_codigo   ON movimentacoes(codigo)",
        ]
        for sql in indices:
            try:
                self._main.execute(sql)
            except sqlite3.OperationalError:
                pass
        self._main.commit()

    def _migrar(self):
        """Adiciona colunas novas sem perder dados e popula localização."""
        cols = [
            ("pecas",    "prateleira",      "TEXT DEFAULT ''"),
            ("pecas",    "setor",           "TEXT DEFAULT ''"),
            ("pecas",    "posicao",         "TEXT DEFAULT ''"),
            ("pecas",    "observacoes",     "TEXT DEFAULT ''"),
            ("pecas",    "atualizado",      "TEXT DEFAULT CURRENT_TIMESTAMP"),
            ("pecas",    "cod_fabricante",  "TEXT DEFAULT ''"),
            ("pecas",    "preco_venda",     "REAL DEFAULT 0.0"),
            ("pecas",    "preco_custo",     "REAL DEFAULT 0.0"),
            ("pecas",    "fornecedor",      "TEXT DEFAULT ''"),
            ("pecas",    "marca",           "TEXT DEFAULT ''"),
            ("pecas",    "qtd_minima",      "INTEGER DEFAULT 2"),
            ("pecas",    "localizacao",     "TEXT DEFAULT ''"),
            ("usuarios", "ativo",           "INTEGER DEFAULT 1"),
            ("usuarios", "criado",          "TEXT DEFAULT CURRENT_TIMESTAMP"),
        ]
        for tab, col, dfn in cols:
            try:
                self._main.execute(f"ALTER TABLE {tab} ADD COLUMN {col} {dfn}")
            except sqlite3.OperationalError:
                pass

        # Se o banco antigo tinha coluna 'preco', copia para 'preco_venda'
        try:
            cols_existentes = [r[1] for r in self._main.execute("PRAGMA table_info(pecas)").fetchall()]
            if "preco" in cols_existentes and "preco_venda" in cols_existentes:
                self._main.execute("UPDATE pecas SET preco_venda=preco WHERE preco_venda=0.0 AND preco!=0.0")
        except Exception:
            pass

        # Se o banco antigo tinha coluna 'aplicacao' (singular), copia para aplicacoes
        try:
            cols_existentes = [r[1] for r in self._main.execute("PRAGMA table_info(pecas)").fetchall()]
            if "aplicacao" in cols_existentes:
                rows_aplic = self._main.execute(
                    "SELECT codigo, aplicacao FROM pecas WHERE aplicacao IS NOT NULL AND aplicacao!=''"
                ).fetchall()
                for cod, aplic in rows_aplic:
                    existe = self._main.execute(
                        "SELECT id FROM aplicacoes WHERE codigo=?", (cod,)
                    ).fetchone()
                    if not existe and aplic:
                        self._main.execute(
                            "INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)", (cod, aplic)
                        )
        except Exception:
            pass

        # Migra banco antigo: se localizacao existe mas prateleira está vazia,
        # tenta extrair prateleira/setor/posicao do campo localizacao existente
        try:
            rows = self._main.execute(
                "SELECT codigo, localizacao FROM pecas WHERE prateleira='' AND localizacao!=''"
            ).fetchall()
            import re as _re
            for row in rows:
                cod, local = row[0], row[1]
                m = _re.match(r'^[Pp][a-zA-Z]*(\d+)[-\s]([A-Za-z]+)[-\s](\w+)$', local.strip())
                if m:
                    prat  = f"Prateleira {m.group(1)}"
                    setor = m.group(2).upper()
                    pos   = m.group(3).zfill(2)
                    self._main.execute(
                        "UPDATE pecas SET prateleira=?, setor=?, posicao=? WHERE codigo=?",
                        (prat, setor, pos, cod))
                else:
                    # Localização livre: coloca tudo em prateleira
                    self._main.execute(
                        "UPDATE pecas SET prateleira=? WHERE codigo=?",
                        (local, cod))
        except Exception:
            pass

        self._main.commit()

    def q(self, sql, params=()):
        return self._main.execute(sql, params)

    def commit(self): self._main.commit()

    def close(self): self._main.close()

    def buscar_pecas(self, termo="", filtro_local="", filtro_alerta=""):
        """Query principal do localizador."""
        conds, params = [], {}
        if termo:
            conds.append("""(p.nome LIKE :t OR p.codigo LIKE :t OR p.localizacao LIKE :t
                          OR p.prateleira LIKE :t OR p.setor LIKE :t
                          OR p.marca LIKE :t OR p.fornecedor LIKE :t
                          OR p.cod_fabricante LIKE :t OR a.veiculo LIKE :t)""")
            params["t"] = f"%{termo}%"
        if filtro_local:
            conds.append("(p.prateleira LIKE :fl OR p.localizacao LIKE :fl)")
            params["fl"] = f"%{filtro_local}%"
        if filtro_alerta == "zerados":
            conds.append("p.quantidade = 0")
        elif filtro_alerta == "baixo":
            conds.append("p.quantidade > 0 AND p.quantidade <= p.qtd_minima")
        elif filtro_alerta == "ok":
            conds.append("p.quantidade > p.qtd_minima")

        where = "WHERE " + " AND ".join(conds) if conds else ""
        return self._main.execute(f"""
            SELECT p.codigo, p.nome, p.localizacao, p.prateleira, p.setor, p.posicao,
                   p.quantidade, p.qtd_minima, p.preco_venda, p.marca,
                   GROUP_CONCAT(DISTINCT a.veiculo) AS aplic,
                   p.fornecedor, p.preco_custo
            FROM pecas p
            LEFT JOIN aplicacoes a ON a.codigo = p.codigo
            {where}
            GROUP BY p.codigo
            ORDER BY p.prateleira, p.setor, p.posicao, p.nome
        """, params).fetchall()

    def prateleiras(self):
        """Lista prateleiras únicas para o painel lateral."""
        return self._main.execute("""
            SELECT prateleira, COUNT(*) as total,
                   SUM(CASE WHEN quantidade=0 THEN 1 ELSE 0 END) as zerados,
                   SUM(CASE WHEN quantidade>0 AND quantidade<=qtd_minima THEN 1 ELSE 0 END) as baixos
            FROM pecas WHERE prateleira != ''
            GROUP BY prateleira ORDER BY prateleira
        """).fetchall()

    def estatisticas(self):
        r = self._main.execute(
            "SELECT COUNT(*),SUM(quantidade),SUM(preco_custo*quantidade),SUM(preco_venda*quantidade) FROM pecas"
        ).fetchone()
        z = self._main.execute("SELECT COUNT(*) FROM pecas WHERE quantidade=0").fetchone()[0]
        b = self._main.execute("SELECT COUNT(*) FROM pecas WHERE quantidade>0 AND quantidade<=qtd_minima").fetchone()[0]
        return {
            "itens": r[0] or 0, "unidades": r[1] or 0,
            "custo": r[2] or 0.0, "venda": r[3] or 0.0,
            "zerados": z, "baixos": b
        }


# ══════════════════════════════════════════════════════════════════════════════
#  TELA DE LOGIN
# ══════════════════════════════════════════════════════════════════════════════
class TelaLogin(ctk.CTkToplevel):
    def __init__(self, db, callback):
        super().__init__()
        self.db, self.callback = db, callback
        self.title(f"{APP_NAME} — Login")
        self.geometry("380x300")
        self.resizable(False, False)
        self.grab_set()
        self.configure(fg_color=BG)
        self._tentativas = 0

        ctk.CTkLabel(self, text="⚙", font=ctk.CTkFont(size=44)).pack(pady=(28,2))
        ctk.CTkLabel(self, text="MECATRACK",
                     font=ctk.CTkFont(size=22, weight="bold"),
                     text_color=ACC).pack()
        ctk.CTkLabel(self, text="Localizador de Autopeças",
                     text_color=MUTED, font=ctk.CTkFont(size=11)).pack(pady=(0,18))

        self._ent_login = ctk.CTkEntry(self, placeholder_text="Usuário",
                                       width=280, height=40)
        self._ent_login.pack(pady=4)
        self._ent_senha = ctk.CTkEntry(self, placeholder_text="Senha",
                                       show="*", width=280, height=40)
        self._ent_senha.pack(pady=4)
        self._ent_senha.bind("<Return>", lambda _: self._entrar())

        self._lbl_erro = ctk.CTkLabel(self, text="",
                                      text_color=ERR, font=ctk.CTkFont(size=11))
        self._lbl_erro.pack(pady=2)

        ctk.CTkButton(self, text="Entrar →", width=280, height=42,
                      font=ctk.CTkFont(size=14, weight="bold"),
                      fg_color=ACC, command=self._entrar).pack(pady=6)
        ctk.CTkLabel(self, text="Padrão: admin / admin123",
                     text_color=MUTED, font=ctk.CTkFont(size=10)).pack()

    def _entrar(self):
        if self._tentativas >= 5:
            self._lbl_erro.configure(text="Muitas tentativas. Reinicie."); return
        login = self._ent_login.get().strip()
        row = self.db.q(
            "SELECT perfil FROM usuarios WHERE login=? AND senha=? AND ativo=1",
            (login, sha256(self._ent_senha.get()))
        ).fetchone()
        if row:
            self.destroy(); self.callback(login, row[0])
        else:
            self._tentativas += 1
            self._lbl_erro.configure(text=f"Credenciais inválidas. ({self._tentativas}/5)")


# ══════════════════════════════════════════════════════════════════════════════
#  CARD DE RESULTADO — LOCALIZAÇÃO EM DESTAQUE
#  Este é o coração visual do sistema: cada peça exibe ONDE está em destaque
# ══════════════════════════════════════════════════════════════════════════════
class CardPeca(ctk.CTkFrame):
    """
    Card visual de uma peça com localização física em destaque.
    Clique seleciona a peça no painel de edição.
    """
    def __init__(self, master, dados: dict, on_click, **kw):
        super().__init__(master, corner_radius=10,
                         fg_color=CARD, border_width=1,
                         border_color=BRD, **kw)
        self._dados = dados
        self._on_click = on_click
        self._build()
        self.bind("<Button-1>", self._clique)

    def _build(self):
        d = self._dados
        local_raw  = d.get("localizacao","") or ""
        prateleira = d.get("prateleira","") or ""
        setor      = d.get("setor","") or ""
        posicao    = d.get("posicao","") or ""
        qty        = d.get("quantidade", 0)
        min_qty    = d.get("qtd_minima", 2)
        cor_local  = _cor_prateleira(prateleira or local_raw)

        # ── Stripe colorida da prateleira (à esquerda) ──────────────────────
        stripe = ctk.CTkFrame(self, width=6, corner_radius=0,
                               fg_color=cor_local)
        stripe.pack(side="left", fill="y", padx=(0,0))
        stripe.bind("<Button-1>", self._clique)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        body.bind("<Button-1>", self._clique)

        # ── LINHA 1: Localização física em DESTAQUE ──────────────────────────
        loc_frame = ctk.CTkFrame(body, fg_color=_hex_claro(cor_local, 0.18),
                                  corner_radius=6)
        loc_frame.pack(fill="x", pady=(0,5))
        loc_frame.bind("<Button-1>", self._clique)

        # Monta texto da localização
        partes = []
        if prateleira: partes.append(prateleira)
        if setor:      partes.append(f"Setor {setor}")
        if posicao:    partes.append(f"Cx {posicao}")
        if not partes and local_raw:
            partes = [_formatar_local(local_raw)]
        loc_txt = "  ·  ".join(partes) if partes else "Localização não definida"

        loc_label = ctk.CTkLabel(loc_frame,
                                  text=f"📍  {loc_txt}",
                                  font=ctk.CTkFont(size=14, weight="bold"),
                                  text_color=cor_local,
                                  anchor="w")
        loc_label.pack(padx=10, pady=6, anchor="w")
        loc_label.bind("<Button-1>", self._clique)

        # ── LINHA 2: Nome da peça ────────────────────────────────────────────
        nome_lbl = ctk.CTkLabel(body,
                                 text=d.get("nome",""),
                                 font=ctk.CTkFont(size=13, weight="bold"),
                                 text_color=TXT, anchor="w",
                                 wraplength=340)
        nome_lbl.pack(fill="x")
        nome_lbl.bind("<Button-1>", self._clique)

        # ── LINHA 3: Aplicações (veículos) ───────────────────────────────────
        aplic = d.get("aplic","") or ""
        if aplic:
            aplic_lbl = ctk.CTkLabel(body,
                                      text=f"🚗  {aplic[:80]}{'…' if len(aplic)>80 else ''}",
                                      font=ctk.CTkFont(size=11),
                                      text_color=MUTED, anchor="w",
                                      wraplength=340)
            aplic_lbl.pack(fill="x")
            aplic_lbl.bind("<Button-1>", self._clique)

        # ── LINHA 4: Código + Marca + Qtd ────────────────────────────────────
        rodape = ctk.CTkFrame(body, fg_color="transparent")
        rodape.pack(fill="x", pady=(5,0))
        rodape.bind("<Button-1>", self._clique)

        ctk.CTkLabel(rodape,
                     text=f"#{d.get('codigo','')}",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(side="left")

        marca = d.get("marca","")
        if marca:
            ctk.CTkLabel(rodape, text=f"  {marca}",
                         font=ctk.CTkFont(size=10),
                         text_color=MUTED).pack(side="left")

        # Estoque com cor
        if qty == 0:
            qtd_cor, qtd_txt, qtd_bg = ERR, f"⛔ Zerado",    _hex_claro(ERR, 0.20)
        elif qty <= min_qty:
            qtd_cor, qtd_txt, qtd_bg = WARN, f"⚠ {qty} un.", _hex_claro(WARN, 0.20)
        else:
            qtd_cor, qtd_txt, qtd_bg = OK, f"✓ {qty} un.", _hex_claro(OK, 0.20)

        badge = ctk.CTkFrame(rodape, fg_color=qtd_bg, corner_radius=6)
        badge.pack(side="right")
        ctk.CTkLabel(badge, text=qtd_txt,
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=qtd_cor).pack(padx=8, pady=2)

        # Preço se disponível
        preco = d.get("preco_venda", 0)
        if preco:
            ctk.CTkLabel(rodape,
                         text=fmt_brl(preco),
                         font=ctk.CTkFont(size=11),
                         text_color=MUTED).pack(side="right", padx=8)

    def _clique(self, event=None):
        self._on_click(self._dados)

    def destacar(self, ativo=True):
        self.configure(border_color=ACC if ativo else BRD,
                       border_width=2 if ativo else 1)


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA RÁPIDA DE LOCALIZAÇÃO (popup ao clicar duas vezes)
# ══════════════════════════════════════════════════════════════════════════════
class PopupLocalizacao(ctk.CTkToplevel):
    """
    Mostra a localização da peça em tela cheia / grande para o funcionário
    visualizar onde ir buscar.
    """
    def __init__(self, parent, dados: dict):
        super().__init__(parent)
        self.configure(fg_color=BG)
        self.title(f"Localização — {dados.get('nome','')}")
        self.geometry("560x440")
        self.resizable(False, False)
        self.grab_set()

        d      = dados
        cor    = _cor_prateleira(d.get("prateleira","") or d.get("localizacao",""))
        pratel = d.get("prateleira","") or ""
        setor  = d.get("setor","") or ""
        posic  = d.get("posicao","") or ""
        local  = d.get("localizacao","") or ""

        partes = []
        if pratel: partes.append(pratel)
        if setor:  partes.append(f"Setor {setor}")
        if posic:  partes.append(f"Caixa {posic}")
        if not partes and local: partes = [local]

        # Header colorido com localização
        header = ctk.CTkFrame(self, fg_color=cor, corner_radius=0, height=160)
        header.pack(fill="x"); header.pack_propagate(False)

        ctk.CTkLabel(header, text="📍",
                     font=ctk.CTkFont(size=40)).pack(pady=(20,0))
        ctk.CTkLabel(header,
                     text="  ·  ".join(partes) or local or "Sem localização",
                     font=ctk.CTkFont(size=28, weight="bold"),
                     text_color="white").pack(pady=4)

        # Corpo
        ctk.CTkLabel(self,
                     text=d.get("nome",""),
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=TXT,
                     wraplength=500).pack(pady=(20,6), padx=20)

        # Código e marca
        info_row = ctk.CTkFrame(self, fg_color=CARD2, corner_radius=8)
        info_row.pack(padx=20, fill="x", pady=4)
        for label, val in [
            ("Código:", d.get("codigo","")),
            ("Marca:",  d.get("marca","") or "—"),
            ("Qtd:",    f"{d.get('quantidade',0)} un."),
        ]:
            col = ctk.CTkFrame(info_row, fg_color="transparent")
            col.pack(side="left", expand=True, pady=10, padx=10)
            ctk.CTkLabel(col, text=label, font=ctk.CTkFont(size=10),
                         text_color=MUTED).pack()
            ctk.CTkLabel(col, text=str(val),
                         font=ctk.CTkFont(size=14, weight="bold"),
                         text_color=TXT).pack()

        # Aplicações
        aplic = d.get("aplic","") or ""
        if aplic:
            aplic_frame = ctk.CTkFrame(self, fg_color=CARD, corner_radius=8,
                                        border_width=1, border_color=BRD)
            aplic_frame.pack(padx=20, fill="x", pady=8)
            ctk.CTkLabel(aplic_frame, text="🚗  Aplica em:",
                         font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=MUTED).pack(anchor="w", padx=12, pady=(8,2))
            ctk.CTkLabel(aplic_frame,
                         text=aplic.replace(",", "  /  ")[:200],
                         font=ctk.CTkFont(size=12),
                         text_color=TXT,
                         wraplength=480).pack(anchor="w", padx=12, pady=(0,8))

        ctk.CTkButton(self, text="✓  Fechar",
                      command=self.destroy,
                      fg_color=cor, hover_color=cor,
                      height=42,
                      font=ctk.CTkFont(size=14, weight="bold")).pack(pady=16, padx=20, fill="x")


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA DE MOVIMENTAÇÃO
# ══════════════════════════════════════════════════════════════════════════════
class JanelaMov(ctk.CTkToplevel):
    def __init__(self, parent, db, dados, callback):
        super().__init__(parent)
        self.db, self.dados, self.callback = db, dados, callback
        nome = dados.get("nome",""); cod = dados.get("codigo","")
        qty  = dados.get("quantidade",0)
        self.title(f"Movimentação — {nome}")
        self.geometry("440x370")
        self.resizable(False, False)
        self.grab_set()
        self.configure(fg_color=BG)

        ctk.CTkLabel(self, text=f"⚙  {nome}",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TXT).pack(pady=(18,2))
        ctk.CTkLabel(self, text=f"Estoque atual: {qty} un.",
                     text_color=MUTED).pack()

        self.tipo_var = tk.StringVar(value="entrada")
        r = ctk.CTkFrame(self, fg_color="transparent"); r.pack(pady=12)
        for txt, val, cor in [("➕ Entrada","entrada",OK),
                               ("➖ Saída","saida",ERR),
                               ("✏️ Ajuste","ajuste",WARN)]:
            ctk.CTkRadioButton(r,text=txt,variable=self.tipo_var,
                               value=val,text_color=cor).pack(side="left",padx=8)

        ctk.CTkLabel(self, text="Quantidade:", text_color=MUTED).pack()
        self._qty = ctk.CTkEntry(self, placeholder_text="Ex: 5",
                                  width=200, height=38)
        self._qty.pack(pady=4); self._qty.focus()

        ctk.CTkLabel(self, text="Motivo (opcional):", text_color=MUTED).pack()
        self._mot = ctk.CTkEntry(self, placeholder_text="NF 1234 / Venda / Quebra",
                                  width=340, height=38)
        self._mot.pack(pady=4)

        ctk.CTkButton(self, text="✔  Confirmar", command=self._confirmar,
                      fg_color=ACC, height=42, width=320,
                      font=ctk.CTkFont(size=13, weight="bold")).pack(pady=16)

    def _confirmar(self):
        try:
            qty = int(self._qty.get().strip())
            if qty <= 0: raise ValueError
        except ValueError:
            messagebox.showwarning("Inválido","Quantidade inteira positiva.",parent=self); return

        cod    = self.dados.get("codigo","")
        tipo   = self.tipo_var.get()
        q_atual= self.dados.get("quantidade",0)
        motivo = self._mot.get().strip()

        if tipo == "entrada":  nova = q_atual + qty
        elif tipo == "saida":
            nova = q_atual - qty
            if nova < 0:
                messagebox.showwarning("Estoque insuficiente",
                    f"Atual: {q_atual}. Não é possível remover {qty}.",parent=self); return
        else: nova = qty

        self.db.q("UPDATE pecas SET quantidade=?, atualizado=? WHERE codigo=?",
                  (nova, agora(), cod))
        self.db.q("INSERT INTO movimentacoes(codigo,tipo,quantidade,motivo,usuario,data_hora)"
                  " VALUES(?,?,?,?,?,?)",
                  (cod, tipo, qty, motivo, "sistema", agora()))
        self.db.commit()
        self.destroy(); self.callback()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL DE PRATELEIRAS (sidebar esquerda)
# ══════════════════════════════════════════════════════════════════════════════
class PainelPrateleiras(ctk.CTkScrollableFrame):
    """
    Lista as prateleiras cadastradas. Clicar filtra a busca para aquela prateleira.
    """
    def __init__(self, master, db, on_filtro, **kw):
        super().__init__(master, width=180, fg_color=CARD,
                          bg_color=CARD, corner_radius=0, **kw)
        self.configure(fg_color=CARD)
        self.db = db
        self.on_filtro = on_filtro
        self._ativa = None
        self._botoes = {}
        self.atualizar()

    def atualizar(self):
        for w in self.winfo_children(): w.destroy()
        self._botoes.clear()

        ctk.CTkLabel(self, text="PRATELEIRAS",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(pady=(14,6), padx=10, anchor="w")

        # Botão "Todas"
        btn_todas = ctk.CTkButton(self, text="📦  Todas",
                                   command=lambda: self._selecionar(""),
                                   fg_color=CARD2, hover_color=BRD,
                                   anchor="w", height=34,
                                   font=ctk.CTkFont(size=12))
        btn_todas.pack(fill="x", padx=6, pady=2)
        self._botoes[""] = btn_todas

        rows = self.db.prateleiras()
        for r in rows:
            nome    = r[0] or ""
            total   = r[1] or 0
            zerados = r[2] or 0
            baixos  = r[3] or 0
            cor     = _cor_prateleira(nome)

            alerta = ""
            if zerados: alerta = f" 🔴{zerados}"
            elif baixos: alerta = f" 🟡{baixos}"

            btn = ctk.CTkButton(
                self,
                text=f"{nome}{alerta}\n{total} iten{'s' if total!=1 else ''}",
                command=lambda n=nome: self._selecionar(n),
                fg_color=CARD2, hover_color=_hex_claro(cor, 0.25),
                text_color=TXT,
                anchor="w", height=44,
                border_width=2, border_color=cor,
                font=ctk.CTkFont(size=11)
            )
            btn.pack(fill="x", padx=6, pady=2)
            self._botoes[nome] = btn

        if not rows:
            ctk.CTkLabel(self, text="Nenhuma prateleira\ncadastrada ainda.",
                         font=ctk.CTkFont(size=11), text_color=MUTED,
                         justify="left").pack(padx=10, pady=20)

    def _selecionar(self, nome):
        self._ativa = nome
        for k, b in self._botoes.items():
            cor = _cor_prateleira(k) if k else ACC
            b.configure(fg_color=(_hex_claro(cor, 0.45) if k==nome else CARD2))
        self.on_filtro(nome)


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL CENTRAL — LOCALIZADOR (exibe os cards de resultado)
# ══════════════════════════════════════════════════════════════════════════════
class PainelLocalizador(ctk.CTkFrame):
    def __init__(self, master, db, on_selecionar, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db              = db
        self._on_selecionar  = on_selecionar
        self._status         = status_cb
        self._filtro_prat    = ""
        self._filtro_alerta  = "todos"
        self._cards: Dict[str, CardPeca] = {}
        self._selecionado    = None
        self._build()

    def _build(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ── Barra de busca ───────────────────────────────────────────────────
        barra = ctk.CTkFrame(self, fg_color=CARD, corner_radius=0, height=60)
        barra.grid(row=0, column=0, sticky="ew")
        barra.grid_columnconfigure(0, weight=1)
        barra.grid_propagate(False)

        lupa = ctk.CTkLabel(barra, text="🔍",
                             font=ctk.CTkFont(size=18))
        lupa.grid(row=0, column=0, padx=(14,0), pady=12, sticky="w")

        self._txt_busca = ctk.CTkEntry(
            barra,
            placeholder_text="Digite nome da peça, código, carro (ex: Gol), marca…",
            height=38, font=ctk.CTkFont(size=15),
            fg_color=CARD2, border_color=BRD
        )
        self._txt_busca.grid(row=0, column=0, padx=(44,6), pady=12, sticky="ew")
        self._txt_busca.bind("<KeyRelease>", self._buscar)
        self._txt_busca.bind("<Return>", self._buscar)

        self._filtro_var = tk.StringVar(value="todos")
        ctk.CTkOptionMenu(
            barra, variable=self._filtro_var,
            values=["todos", "zerados", "baixo", "ok"],
            width=120, height=38,
            command=lambda _: self._buscar()
        ).grid(row=0, column=1, padx=(0,6), pady=12)

        ctk.CTkButton(barra, text="✕", width=38, height=38,
                      fg_color=CARD2, border_color=BRD,
                      command=self._limpar).grid(row=0, column=2, padx=(0,14), pady=12)

        # ── Área de resultados (scrollável) ──────────────────────────────────
        self._scroll = ctk.CTkScrollableFrame(self, fg_color=BG, corner_radius=0)
        self._scroll.grid(row=1, column=0, sticky="nsew")
        self._scroll.grid_columnconfigure(0, weight=1)

        # ── Rodapé de contagem ────────────────────────────────────────────────
        self._lbl_count = ctk.CTkLabel(self, text="",
                                        font=ctk.CTkFont(size=11),
                                        text_color=MUTED)
        self._lbl_count.grid(row=2, column=0, padx=14, pady=4, sticky="w")

        self._txt_busca.focus()
        self.atualizar()

    def set_filtro_prateleira(self, nome: str):
        self._filtro_prat = nome
        self._buscar()

    def _buscar(self, event=None):
        termo   = self._txt_busca.get().strip()
        alerta  = self._filtro_var.get()
        rows    = self.db.buscar_pecas(
            termo=termo,
            filtro_local=self._filtro_prat,
            filtro_alerta=alerta if alerta != "todos" else ""
        )
        self._renderizar(rows)

    def _limpar(self):
        self._txt_busca.delete(0, tk.END)
        self._filtro_prat = ""
        self._filtro_var.set("todos")
        self._buscar()

    def _renderizar(self, rows):
        # Limpa cards antigos
        for w in self._scroll.winfo_children(): w.destroy()
        self._cards.clear()

        if not rows:
            ctk.CTkLabel(
                self._scroll,
                text="Nenhuma peça encontrada.\n\nTente outro termo ou cadastre a peça.",
                font=ctk.CTkFont(size=14), text_color=MUTED,
                justify="center"
            ).pack(pady=60)
            self._lbl_count.configure(text="0 peças")
            return

        alertas = 0
        for r in rows:
            dados = {
                "codigo":       r[0], "nome":         r[1],
                "localizacao":  r[2], "prateleira":   r[3],
                "setor":        r[4], "posicao":      r[5],
                "quantidade":   r[6], "qtd_minima":   r[7],
                "preco_venda":  r[8], "marca":        r[9],
                "aplic":        r[10],"fornecedor":   r[11],
                "preco_custo":  r[12],
            }
            if dados["quantidade"] == 0 or dados["quantidade"] <= dados["qtd_minima"]:
                alertas += 1

            card = CardPeca(self._scroll, dados, on_click=self._card_clicado)
            card.pack(fill="x", padx=12, pady=4)
            # Duplo clique → popup de localização
            card.bind("<Double-1>", lambda e, d=dados: PopupLocalizacao(self, d))
            self._cards[dados["codigo"]] = card

        n = len(rows)
        av = f"  ·  ⚠ {alertas} com alerta" if alertas else ""
        self._lbl_count.configure(
            text=f"{n} peça{'s' if n!=1 else ''} encontrada{'s' if n!=1 else ''}{av}")

    def _card_clicado(self, dados: dict):
        # Destaca card selecionado
        if self._selecionado and self._selecionado in self._cards:
            self._cards[self._selecionado].destacar(False)
        self._selecionado = dados.get("codigo","")
        if self._selecionado in self._cards:
            self._cards[self._selecionado].destacar(True)
        self._on_selecionar(dados)
        loc = _formatar_local(dados.get("localizacao",""))
        self._status(f"📍  {loc}  —  {dados.get('nome','')}")

    def atualizar(self):
        self._buscar()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL DE EDIÇÃO (direita / gaveta lateral)
#  Abre quando uma peça é selecionada
# ══════════════════════════════════════════════════════════════════════════════
class PainelEdicao(ctk.CTkScrollableFrame):
    def __init__(self, master, db, status_cb, refresh_cb, **kw):
        super().__init__(master, width=340, fg_color=CARD,
                          bg_color=CARD, corner_radius=0,
                          border_width=1, border_color=BRD, **kw)
        self.configure(fg_color=CARD)
        self.db             = db
        self._status        = status_cb
        self._refresh       = refresh_cb
        self.ent: Dict[str, ctk.CTkEntry] = {}
        self._dados_atuais  = None
        self._build()

    def _build(self):
        ctk.CTkLabel(self, text="Cadastro / Edição",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=TXT).pack(pady=(14,4), padx=14, anchor="w")

        # ── LOCALIZAÇÃO FÍSICA (primeiro e em destaque) ─────────────────────
        ctk.CTkFrame(self, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=4)
        ctk.CTkLabel(self, text="📍  LOCALIZAÇÃO FÍSICA",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=ACC).pack(anchor="w", padx=14, pady=(6,2))

        # Prateleira / Setor / Posição em linha
        loc_grid = ctk.CTkFrame(self, fg_color="transparent")
        loc_grid.pack(fill="x", padx=14, pady=2)
        loc_grid.grid_columnconfigure((0,1,2), weight=1)

        for i, (key, ph, dica) in enumerate([
            ("prateleira", "Prat.", "Ex: Prateleira 1"),
            ("setor",      "Setor", "Ex: A"),
            ("posicao",    "Caixa", "Ex: 03"),
        ]):
            f = ctk.CTkFrame(loc_grid, fg_color="transparent")
            f.grid(row=0, column=i, padx=3, sticky="ew")
            ctk.CTkLabel(f, text=ph, font=ctk.CTkFont(size=10),
                         text_color=MUTED).pack(anchor="w")
            e = ctk.CTkEntry(f, placeholder_text=dica, height=36)
            e.pack(fill="x")
            self.ent[key] = e
            e.bind("<FocusOut>", self._atualizar_local_composto)

        # Campo de localização composto (auto-montado ou manual)
        ctk.CTkLabel(self, text="Código de localização (gerado automaticamente):",
                     font=ctk.CTkFont(size=10), text_color=MUTED).pack(
            anchor="w", padx=14, pady=(6,0))
        self.ent["localizacao"] = ctk.CTkEntry(
            self, placeholder_text="Ex: P1-A-03  (ou qualquer texto)",
            height=36, fg_color=CARD2)
        self.ent["localizacao"].pack(fill="x", padx=14, pady=2)

        # ── IDENTIFICAÇÃO ───────────────────────────────────────────────────
        ctk.CTkFrame(self, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=8)
        ctk.CTkLabel(self, text="IDENTIFICAÇÃO",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=14, pady=(0,2))

        # Código com leitor de barcode
        row_cod = ctk.CTkFrame(self, fg_color="transparent")
        row_cod.pack(fill="x", padx=14, pady=2)
        row_cod.grid_columnconfigure(0, weight=1)
        self.ent["codigo"] = ctk.CTkEntry(row_cod,
                                           placeholder_text="Código interno *",
                                           height=36)
        self.ent["codigo"].grid(row=0, column=0, sticky="ew", padx=(0,4))
        ctk.CTkButton(row_cod, text="📷", width=36, height=36,
                      command=self._leitor_barcode,
                      fg_color=CARD2).grid(row=0, column=1)

        for key, ph in [
            ("cod_fabricante", "Cód. fabricante / EAN"),
            ("nome",           "Nome da peça *"),
            ("marca",          "Marca  (ex: Mahle, LUK, Fras-le)"),
            ("fornecedor",     "Fornecedor"),
        ]:
            self.ent[key] = ctk.CTkEntry(self, placeholder_text=ph, height=36)
            self.ent[key].pack(fill="x", padx=14, pady=2)

        # ── VEÍCULOS ─────────────────────────────────────────────────────────
        ctk.CTkFrame(self, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=8)
        ctk.CTkLabel(self, text="🚗  APLICA EM (um veículo por linha)",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=14, pady=(0,2))
        self.txt_aplic = ctk.CTkTextbox(self, height=80, corner_radius=6,
                                         fg_color=CARD2)
        self.txt_aplic.pack(fill="x", padx=14, pady=2)

        # ── ESTOQUE & PREÇOS ─────────────────────────────────────────────────
        ctk.CTkFrame(self, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=8)
        ctk.CTkLabel(self, text="ESTOQUE & PREÇOS",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(anchor="w", padx=14, pady=(0,2))

        g2 = ctk.CTkFrame(self, fg_color="transparent")
        g2.pack(fill="x", padx=14, pady=2)
        g2.grid_columnconfigure((0,1), weight=1)
        for i, (key, ph) in enumerate([("quantidade","Qtd atual"),("qtd_minima","Qtd mínima")]):
            self.ent[key] = ctk.CTkEntry(g2, placeholder_text=ph, height=36)
            self.ent[key].grid(row=0, column=i, padx=3, sticky="ew")

        g3 = ctk.CTkFrame(self, fg_color="transparent")
        g3.pack(fill="x", padx=14, pady=2)
        g3.grid_columnconfigure((0,1), weight=1)
        for i, (key, ph) in enumerate([("preco_custo","Custo R$"),("preco_venda","Venda R$")]):
            self.ent[key] = ctk.CTkEntry(g3, placeholder_text=ph, height=36)
            self.ent[key].grid(row=0, column=i, padx=3, sticky="ew")

        # Observações
        ctk.CTkLabel(self, text="Observações:", font=ctk.CTkFont(size=10),
                     text_color=MUTED).pack(anchor="w", padx=14, pady=(6,0))
        self.txt_obs = ctk.CTkTextbox(self, height=52, corner_radius=6,
                                       fg_color=CARD2)
        self.txt_obs.pack(fill="x", padx=14, pady=2)

        # ── BOTÕES DE AÇÃO ────────────────────────────────────────────────────
        ctk.CTkFrame(self, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=8)

        btns = [
            ("💾  Salvar / Atualizar",   self._salvar,      ACC,   "#1d4ed8"),
            ("➕  Dar Entrada",           self._mov_entrada, OK,    "#15803d"),
            ("➖  Registrar Saída",       self._mov_saida,   "#b45309","#92400e"),
            ("🏷  Gerar Etiqueta",        self._etiqueta,    CARD2, BRD),
            ("🗑  Excluir Peça",          self._excluir,     ERR,   "#b91c1c"),
            ("🧹  Limpar",               self._limpar,      CARD2, BRD),
        ]
        for txt, cmd, fg, hv in btns:
            ctk.CTkButton(self, text=txt, command=cmd,
                          fg_color=fg, hover_color=hv,
                          height=36).pack(fill="x", padx=14, pady=2)

    def _atualizar_local_composto(self, event=None):
        """Monta 'P1-A-03' automaticamente a partir dos 3 campos."""
        prat  = self.ent["prateleira"].get().strip()
        setor = self.ent["setor"].get().strip()
        pos   = self.ent["posicao"].get().strip()
        if prat or setor or pos:
            # Extrai número da prateleira
            num = re.sub(r'[^0-9]', '', prat) or prat
            partes = []
            if num:   partes.append(f"P{num}")
            if setor: partes.append(setor.upper())
            if pos:   partes.append(pos.zfill(2))
            composto = "-".join(partes)
            self.ent["localizacao"].delete(0, tk.END)
            self.ent["localizacao"].insert(0, composto)

    def carregar(self, dados: dict):
        """Preenche o painel com os dados da peça selecionada."""
        self._dados_atuais = dados
        self._limpar_campos()

        mapa = {
            "codigo":       dados.get("codigo",""),
            "nome":         dados.get("nome",""),
            "localizacao":  dados.get("localizacao",""),
            "prateleira":   dados.get("prateleira",""),
            "setor":        dados.get("setor",""),
            "posicao":      dados.get("posicao",""),
            "quantidade":   str(dados.get("quantidade","")),
            "qtd_minima":   str(dados.get("qtd_minima","")),
            "preco_venda":  f"{dados.get('preco_venda',0):.2f}".replace(".",","),
            "preco_custo":  f"{dados.get('preco_custo',0):.2f}".replace(".",","),
            "marca":        dados.get("marca","") or "",
            "fornecedor":   dados.get("fornecedor","") or "",
            "cod_fabricante": "",
        }
        for key, val in mapa.items():
            if key in self.ent:
                self.ent[key].delete(0, tk.END)
                self.ent[key].insert(0, val)

        # Busca cod_fabricante e observações do banco
        row = self.db.q("SELECT cod_fabricante, observacoes FROM pecas WHERE codigo=?",
                        (dados.get("codigo",""),)).fetchone()
        if row:
            self.ent["cod_fabricante"].delete(0, tk.END)
            self.ent["cod_fabricante"].insert(0, row[0] or "")
            self.txt_obs.delete("1.0","end")
            self.txt_obs.insert("1.0", row[1] or "")

        # Aplicações
        apls = self.db.q("SELECT veiculo FROM aplicacoes WHERE codigo=? ORDER BY veiculo",
                         (dados.get("codigo",""),)).fetchall()
        self.txt_aplic.delete("1.0","end")
        self.txt_aplic.insert("1.0", "\n".join(a[0] for a in apls))

    def _limpar_campos(self):
        for e in self.ent.values():
            e.delete(0, tk.END)
        self.txt_aplic.delete("1.0","end")
        self.txt_obs.delete("1.0","end")

    def _salvar(self):
        cod  = self.ent["codigo"].get().strip()
        nome = self.ent["nome"].get().strip()
        if not cod or not nome:
            messagebox.showwarning("Obrigatório", "Preencha Código e Nome."); return

        prat  = self.ent["prateleira"].get().strip()
        setor = self.ent["setor"].get().strip()
        pos   = self.ent["posicao"].get().strip()
        local = self.ent["localizacao"].get().strip()

        # Se não tem código composto mas tem os campos, gera
        if not local and (prat or setor or pos):
            self._atualizar_local_composto()
            local = self.ent["localizacao"].get().strip()

        self.db.q("""
            INSERT OR REPLACE INTO pecas
            (codigo,nome,localizacao,prateleira,setor,posicao,
             quantidade,qtd_minima,preco_venda,preco_custo,
             fornecedor,marca,cod_fabricante,observacoes,atualizado)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            cod, nome, local, prat, setor, pos,
            parse_int(self.ent["quantidade"].get()),
            parse_int(self.ent["qtd_minima"].get()) or 2,
            parse_float(self.ent["preco_venda"].get()),
            parse_float(self.ent["preco_custo"].get()),
            self.ent["fornecedor"].get().strip(),
            self.ent["marca"].get().strip(),
            self.ent["cod_fabricante"].get().strip(),
            self.txt_obs.get("1.0","end").strip(),
            agora()
        ))
        self.db.q("DELETE FROM aplicacoes WHERE codigo=?", (cod,))
        for linha in self.txt_aplic.get("1.0","end").strip().splitlines():
            if linha.strip():
                self.db.q("INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)",
                          (cod, linha.strip()))
        self.db.commit()
        self._status(f"✅  Peça «{nome}» salva em {_formatar_local(local)}")
        self._refresh()

    def _peca_selecionada(self):
        cod = self.ent["codigo"].get().strip()
        if not cod:
            messagebox.showwarning("Aviso","Selecione uma peça na lista."); return None
        r = self.db.q("SELECT codigo,nome,quantidade,preco_custo,preco_venda FROM pecas WHERE codigo=?",
                      (cod,)).fetchone()
        if not r:
            messagebox.showwarning("Não encontrada", f"Peça {cod} não está no banco."); return None
        return dict(r)

    def _mov_entrada(self):
        d = self._peca_selecionada()
        if d: JanelaMov(self, self.db, d, self._pos_mov)

    def _mov_saida(self):
        d = self._peca_selecionada()
        if d:
            j = JanelaMov(self, self.db, d, self._pos_mov)
            j.tipo_var.set("saida")

    def _pos_mov(self):
        self._refresh()
        cod = self.ent["codigo"].get().strip()
        if cod:
            r = self.db.q("""SELECT p.codigo,p.nome,p.localizacao,p.prateleira,p.setor,p.posicao,
                                    p.quantidade,p.qtd_minima,p.preco_venda,p.marca,
                                    '' as aplic,p.fornecedor,p.preco_custo
                              FROM pecas p WHERE p.codigo=?""",(cod,)).fetchone()
            if r: self.carregar(dict(r))

    def _excluir(self):
        cod = self.ent["codigo"].get().strip()
        if not cod: messagebox.showwarning("Aviso","Selecione uma peça."); return
        if not messagebox.askyesno("Confirmar", f"Excluir a peça {cod}?"): return
        self.db.q("DELETE FROM pecas WHERE codigo=?", (cod,))
        self.db.commit()
        self._status(f"🗑  Peça {cod} excluída.")
        self._limpar_campos()
        self._refresh()

    def _limpar(self):
        self._dados_atuais = None
        self._limpar_campos()

    def _leitor_barcode(self):
        win = ctk.CTkToplevel(self)
        win.title("Leitor de Código de Barras")
        win.geometry("380x200")
        win.grab_set()
        win.configure(fg_color=BG)
        ctk.CTkLabel(win, text="📷  Passe o leitor USB agora",
                     font=ctk.CTkFont(size=14, weight="bold"), text_color=TXT).pack(pady=(20,4))
        ctk.CTkLabel(win, text="O leitor age como teclado. Código aparece abaixo.",
                     text_color=MUTED).pack()
        ent = ctk.CTkEntry(win, width=300, height=44, font=ctk.CTkFont(size=16))
        ent.pack(pady=14); ent.focus()
        def _ok(e=None):
            cod = ent.get().strip()
            if cod:
                self.ent["cod_fabricante"].delete(0, tk.END)
                self.ent["cod_fabricante"].insert(0, cod)
                if not self.ent["codigo"].get().strip():
                    self.ent["codigo"].delete(0, tk.END)
                    self.ent["codigo"].insert(0, cod)
            win.destroy()
        ent.bind("<Return>", _ok)
        ctk.CTkButton(win, text="Confirmar", command=_ok, fg_color=ACC).pack()

    def _etiqueta(self):
        if DEPS_FALTANDO:
            messagebox.showerror("Libs ausentes",
                f"Instale: pip install {' '.join(DEPS_FALTANDO)}"); return
        from barcode import Code128
        from barcode.writer import ImageWriter
        from PIL import Image, ImageDraw, ImageFont

        cod    = self.ent["codigo"].get().strip()
        nome   = self.ent["nome"].get().strip()
        prat   = self.ent["prateleira"].get().strip()
        setor  = self.ent["setor"].get().strip()
        pos    = self.ent["posicao"].get().strip()
        local  = self.ent["localizacao"].get().strip()
        marca  = self.ent["marca"].get().strip()

        partes = []
        if prat:  partes.append(prat)
        if setor: partes.append(f"Setor {setor}")
        if pos:   partes.append(f"Cx {pos}")
        loc_txt = "  ·  ".join(partes) if partes else _formatar_local(local)

        apls = [l.strip() for l in self.txt_aplic.get("1.0","end").splitlines() if l.strip()]
        apls_str = " / ".join(apls[:3])

        if not cod:
            messagebox.showwarning("Aviso","Preencha o Código."); return
        try:
            buf = io.BytesIO()
            writer = ImageWriter()
            writer.set_options({"module_height":10.0,"module_width":0.7,
                                "font_size":7,"text_distance":3.0,
                                "quiet_zone":4.0,"dpi":200,"write_text":True})
            Code128(cod, writer=writer).write(buf)
            buf.seek(0)
            img_bc = Image.open(buf).convert("RGB")
            W, H_TOP = img_bc.width, 120

            cor_rgb = tuple(int(_cor_prateleira(prat or local).lstrip("#")[i:i+2],16) for i in (0,2,4))

            etiqueta = Image.new("RGB",(W, H_TOP + img_bc.height),(255,255,255))
            draw = ImageDraw.Draw(etiqueta)

            def _fnt(sz, bold=False):
                for p in [("arialbd.ttf" if bold else "arial.ttf"),
                          "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
                          else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
                    try: return ImageFont.truetype(p, sz)
                    except: pass
                return ImageFont.load_default()

            draw.rectangle([0,0,W,8], fill=cor_rgb)
            draw.text((10,14), f"📍  {loc_txt}", font=_fnt(15,True), fill=cor_rgb)
            draw.text((10,38), nome, font=_fnt(14,True), fill=(15,15,15))
            y = 60
            if marca: draw.text((10,y), f"Marca: {marca}", font=_fnt(11), fill=(80,80,80)); y+=16
            if apls_str: draw.text((10,y), f"Aplica: {apls_str}", font=_fnt(10), fill=(80,80,80)); y+=14
            draw.text((10,y), f"Cód: {cod}", font=_fnt(10), fill=(120,120,120))
            etiqueta.paste(img_bc, (0, H_TOP))

            arq = f"mecatrack_etiqueta_{cod}.png"
            etiqueta.save(arq, dpi=(200,200))
            if messagebox.askyesno("Etiqueta gerada ✅",
                f"Salvo em: {os.path.abspath(arq)}\n\nImprimir agora?"):
                if sys.platform.startswith("win"): os.startfile(arq,"print")
                elif sys.platform == "darwin": os.system(f'lpr "{arq}"')
                else: os.system(f'lpr "{arq}" 2>/dev/null || xdg-open "{arq}"')
            self._status(f"🏷  Etiqueta {arq} gerada.")
        except Exception as exc:
            messagebox.showerror("Erro", f"{type(exc).__name__}: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA DE HISTÓRICO
# ══════════════════════════════════════════════════════════════════════════════
class JanelaHistorico(ctk.CTkToplevel):
    def __init__(self, parent, db, codigo=None):
        super().__init__(parent)
        self.db = db
        self.title("Histórico de Movimentações")
        self.geometry("820x500")
        self.grab_set()
        self.configure(fg_color=BG)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        frow = ctk.CTkFrame(self, fg_color=CARD, corner_radius=8)
        frow.grid(row=0, column=0, padx=12, pady=(12,4), sticky="ew")
        ctk.CTkLabel(frow, text="Código:").pack(side="left", padx=(10,4))
        self._ef = ctk.CTkEntry(frow, width=150, height=34)
        self._ef.pack(side="left", padx=4)
        if codigo: self._ef.insert(0, codigo)

        self._tipo_var = tk.StringVar(value="todos")
        ctk.CTkOptionMenu(frow, variable=self._tipo_var,
                          values=["todos","entrada","saida","ajuste"],
                          width=120, height=34).pack(side="left", padx=4)
        ctk.CTkButton(frow, text="Buscar", width=80, height=34,
                      command=self._carregar).pack(side="left", padx=8)
        ctk.CTkButton(frow, text="Exportar CSV", width=120, height=34,
                      fg_color=CARD2, command=self._exportar).pack(side="right", padx=10)
        ctk.CTkButton(frow, text="Exportar PDF", width=120, height=34,
                      fg_color=CARD2, command=self._exportar_pdf).pack(side="right", padx=4)

        cols = ("data_hora","codigo","nome","tipo","qtd","motivo","usuario")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", style="M.Treeview")
        for col, (txt, w) in zip(cols,[("Data/Hora",140),("Código",90),("Peça",180),
                                        ("Tipo",70),("Qtd",50),("Motivo",230),("Usuário",90)]):
            self.tree.heading(col, text=txt); self.tree.column(col, width=w)
        self.tree.tag_configure("entrada", foreground="#4ade80")
        self.tree.tag_configure("saida",   foreground="#f87171")
        self.tree.tag_configure("ajuste",  foreground="#fbbf24")

        sb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=sb.set)
        self.tree.grid(row=1, column=0, sticky="nsew", padx=(12,0), pady=4)
        sb.grid(row=1, column=1, sticky="ns", pady=4, padx=(0,8))
        self._lbl = ctk.CTkLabel(self, text="", text_color=MUTED, font=ctk.CTkFont(size=11))
        self._lbl.grid(row=2, column=0, padx=14, pady=(2,8), sticky="w")
        self._carregar()

    def _carregar(self):
        self.tree.delete(*self.tree.get_children())
        filtro = self._ef.get().strip(); tipo = self._tipo_var.get()
        conds, params = [], {}
        if filtro: conds.append("(m.codigo LIKE :f OR p.nome LIKE :f)"); params["f"]=f"%{filtro}%"
        if tipo != "todos": conds.append("m.tipo=:tp"); params["tp"]=tipo
        where = "WHERE " + " AND ".join(conds) if conds else ""
        rows = self.db.q(f"""
            SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
            FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo
            {where} ORDER BY m.id DESC LIMIT 1000
        """, params).fetchall()
        for r in rows:
            tag = r[3] if r[3] in ("entrada","saida","ajuste") else "ajuste"
            self.tree.insert("","end",values=tuple(r),tags=(tag,))
        self._lbl.configure(text=f"{len(rows)} registros")

    def _exportar(self):
        rows = self.db.q("""
            SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
            FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo ORDER BY m.id DESC
        """).fetchall()
        nome = f"mecatrack_historico_{hoje()}.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["Data/Hora","Código","Peça","Tipo","Qtd","Motivo","Usuário"])
            w.writerows(rows)
        messagebox.showinfo("Exportado", f"Salvo em:\n{os.path.abspath(nome)}", parent=self)

    def _exportar_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import cm
        except ImportError:
            messagebox.showerror("Erro","Instale: pip install reportlab",parent=self); return
        nome = f"mecatrack_historico_{hoje()}.pdf"
        doc = SimpleDocTemplate(nome, pagesize=landscape(A4),
                                leftMargin=1*cm, rightMargin=1*cm,
                                topMargin=1.5*cm, bottomMargin=1*cm)
        styles = getSampleStyleSheet()
        rows = self.db.q("""
            SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
            FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo ORDER BY m.id DESC LIMIT 500
        """).fetchall()
        data = [["Data/Hora","Código","Peça","Tipo","Qtd","Motivo","Usuário"]] + [list(r) for r in rows]
        t = Table(data, colWidths=[3.5*cm,2.2*cm,5*cm,1.8*cm,1.2*cm,7*cm,2*cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A8A")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),8),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, colors.HexColor("#EFF6FF")]),
            ("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#CBD5E1")),
        ]))
        doc.build([Paragraph("<b>MECATRACK — Histórico de Movimentações</b>",styles["Title"]),
                   Paragraph(f"Gerado em: {agora()}",styles["Normal"]),
                   Spacer(1,0.5*cm), t])
        messagebox.showinfo("PDF gerado ✅", f"Salvo em:\n{os.path.abspath(nome)}", parent=self)


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA DE EXPORTAÇÃO / IMPORTAÇÃO (menu)
# ══════════════════════════════════════════════════════════════════════════════
class JanelaFerramentas(ctk.CTkToplevel):
    def __init__(self, parent, db, usuario, status_cb, refresh_cb):
        super().__init__(parent)
        self.db, self.usuario = db, usuario
        self._status, self._refresh = status_cb, refresh_cb
        self.title("Ferramentas — Exportar / Importar")
        self.geometry("640x560")
        self.grab_set()
        self.configure(fg_color=BG)
        self._build()

    def _build(self):
        ctk.CTkLabel(self, text="Ferramentas",
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=TXT).pack(pady=(18,4), padx=20, anchor="w")

        # Exportar
        card_exp = ctk.CTkFrame(self, fg_color=CARD, corner_radius=10,
                                 border_width=1, border_color=BRD)
        card_exp.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(card_exp, text="📤  Exportar Estoque",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TXT).pack(anchor="w", padx=14, pady=(12,4))
        btn_row = ctk.CTkFrame(card_exp, fg_color="transparent")
        btn_row.pack(fill="x", padx=14, pady=(0,12))
        ctk.CTkButton(btn_row, text="Exportar CSV", command=self._exp_csv,
                      fg_color=ACC).pack(side="left", padx=4)
        ctk.CTkButton(btn_row, text="Exportar Excel", command=self._exp_excel,
                      fg_color=CARD2).pack(side="left", padx=4)
        ctk.CTkButton(btn_row, text="Exportar PDF (relatório)", command=self._exp_pdf,
                      fg_color=CARD2).pack(side="left", padx=4)

        # Importar
        card_imp = ctk.CTkFrame(self, fg_color=CARD, corner_radius=10,
                                 border_width=1, border_color=BRD)
        card_imp.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(card_imp, text="📥  Importar CSV",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TXT).pack(anchor="w", padx=14, pady=(12,4))
        ctk.CTkLabel(card_imp,
                     text="Colunas esperadas: Código; Nome; Prateleira; Setor; Posição;\n"
                          "Qtd; QtdMin; Custo; Venda; Marca; Fornecedor; CódFabricante; Aplicações",
                     font=ctk.CTkFont(size=10), text_color=MUTED).pack(anchor="w", padx=14)
        btn_row2 = ctk.CTkFrame(card_imp, fg_color="transparent")
        btn_row2.pack(fill="x", padx=14, pady=(4,12))
        ctk.CTkButton(btn_row2, text="Selecionar CSV e Importar",
                      command=self._importar, fg_color=OK).pack(side="left", padx=4)
        ctk.CTkButton(btn_row2, text="Baixar modelo CSV",
                      command=self._modelo, fg_color=CARD2).pack(side="left", padx=4)

        # Histórico
        card_hist = ctk.CTkFrame(self, fg_color=CARD, corner_radius=10,
                                  border_width=1, border_color=BRD)
        card_hist.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(card_hist, text="🕒  Histórico & Auditoria",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=TXT).pack(anchor="w", padx=14, pady=(12,4))
        btn_row3 = ctk.CTkFrame(card_hist, fg_color="transparent")
        btn_row3.pack(fill="x", padx=14, pady=(0,12))
        ctk.CTkButton(btn_row3, text="Histórico de movimentações",
                      command=lambda: JanelaHistorico(self, self.db),
                      fg_color=CARD2).pack(side="left", padx=4)

        # Log
        ctk.CTkLabel(self, text="Log:", text_color=MUTED,
                     font=ctk.CTkFont(size=11)).pack(anchor="w", padx=22, pady=(8,2))
        self._txt = ctk.CTkTextbox(self, fg_color=CARD,
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    corner_radius=8)
        self._txt.pack(fill="both", expand=True, padx=20, pady=(0,16))

    def _log(self, msg):
        self._txt.configure(state="normal")
        self._txt.insert("end", f"{agora()} — {msg}\n")
        self._txt.see("end")

    def _exp_csv(self):
        rows = self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.localizacao,
                   p.quantidade,p.qtd_minima,p.preco_custo,p.preco_venda,
                   p.marca,p.fornecedor,p.cod_fabricante,
                   GROUP_CONCAT(a.veiculo,' / ')
            FROM pecas p LEFT JOIN aplicacoes a ON a.codigo=p.codigo
            GROUP BY p.codigo ORDER BY p.prateleira,p.setor,p.posicao
        """).fetchall()
        nome = f"mecatrack_estoque_{hoje()}.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["Código","Nome","Prateleira","Setor","Posição","Localização",
                        "Qtd","QtdMin","Custo","Venda","Marca","Fornecedor","CódFab","Aplicações"])
            w.writerows(rows)
        self._log(f"CSV exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("Exportado ✅", f"Salvo em:\n{os.path.abspath(nome)}", parent=self)

    def _exp_excel(self):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            messagebox.showerror("Erro","pip install openpyxl",parent=self); return

        wb = openpyxl.Workbook()
        ws = wb.active; ws.title = "Estoque"
        h_font = Font(bold=True, color="FFFFFF", size=11)
        h_fill = PatternFill("solid", fgColor="1E3A8A")
        thin   = Side(border_style="thin", color="CBD5E1")
        brd    = openpyxl.styles.Border(left=thin,right=thin,top=thin,bottom=thin)

        hdrs = ["Código","Nome","Prateleira","Setor","Posição","Localização",
                "Qtd","QtdMin","Custo R$","Venda R$","Margem%","Marca","Fornecedor","Aplicações"]
        ws.append(hdrs)
        for cell in ws[1]:
            cell.font=h_font; cell.fill=h_fill; cell.border=brd
            cell.alignment=Alignment(horizontal="center")

        rows = self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.localizacao,
                   p.quantidade,p.qtd_minima,p.preco_custo,p.preco_venda,p.marca,p.fornecedor,
                   GROUP_CONCAT(a.veiculo,' / ')
            FROM pecas p LEFT JOIN aplicacoes a ON a.codigo=p.codigo
            GROUP BY p.codigo ORDER BY p.prateleira,p.setor,p.posicao
        """).fetchall()

        alt = PatternFill("solid", fgColor="EFF6FF")
        for idx, r in enumerate(rows, 2):
            custo, venda = r[8], r[9]
            margem = round((venda-custo)/venda*100,1) if venda else 0
            ws.append([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],custo,venda,margem,r[10],r[11],r[12] or ""])
            if idx%2==0:
                for cell in ws[idx]: cell.fill=alt
            for cell in ws[idx]: cell.border=brd
            # Alerta
            qty_cell = ws[idx][6]
            if r[6]==0: qty_cell.font=Font(color="EF4444",bold=True)
            elif r[6]<=r[7]: qty_cell.font=Font(color="F59E0B",bold=True)

        from openpyxl.utils import get_column_letter
        for ci, col in enumerate(ws.columns,1):
            w = min(max(len(str(c.value or "")) for c in col)+4, 40)
            ws.column_dimensions[get_column_letter(ci)].width = w

        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions

        # Aba resumo
        ws2 = wb.create_sheet("Resumo")
        est = self.db.estatisticas()
        ws2.append(["Métrica","Valor"])
        for k,v in [("Total itens",est["itens"]),("Zerados",est["zerados"]),
                    ("Abaixo mínimo",est["baixos"]),("Valor custo",round(est["custo"],2)),
                    ("Valor venda",round(est["venda"],2)),("Gerado em",agora())]:
            ws2.append([k,v])

        nome = f"mecatrack_estoque_{hoje()}.xlsx"
        wb.save(nome)
        self._log(f"Excel exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("Exportado ✅",f"Salvo em:\n{os.path.abspath(nome)}",parent=self)

    def _exp_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import cm
        except ImportError:
            messagebox.showerror("Erro","pip install reportlab",parent=self); return

        nome = f"mecatrack_estoque_{hoje()}.pdf"
        doc = SimpleDocTemplate(nome, pagesize=landscape(A4),
                                leftMargin=1*cm, rightMargin=1*cm,
                                topMargin=1.5*cm, bottomMargin=1*cm)
        styles = getSampleStyleSheet()
        rows = self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.localizacao,
                   p.quantidade,p.preco_venda,p.marca,GROUP_CONCAT(a.veiculo,' / ')
            FROM pecas p LEFT JOIN aplicacoes a ON a.codigo=p.codigo
            GROUP BY p.codigo ORDER BY p.prateleira,p.setor,p.posicao
        """).fetchall()

        data = [["Código","Nome","Prateleira","Setor","Posição","Local","Qtd","Venda","Marca","Aplica em"]]
        for r in rows:
            data.append([str(x) if x else "—" for x in r])

        t = Table(data, colWidths=[2.2*cm,4.5*cm,2.5*cm,1.5*cm,1.5*cm,2*cm,1.2*cm,2*cm,2.5*cm,4.5*cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A8A")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),7),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#EFF6FF")]),
            ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#CBD5E1")),
        ]))
        est = self.db.estatisticas()
        doc.build([
            Paragraph(f"<b>MECATRACK — Estoque Completo por Localização</b>",styles["Title"]),
            Paragraph(f"Gerado em: {agora()}  ·  {est['itens']} itens  ·  {est['unidades']} unidades",
                      styles["Normal"]),
            Spacer(1,0.5*cm), t
        ])
        self._log(f"PDF exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("PDF gerado ✅",f"Salvo em:\n{os.path.abspath(nome)}",parent=self)

    def _importar(self):
        path = filedialog.askopenfilename(title="Selecionar CSV",
                   filetypes=[("CSV","*.csv"),("Todos","*.*")], parent=self)
        if not path: return
        criados = atualizados = erros = 0
        self._log(f"Importando: {path}")

        try:
            for enc in ["utf-8-sig","utf-8","latin-1","cp1252"]:
                try:
                    with open(path, newline="", encoding=enc) as ff:
                        sample = ff.read(2048)
                    encoding = enc; break
                except: pass

            with open(path, newline="", encoding=encoding) as ff:
                try:
                    import csv as _csv
                    dialect = _csv.Sniffer().sniff(sample, delimiters=";,\t")
                    reader  = _csv.DictReader(ff, dialect=dialect)
                except Exception:
                    ff.seek(0)
                    reader = _csv.DictReader(ff, delimiter=";")

                col = {k.lower().strip():k for k in (reader.fieldnames or [])}

                def gc(alts):
                    for a in alts:
                        if a in col: return col[a]
                    return None

                F = {
                    "cod":   gc(["código","codigo","code","id"]),
                    "nome":  gc(["nome","name","descrição","descricao"]),
                    "prat":  gc(["prateleira","prateleira","shelf","prat"]),
                    "setor": gc(["setor","sector","area"]),
                    "pos":   gc(["posição","posicao","posicao","caixa","cx","pos","position"]),
                    "local": gc(["localização","localizacao","local","location"]),
                    "qty":   gc(["quantidade","qtd","qty","quantity","estoque"]),
                    "min":   gc(["qtd mínima","qtd minima","qtdmin","min","mínimo"]),
                    "custo": gc(["custo r$","custo","cost"]),
                    "venda": gc(["venda r$","venda","price","preço"]),
                    "marca": gc(["marca","brand"]),
                    "forn":  gc(["fornecedor","supplier"]),
                    "ean":   gc(["cód fabricante","cod fabricante","ean","barcode"]),
                    "aplic": gc(["aplicações","aplicacoes","veículos","veiculos","cars"]),
                }

                for row in reader:
                    rl = {k.lower().strip():v for k,v in row.items()}
                    def gv(field):
                        fk = F.get(field)
                        return (rl.get(fk.lower().strip(),"") if fk else "").strip()

                    cod  = gv("cod")
                    nome = gv("nome")
                    if not cod or not nome:
                        erros+=1; self._log(f"  ⚠ Linha sem código/nome ignorada"); continue

                    prat  = gv("prat")
                    setor = gv("setor")
                    pos   = gv("pos")
                    local = gv("local")
                    if not local and (prat or setor or pos):
                        num = re.sub(r'[^0-9]','',prat) or prat
                        partes = []
                        if num:   partes.append(f"P{num}")
                        if setor: partes.append(setor.upper())
                        if pos:   partes.append(pos.zfill(2))
                        local = "-".join(partes)

                    existe = self.db.q("SELECT codigo FROM pecas WHERE codigo=?",
                                       (cod,)).fetchone()
                    try:
                        self.db.q("""
                            INSERT OR REPLACE INTO pecas
                            (codigo,nome,localizacao,prateleira,setor,posicao,
                             quantidade,qtd_minima,preco_custo,preco_venda,
                             marca,fornecedor,cod_fabricante,atualizado)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        """, (cod,nome,local,prat,setor,pos,
                              parse_int(gv("qty")), parse_int(gv("min")) or 2,
                              parse_float(gv("custo")), parse_float(gv("venda")),
                              gv("marca"), gv("forn"), gv("ean"), agora()))
                        self.db.q("DELETE FROM aplicacoes WHERE codigo=?",(cod,))
                        for aplic in (gv("aplic") or "").split("/"):
                            if aplic.strip():
                                self.db.q("INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)",
                                          (cod, aplic.strip()))
                        if existe: atualizados+=1
                        else:      criados+=1
                    except Exception as ex:
                        erros+=1; self._log(f"  ❌ Erro em {cod}: {ex}")

            self.db.commit()
            msg = f"✅ Concluído: {criados} criados, {atualizados} atualizados, {erros} erros."
            self._log(msg)
            messagebox.showinfo("Importação concluída", msg, parent=self)
            self._status(msg); self._refresh()
        except Exception as exc:
            self._log(f"❌ Falha: {exc}")
            messagebox.showerror("Erro", str(exc), parent=self)

    def _modelo(self):
        nome = "mecatrack_modelo_importacao.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["Código","Nome","Prateleira","Setor","Posição",
                        "Qtd","QtdMin","Custo","Venda","Marca","Fornecedor","CódFab","Aplicações"])
            w.writerow(["FLT-001","Filtro de óleo Mahle","Prateleira 1","A","03",
                        "10","2","12,50","29,90","Mahle","Distribuidora XYZ","OC 222","Gol 1.0/Palio 1.0"])
            w.writerow(["KIT-EMB-002","Kit de embreagem LUK","Prateleira 2","B","07",
                        "3","1","180,00","420,00","LUK","Peças Sul","628 3060 00","Corsa 1.0/Celta 1.0"])
        self._log(f"Modelo criado: {os.path.abspath(nome)}")
        messagebox.showinfo("Modelo criado",
                            f"Arquivo:\n{os.path.abspath(nome)}\n\nEdite e importe.",
                            parent=self)


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA DE USUÁRIOS
# ══════════════════════════════════════════════════════════════════════════════
class JanelaUsuarios(ctk.CTkToplevel):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.title("Gerenciar Usuários")
        self.geometry("540x420")
        self.grab_set()
        self.configure(fg_color=BG)
        self._build()

    def _build(self):
        ctk.CTkLabel(self, text="Usuários do Sistema",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=TXT).pack(pady=(16,8), padx=16, anchor="w")

        cols = ("login","perfil","ativo","criado")
        self.tree = ttk.Treeview(self, columns=cols, show="headings",
                                  style="M.Treeview", height=8)
        for col, (txt,w) in zip(cols,[("Login",180),("Perfil",100),("Ativo",60),("Criado",160)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.pack(fill="both", expand=True, padx=16, pady=4)

        form = ctk.CTkFrame(self, fg_color=CARD2, corner_radius=8)
        form.pack(fill="x", padx=16, pady=8)
        form.grid_columnconfigure((0,1,2,3), weight=1)
        self._ent_l = ctk.CTkEntry(form, placeholder_text="Login",  height=36, width=140)
        self._ent_s = ctk.CTkEntry(form, placeholder_text="Senha",  height=36, width=140, show="*")
        self._pv    = tk.StringVar(value="operador")
        self._ent_l.grid(row=0,column=0,padx=8,pady=8)
        self._ent_s.grid(row=0,column=1,padx=4)
        ctk.CTkOptionMenu(form,variable=self._pv,values=["operador","gerente","admin"],
                          width=110,height=36).grid(row=0,column=2,padx=4)
        br = ctk.CTkFrame(form,fg_color="transparent"); br.grid(row=0,column=3,padx=8)
        ctk.CTkButton(br,text="➕ Adicionar",width=110,height=36,
                      fg_color=OK,command=self._add).pack(side="left",padx=2)
        ctk.CTkButton(br,text="🚫 Desativar",width=110,height=36,
                      fg_color=ERR,command=self._desat).pack(side="left",padx=2)
        self._refresh()

    def _refresh(self):
        self.tree.delete(*self.tree.get_children())
        for r in self.db.q("SELECT login,perfil,ativo,criado FROM usuarios ORDER BY login").fetchall():
            self.tree.insert("","end",iid=r[0],values=(r[0],r[1],"✅" if r[2] else "❌",r[3] or "—"))

    def _add(self):
        l,s,p = self._ent_l.get().strip(), self._ent_s.get().strip(), self._pv.get()
        if not l or not s:
            messagebox.showwarning("Aviso","Preencha login e senha.",parent=self); return
        try:
            self.db.q("INSERT INTO usuarios(login,senha,perfil,ativo) VALUES(?,?,?,1)",
                      (l,sha256(s),p)); self.db.commit()
            self._ent_l.delete(0,tk.END); self._ent_s.delete(0,tk.END); self._refresh()
        except sqlite3.IntegrityError:
            messagebox.showwarning("Aviso","Login já existe.",parent=self)

    def _desat(self):
        sel = self.tree.selection()
        if not sel: return
        if sel[0]=="admin":
            messagebox.showwarning("Aviso","Não é possível desativar admin.",parent=self); return
        self.db.q("UPDATE usuarios SET ativo=0 WHERE login=?",(sel[0],))
        self.db.commit(); self._refresh()


# ══════════════════════════════════════════════════════════════════════════════
#  APLICAÇÃO PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════
class AppMecatrack(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1280x780")
        self.minsize(1000, 620)
        self.configure(fg_color=BG)
        self.update()

        self.db = Database()
        self._backup_auto()
        self._build_ui()
        self.update()

    def _backup_auto(self):
        def _f():
            os.makedirs(BACKUP_DIR, exist_ok=True)
            dest = os.path.join(BACKUP_DIR, f"mecatrack_{hoje()}.db")
            if not os.path.exists(dest) and os.path.exists(DB_FILE):
                shutil.copy2(DB_FILE, dest)
                baks = sorted(os.listdir(BACKUP_DIR))
                for b in baks[:-30]: os.remove(os.path.join(BACKUP_DIR, b))
        threading.Thread(target=_f, daemon=True).start()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=0)  # painel prateleiras
        self.grid_columnconfigure(1, weight=1)  # localizador (cards)
        self.grid_columnconfigure(2, weight=0)  # painel edição
        self.grid_rowconfigure(0, weight=1)

        # ── Sidebar esquerda: Prateleiras ────────────────────────────────────
        self._painel_prat = PainelPrateleiras(
            self, self.db,
            on_filtro=lambda n: self._localizador.set_filtro_prateleira(n)
        )
        self._painel_prat.grid(row=0, column=0, sticky="nsew")

        # ── Centro: Localizador ──────────────────────────────────────────────
        self._localizador = PainelLocalizador(
            self, self.db,
            on_selecionar=self._peca_selecionada,
            status_cb=self._set_status
        )
        self._localizador.grid(row=0, column=1, sticky="nsew")

        # ── Painel direito: Edição ───────────────────────────────────────────
        self._edicao = PainelEdicao(
            self, self.db,
            status_cb=self._set_status,
            refresh_cb=self._refresh_tudo
        )
        self._edicao.grid(row=0, column=2, sticky="nsew")

        # ── Barra de status + menu ────────────────────────────────────────────
        self._build_statusbar()

        # Força repintura no Windows (evita tela branca)
        self.after(50, self._forcar_cores)

    def _forcar_cores(self):
        """Reaplica cores em todos os frames — corrige bug de tela branca no Windows."""
        self.configure(fg_color=BG)
        for w in self.winfo_children():
            try:
                cls = w.__class__.__name__
                if "ScrollableFrame" in cls or "Frame" in cls:
                    w.configure(fg_color=w.cget("fg_color"))
            except Exception:
                pass
        self.update_idletasks()

    def _build_statusbar(self):
        bar = ctk.CTkFrame(self, height=34, corner_radius=0,
                            fg_color=CARD, border_width=1, border_color=BRD)
        bar.grid(row=1, column=0, columnspan=3, sticky="ew")
        bar.grid_columnconfigure(1, weight=1)

        # Menu botões
        menu_frame = ctk.CTkFrame(bar, fg_color="transparent")
        menu_frame.grid(row=0, column=0, padx=8, pady=4)

        for txt, cmd in [
            ("⚙  Novo Cadastro",    self._novo_cadastro),
            ("🔧  Ferramentas",      self._ferramentas),
            ("🕒  Histórico",        self._historico),
        ]:
            ctk.CTkButton(menu_frame, text=txt, command=cmd,
                          fg_color=CARD2, hover_color=BRD,
                          height=26, font=ctk.CTkFont(size=11)).pack(side="left", padx=3)

        self._status_var = tk.StringVar(
            value=f"{APP_NAME} {APP_VERSION}  ·  {hoje()}")
        ctk.CTkLabel(bar, textvariable=self._status_var,
                     font=ctk.CTkFont(size=10),
                     text_color=MUTED, anchor="e").grid(row=0, column=2, padx=14, sticky="e")

        if DEPS_FALTANDO:
            ctk.CTkLabel(bar, text=f"⚠ pip install {' '.join(DEPS_FALTANDO)}",
                         font=ctk.CTkFont(size=10),
                         text_color=WARN).grid(row=0, column=1, padx=8)

    def _set_status(self, msg):
        self._status_var.set(msg)

    def _peca_selecionada(self, dados: dict):
        self._edicao.carregar(dados)

    def _refresh_tudo(self):
        self._localizador.atualizar()
        self._painel_prat.atualizar()

    def _novo_cadastro(self):
        self._edicao._limpar_campos()

    def _ferramentas(self):
        JanelaFerramentas(self, self.db, "sistema",
                          self._set_status, self._refresh_tudo)

    def _historico(self):
        JanelaHistorico(self, self.db)

    def on_closing(self):
        self.db.close()
        self.destroy()


# ── Estilos ttk globais ────────────────────────────────────────────────────────
def _aplicar_estilo():
    style = ttk.Style()
    style.theme_use("default")
    style.configure("M.Treeview",
                    background=CARD, foreground=TXT,
                    fieldbackground=CARD, rowheight=28,
                    font=("Consolas",10))
    style.configure("M.Treeview.Heading",
                    background=CARD2, foreground="#94a3b8",
                    font=("Consolas",10,"bold"), relief="flat")
    style.map("M.Treeview",
              background=[("selected","#1e3a5f")],
              foreground=[("selected","white")])

# ── Entry-point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    _aplicar_estilo()
    app = AppMecatrack()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()