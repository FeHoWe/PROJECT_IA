# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║              MECATRACK ERP  v4.0  —  Sistema Unificado                       ║
# ║   Localizador · Estoque · PDV · Orçamentos · Financeiro · Relatórios          ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
#
#  INSTALAÇÃO:
#     pip install customtkinter python-barcode Pillow matplotlib openpyxl reportlab
#
#  EXECUÇÃO:
#     python mecatrack_erp.py
#
#  MÓDULOS:
#     1. Localizador    — busca instantânea + localização física
#     2. Cadastro       — cadastro / edição de peças
#     3. PDV / Caixa    — frente de caixa com carrinho
#     4. Orçamentos     — criação / acompanhamento
#     5. Pedidos        — controle de pedidos de venda
#     6. Compras        — pedidos de compra para fornecedores
#     7. Financeiro     — contas a receber / pagar
#     8. Clientes       — cadastro de clientes PF/PJ
#     9. Fornecedores   — cadastro de fornecedores
#    10. Relatórios     — exportação Excel / PDF / CSV
#    11. Usuários       — controle de acesso
#    12. Configurações  — dados da empresa, backup

import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk, filedialog
import customtkinter as ctk
import os, sys, io, shutil, datetime, hashlib, csv, threading, re
from typing import Optional, List, Tuple, Dict

APP_NAME    = "MecaTrack ERP"
APP_VERSION = "v4.0"
APP_TITLE   = f"{APP_NAME}  ·  Sistema de Autopeças  {APP_VERSION}"
DB_FILE     = "mecatrack_estoque.db"
BACKUP_DIR  = "mecatrack_backups"
LOG_FILE    = "mecatrack_auditoria.log"

# ── Deps opcionais ─────────────────────────────────────────────────────────────
def _checar_deps():
    m = []
    for mod, pkg in [("barcode","python-barcode"),("PIL","Pillow"),
                     ("matplotlib","matplotlib"),("openpyxl","openpyxl"),
                     ("reportlab","reportlab")]:
        try: __import__(mod)
        except ImportError: m.append(pkg)
    return m

DEPS_FALTANDO = _checar_deps()

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── Paleta ─────────────────────────────────────────────────────────────────────
BG    = "#0f1117"
CARD  = "#1a1d27"
CARD2 = "#22263a"
ACC   = "#3b82f6"
ACC2  = "#6366f1"
OK    = "#22c55e"
WARN  = "#f59e0b"
ERR   = "#ef4444"
TXT   = "#e2e8f0"
MUTED = "#64748b"
BRD   = "#2d3148"
PURP  = "#8b5cf6"
CYAN  = "#06b6d4"
PINK  = "#ec4899"

CORES_PRAT = ["#3b82f6","#22c55e","#f59e0b","#ef4444","#8b5cf6",
               "#06b6d4","#ec4899","#f97316","#84cc16","#64748b"]

# ══════════════════════════════════════════════════════════════════════════════
#  UTILITÁRIOS
# ══════════════════════════════════════════════════════════════════════════════
def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def agora():   return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def hoje():    return datetime.date.today().isoformat()

def fmt_brl(v):
    try:
        return f"R$ {float(v):,.2f}".replace(",","X").replace(".",",").replace("X",".")
    except: return "R$ 0,00"

def parse_float(s):
    try: return float(str(s).strip().replace("R$","").replace(" ","").replace(".","").replace(",","."))
    except: return 0.0

def parse_int(s):
    try: return int(str(s).strip())
    except: return 0

def auditar(usuario, acao, detalhe=""):
    try:
        with open(LOG_FILE,"a",encoding="utf-8") as f:
            f.write(f"{agora()} | {usuario:12s} | {acao:30s} | {detalhe}\n")
    except: pass

def _cor_prateleira(nome_local: str) -> str:
    match = re.search(r'\d+', str(nome_local))
    if match:
        idx = (int(match.group()) - 1) % len(CORES_PRAT)
        return CORES_PRAT[idx]
    h = abs(hash(str(nome_local))) % len(CORES_PRAT)
    return CORES_PRAT[h]

def _hex_claro(hex_cor: str, fator: float = 0.15) -> str:
    try:
        h = hex_cor.lstrip("#")
        r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
        br, bg, bb = 26, 29, 39
        nr = int(br + (r - br) * fator)
        ng = int(bg + (g - bg) * fator)
        nb = int(bb + (b - bb) * fator)
        return f"#{nr:02x}{ng:02x}{nb:02x}"
    except Exception:
        return CARD

def _formatar_local(local: str) -> str:
    if not local: return "—"
    m = re.match(r'^[Pp][a-zA-Z]*(\d+)[-\s]([A-Za-z]+)[-\s](\w+)$', local.strip())
    if m:
        return f"Prat {m.group(1)} · Set {m.group(2).upper()} · Cx {m.group(3)}"
    return local

def _lbl_secao(parent, texto, cor=MUTED):
    ctk.CTkFrame(parent, height=1, fg_color=BRD).pack(fill="x", padx=14, pady=(8,4))
    ctk.CTkLabel(parent, text=texto,
                 font=ctk.CTkFont(size=10, weight="bold"),
                 text_color=cor).pack(anchor="w", padx=14, pady=(0,3))


# ══════════════════════════════════════════════════════════════════════════════
#  BANCO DE DADOS — SCHEMA COMPLETO
# ══════════════════════════════════════════════════════════════════════════════
class Database:
    def __init__(self, path=DB_FILE):
        self.path = path
        self._local = threading.local()
        self._main = self._new_conn()
        self._criar_todas_tabelas()
        self._migrar()
        self._criar_indices()

    def _new_conn(self):
        c = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=5000")
        c.row_factory = sqlite3.Row
        return c

    @property
    def conn(self):
        if not hasattr(self._local,"c") or not self._local.c:
            self._local.c = self._new_conn()
        return self._local.c

    def _criar_todas_tabelas(self):
        self._main.executescript("""
        -- ── USUÁRIOS ──────────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS usuarios (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            login   TEXT UNIQUE NOT NULL,
            senha   TEXT NOT NULL,
            perfil  TEXT DEFAULT 'operador',
            ativo   INTEGER DEFAULT 1,
            criado  TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- ── PEÇAS / ESTOQUE ───────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS pecas (
            codigo          TEXT PRIMARY KEY,
            nome            TEXT NOT NULL,
            localizacao     TEXT DEFAULT '',
            prateleira      TEXT DEFAULT '',
            setor           TEXT DEFAULT '',
            posicao         TEXT DEFAULT '',
            quantidade      INTEGER DEFAULT 0,
            qtd_minima      INTEGER DEFAULT 2,
            preco_venda     REAL DEFAULT 0.0,
            preco_custo     REAL DEFAULT 0.0,
            fornecedor      TEXT DEFAULT '',
            marca           TEXT DEFAULT '',
            cod_fabricante  TEXT DEFAULT '',
            categoria       TEXT DEFAULT '',
            ncm             TEXT DEFAULT '',
            unidade         TEXT DEFAULT 'UN',
            observacoes     TEXT DEFAULT '',
            ativo           INTEGER DEFAULT 1,
            atualizado      TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS aplicacoes (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo  TEXT NOT NULL REFERENCES pecas(codigo) ON DELETE CASCADE,
            veiculo TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS movimentacoes (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo     TEXT NOT NULL,
            tipo       TEXT NOT NULL,
            quantidade INTEGER NOT NULL,
            motivo     TEXT DEFAULT '',
            usuario    TEXT DEFAULT '',
            data_hora  TEXT NOT NULL
        );

        -- ── CLIENTES ──────────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS clientes (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo            TEXT DEFAULT 'PF',
            nome            TEXT NOT NULL,
            nome_fantasia   TEXT DEFAULT '',
            cpf_cnpj        TEXT DEFAULT '',
            ie              TEXT DEFAULT '',
            telefone        TEXT DEFAULT '',
            email           TEXT DEFAULT '',
            endereco        TEXT DEFAULT '',
            bairro          TEXT DEFAULT '',
            cidade          TEXT DEFAULT '',
            uf              TEXT DEFAULT '',
            cep             TEXT DEFAULT '',
            limite_credito  REAL DEFAULT 0.0,
            tabela_preco    TEXT DEFAULT 'Varejo',
            observacoes     TEXT DEFAULT '',
            ativo           INTEGER DEFAULT 1,
            criado          TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- ── FORNECEDORES ──────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS fornecedores (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            razao_social    TEXT NOT NULL,
            nome_fantasia   TEXT DEFAULT '',
            cnpj            TEXT DEFAULT '',
            ie              TEXT DEFAULT '',
            representante   TEXT DEFAULT '',
            telefone        TEXT DEFAULT '',
            email           TEXT DEFAULT '',
            endereco        TEXT DEFAULT '',
            cidade          TEXT DEFAULT '',
            uf              TEXT DEFAULT '',
            prazo_entrega   INTEGER DEFAULT 7,
            cond_pagamento  TEXT DEFAULT '30 dias',
            observacoes     TEXT DEFAULT '',
            ativo           INTEGER DEFAULT 1,
            criado          TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- ── ORÇAMENTOS ────────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS orcamentos (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            numero          TEXT UNIQUE NOT NULL,
            cliente_id      INTEGER REFERENCES clientes(id),
            cliente_nome    TEXT DEFAULT '',
            status          TEXT DEFAULT 'aberto',
            desconto_pct    REAL DEFAULT 0.0,
            total           REAL DEFAULT 0.0,
            validade_dias   INTEGER DEFAULT 7,
            observacoes     TEXT DEFAULT '',
            usuario         TEXT DEFAULT '',
            criado          TEXT DEFAULT CURRENT_TIMESTAMP,
            atualizado      TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS orcamento_itens (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            orc_id      INTEGER NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
            codigo      TEXT NOT NULL,
            nome        TEXT NOT NULL,
            quantidade  INTEGER DEFAULT 1,
            preco_unit  REAL DEFAULT 0.0,
            desconto    REAL DEFAULT 0.0,
            subtotal    REAL DEFAULT 0.0
        );

        -- ── PEDIDOS DE VENDA ──────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS pedidos (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            numero          TEXT UNIQUE NOT NULL,
            cliente_id      INTEGER REFERENCES clientes(id),
            cliente_nome    TEXT DEFAULT '',
            status          TEXT DEFAULT 'pendente',
            forma_pagto     TEXT DEFAULT 'Dinheiro',
            desconto_pct    REAL DEFAULT 0.0,
            total           REAL DEFAULT 0.0,
            total_pago      REAL DEFAULT 0.0,
            orc_origem      TEXT DEFAULT '',
            observacoes     TEXT DEFAULT '',
            usuario         TEXT DEFAULT '',
            criado          TEXT DEFAULT CURRENT_TIMESTAMP,
            atualizado      TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS pedido_itens (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            ped_id      INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
            codigo      TEXT NOT NULL,
            nome        TEXT NOT NULL,
            quantidade  INTEGER DEFAULT 1,
            preco_unit  REAL DEFAULT 0.0,
            desconto    REAL DEFAULT 0.0,
            subtotal    REAL DEFAULT 0.0
        );

        -- ── PEDIDOS DE COMPRA ─────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS pedidos_compra (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            numero          TEXT UNIQUE NOT NULL,
            fornecedor_id   INTEGER REFERENCES fornecedores(id),
            fornecedor_nome TEXT DEFAULT '',
            status          TEXT DEFAULT 'pendente',
            total           REAL DEFAULT 0.0,
            previsao        TEXT DEFAULT '',
            observacoes     TEXT DEFAULT '',
            usuario         TEXT DEFAULT '',
            criado          TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS compra_itens (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            compra_id   INTEGER NOT NULL REFERENCES pedidos_compra(id) ON DELETE CASCADE,
            codigo      TEXT NOT NULL,
            nome        TEXT NOT NULL,
            quantidade  INTEGER DEFAULT 1,
            preco_unit  REAL DEFAULT 0.0,
            subtotal    REAL DEFAULT 0.0
        );

        -- ── FINANCEIRO ────────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS contas_receber (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao       TEXT NOT NULL,
            cliente_nome    TEXT DEFAULT '',
            pedido_ref      TEXT DEFAULT '',
            valor           REAL DEFAULT 0.0,
            valor_pago      REAL DEFAULT 0.0,
            vencimento      TEXT NOT NULL,
            pagamento       TEXT DEFAULT '',
            status          TEXT DEFAULT 'aberto',
            observacoes     TEXT DEFAULT '',
            criado          TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS contas_pagar (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao       TEXT NOT NULL,
            fornecedor_nome TEXT DEFAULT '',
            compra_ref      TEXT DEFAULT '',
            valor           REAL DEFAULT 0.0,
            valor_pago      REAL DEFAULT 0.0,
            vencimento      TEXT NOT NULL,
            pagamento       TEXT DEFAULT '',
            status          TEXT DEFAULT 'aberto',
            observacoes     TEXT DEFAULT '',
            criado          TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- ── CONDIÇÕES DE PAGAMENTO ────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS condicoes_pagamento (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            nome            TEXT UNIQUE NOT NULL,
            parcelas        INTEGER DEFAULT 1,
            intervalo_dias  INTEGER DEFAULT 30,
            desconto_avista REAL DEFAULT 0.0,
            ativo           INTEGER DEFAULT 1
        );

        -- ── TABELAS DE PREÇO ──────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS tabelas_preco (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            nome                TEXT UNIQUE NOT NULL,
            desconto_percentual REAL DEFAULT 0.0,
            ativo               INTEGER DEFAULT 1
        );

        -- ── NF-e (simulação) ──────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS nfe (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            numero      TEXT UNIQUE NOT NULL,
            serie       TEXT DEFAULT '1',
            chave       TEXT DEFAULT '',
            pedido_ref  TEXT DEFAULT '',
            cliente_nome TEXT DEFAULT '',
            valor_total REAL DEFAULT 0.0,
            status      TEXT DEFAULT 'rascunho',
            ambiente    TEXT DEFAULT '2',
            xml_content TEXT DEFAULT '',
            observacoes TEXT DEFAULT '',
            usuario     TEXT DEFAULT '',
            criado      TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- ── CONFIGURAÇÕES ─────────────────────────────────────────────────────
        CREATE TABLE IF NOT EXISTS config (
            chave   TEXT PRIMARY KEY,
            valor   TEXT DEFAULT ''
        );
        """)

        # Admin padrão
        self._main.execute(
            "INSERT OR IGNORE INTO usuarios(login,senha,perfil) VALUES(?,?,?)",
            ("admin", sha256("admin123"), "admin"))

        # Configurações padrão
        configs = [
            ("empresa_nome",   "Autopeças Exemplo Ltda"),
            ("empresa_cnpj",   "00.000.000/0001-00"),
            ("empresa_fone",   "(51) 3000-0000"),
            ("empresa_cidade", "Porto Alegre"),
            ("empresa_uf",     "RS"),
            ("nfe_ambiente",   "2"),
            ("prox_orcamento", "1"),
            ("prox_pedido",    "1"),
            ("prox_compra",    "1"),
            ("prox_nfe",       "1"),
            ("empresa_ie",     ""),
            ("empresa_endereco",""),
        ]
        for k, v in configs:
            self._main.execute("INSERT OR IGNORE INTO config(chave,valor) VALUES(?,?)", (k,v))

        # Condições de pagamento padrão
        conds = [
            ("À Vista",       1, 0,  5.0),
            ("30 dias",       1, 30, 0.0),
            ("30/60 dias",    2, 30, 0.0),
            ("30/60/90 dias", 3, 30, 0.0),
            ("4x sem juros",  4, 30, 0.0),
        ]
        for nome, parc, inter, desc in conds:
            self._main.execute(
                "INSERT OR IGNORE INTO condicoes_pagamento(nome,parcelas,intervalo_dias,desconto_avista) VALUES(?,?,?,?)",
                (nome, parc, inter, desc))

        # Tabelas de preço padrão
        tabs = [("Varejo",0.0),("Atacado",10.0),("VIP",15.0)]
        for nome, desc in tabs:
            self._main.execute(
                "INSERT OR IGNORE INTO tabelas_preco(nome,desconto_percentual) VALUES(?,?)",
                (nome, desc))

        self._main.commit()

    def _criar_indices(self):
        indices = [
            "CREATE INDEX IF NOT EXISTS idx_pecas_local  ON pecas(localizacao)",
            "CREATE INDEX IF NOT EXISTS idx_pecas_prat   ON pecas(prateleira)",
            "CREATE INDEX IF NOT EXISTS idx_pecas_nome   ON pecas(nome)",
            "CREATE INDEX IF NOT EXISTS idx_mov_codigo   ON movimentacoes(codigo)",
            "CREATE INDEX IF NOT EXISTS idx_ped_status   ON pedidos(status)",
            "CREATE INDEX IF NOT EXISTS idx_orc_status   ON orcamentos(status)",
        ]
        for sql in indices:
            try: self._main.execute(sql)
            except sqlite3.OperationalError: pass
        self._main.commit()

    def _migrar(self):
        """Adiciona colunas novas sem perder dados existentes."""
        cols = [
            ("pecas","prateleira","TEXT DEFAULT ''"),
            ("pecas","setor","TEXT DEFAULT ''"),
            ("pecas","posicao","TEXT DEFAULT ''"),
            ("pecas","observacoes","TEXT DEFAULT ''"),
            ("pecas","atualizado","TEXT DEFAULT CURRENT_TIMESTAMP"),
            ("pecas","cod_fabricante","TEXT DEFAULT ''"),
            ("pecas","preco_venda","REAL DEFAULT 0.0"),
            ("pecas","preco_custo","REAL DEFAULT 0.0"),
            ("pecas","fornecedor","TEXT DEFAULT ''"),
            ("pecas","marca","TEXT DEFAULT ''"),
            ("pecas","qtd_minima","INTEGER DEFAULT 2"),
            ("pecas","localizacao","TEXT DEFAULT ''"),
            ("pecas","categoria","TEXT DEFAULT ''"),
            ("pecas","ncm","TEXT DEFAULT ''"),
            ("pecas","unidade","TEXT DEFAULT 'UN'"),
            ("pecas","ativo","INTEGER DEFAULT 1"),
            ("usuarios","ativo","INTEGER DEFAULT 1"),
            ("usuarios","criado","TEXT DEFAULT CURRENT_TIMESTAMP"),
        ]
        for tab, col, dfn in cols:
            try: self._main.execute(f"ALTER TABLE {tab} ADD COLUMN {col} {dfn}")
            except sqlite3.OperationalError: pass

        # Migra coluna 'preco' → 'preco_venda'
        try:
            cols_ex = [r[1] for r in self._main.execute("PRAGMA table_info(pecas)").fetchall()]
            if "preco" in cols_ex:
                self._main.execute("UPDATE pecas SET preco_venda=preco WHERE preco_venda=0.0 AND preco!=0.0")
        except: pass

        # Migra aplicacao singular → aplicacoes
        try:
            cols_ex = [r[1] for r in self._main.execute("PRAGMA table_info(pecas)").fetchall()]
            if "aplicacao" in cols_ex:
                for cod, aplic in self._main.execute(
                    "SELECT codigo,aplicacao FROM pecas WHERE aplicacao IS NOT NULL AND aplicacao!=''").fetchall():
                    if not self._main.execute("SELECT id FROM aplicacoes WHERE codigo=?",(cod,)).fetchone():
                        self._main.execute("INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)",(cod,aplic))
        except: pass

        # Migra localização antiga → prateleira/setor/posicao
        try:
            for cod, local in self._main.execute(
                "SELECT codigo,localizacao FROM pecas WHERE prateleira='' AND localizacao!=''").fetchall():
                m = re.match(r'^[Pp][a-zA-Z]*(\d+)[-\s]([A-Za-z]+)[-\s](\w+)$', local.strip())
                if m:
                    self._main.execute("UPDATE pecas SET prateleira=?,setor=?,posicao=? WHERE codigo=?",
                        (f"Prateleira {m.group(1)}", m.group(2).upper(), m.group(3).zfill(2), cod))
                else:
                    self._main.execute("UPDATE pecas SET prateleira=? WHERE codigo=?", (local, cod))
        except: pass

        self._main.commit()

    # ── Métodos de consulta ──────────────────────────────────────────────────
    def q(self, sql, params=()): return self._main.execute(sql, params)
    def commit(self): self._main.commit()
    def close(self): self._main.close()

    def cfg(self, chave, default=""):
        r = self._main.execute("SELECT valor FROM config WHERE chave=?", (chave,)).fetchone()
        return r[0] if r else default

    def set_cfg(self, chave, valor):
        self._main.execute("INSERT OR REPLACE INTO config(chave,valor) VALUES(?,?)", (chave, valor))
        self._main.commit()

    def prox_numero(self, chave, prefixo):
        n = int(self.cfg(chave, "1"))
        self.set_cfg(chave, str(n + 1))
        return f"{prefixo}{n:05d}"

    def buscar_pecas(self, termo="", filtro_local="", filtro_alerta=""):
        conds, params = [], {}
        if termo:
            conds.append("""(p.nome LIKE :t OR p.codigo LIKE :t OR p.localizacao LIKE :t
                          OR p.prateleira LIKE :t OR p.setor LIKE :t
                          OR p.marca LIKE :t OR p.fornecedor LIKE :t
                          OR p.cod_fabricante LIKE :t OR a.veiculo LIKE :t)""")
            params["t"] = f"%{termo}%"
        if filtro_local:
            conds.append("(p.prateleira LIKE :fl OR p.localizacao LIKE :fl)")
            params["fl"] = f"%{filtro_local}%"
        if filtro_alerta == "zerados":
            conds.append("p.quantidade = 0")
        elif filtro_alerta == "baixo":
            conds.append("p.quantidade > 0 AND p.quantidade <= p.qtd_minima")
        elif filtro_alerta == "ok":
            conds.append("p.quantidade > p.qtd_minima")
        conds.append("p.ativo = 1")
        where = "WHERE " + " AND ".join(conds)
        return self._main.execute(f"""
            SELECT p.codigo,p.nome,p.localizacao,p.prateleira,p.setor,p.posicao,
                   p.quantidade,p.qtd_minima,p.preco_venda,p.marca,
                   GROUP_CONCAT(DISTINCT a.veiculo) AS aplic,
                   p.fornecedor,p.preco_custo,p.categoria,p.unidade
            FROM pecas p
            LEFT JOIN aplicacoes a ON a.codigo=p.codigo
            {where}
            GROUP BY p.codigo
            ORDER BY p.prateleira,p.setor,p.posicao,p.nome
        """, params).fetchall()

    def prateleiras(self):
        return self._main.execute("""
            SELECT prateleira,COUNT(*) as total,
                   SUM(CASE WHEN quantidade=0 THEN 1 ELSE 0 END) as zerados,
                   SUM(CASE WHEN quantidade>0 AND quantidade<=qtd_minima THEN 1 ELSE 0 END) as baixos
            FROM pecas WHERE prateleira!='' AND ativo=1
            GROUP BY prateleira ORDER BY prateleira
        """).fetchall()

    def estatisticas(self):
        r = self._main.execute(
            "SELECT COUNT(*),SUM(quantidade),SUM(preco_custo*quantidade),SUM(preco_venda*quantidade) FROM pecas WHERE ativo=1"
        ).fetchone()
        z = self._main.execute("SELECT COUNT(*) FROM pecas WHERE quantidade=0 AND ativo=1").fetchone()[0]
        b = self._main.execute("SELECT COUNT(*) FROM pecas WHERE quantidade>0 AND quantidade<=qtd_minima AND ativo=1").fetchone()[0]
        v_hoje = self._main.execute(
            "SELECT COALESCE(SUM(total),0) FROM pedidos WHERE DATE(criado)=DATE('now') AND status!='cancelado'"
        ).fetchone()[0]
        return {
            "itens":r[0] or 0,"unidades":r[1] or 0,
            "custo":r[2] or 0.0,"venda":r[3] or 0.0,
            "zerados":z,"baixos":b,"vendas_hoje":v_hoje or 0.0
        }


# ══════════════════════════════════════════════════════════════════════════════
#  TELA DE LOGIN
# ══════════════════════════════════════════════════════════════════════════════
class TelaLogin(ctk.CTkToplevel):
    def __init__(self, db, callback):
        super().__init__()
        self.db, self.callback = db, callback
        self.title(f"{APP_NAME} — Login")
        self.geometry("400x320")
        self.resizable(False, False)
        self.grab_set()
        self.configure(fg_color=BG)
        self._tentativas = 0
        self._build()

    def _build(self):
        ctk.CTkLabel(self, text="⚙", font=ctk.CTkFont(size=44)).pack(pady=(28,2))
        ctk.CTkLabel(self, text="MECATRACK ERP",
                     font=ctk.CTkFont(size=22, weight="bold"),
                     text_color=ACC).pack()
        ctk.CTkLabel(self, text="Sistema de Autopeças",
                     text_color=MUTED, font=ctk.CTkFont(size=11)).pack(pady=(0,18))
        self._ent_login = ctk.CTkEntry(self, placeholder_text="Usuário", width=280, height=40)
        self._ent_login.pack(pady=4)
        self._ent_senha = ctk.CTkEntry(self, placeholder_text="Senha", show="*", width=280, height=40)
        self._ent_senha.pack(pady=4)
        self._ent_senha.bind("<Return>", lambda _: self._entrar())
        self._lbl_erro = ctk.CTkLabel(self, text="", text_color=ERR, font=ctk.CTkFont(size=11))
        self._lbl_erro.pack(pady=2)
        ctk.CTkButton(self, text="Entrar →", width=280, height=42,
                      font=ctk.CTkFont(size=14, weight="bold"),
                      fg_color=ACC, command=self._entrar).pack(pady=6)
        ctk.CTkLabel(self, text="Padrão: admin / admin123",
                     text_color=MUTED, font=ctk.CTkFont(size=10)).pack()

    def _entrar(self):
        if self._tentativas >= 5:
            self._lbl_erro.configure(text="Muitas tentativas. Reinicie."); return
        login = self._ent_login.get().strip()
        row = self.db.q(
            "SELECT perfil FROM usuarios WHERE login=? AND senha=? AND ativo=1",
            (login, sha256(self._ent_senha.get()))
        ).fetchone()
        if row:
            self.destroy(); self.callback(login, row[0])
        else:
            self._tentativas += 1
            self._lbl_erro.configure(text=f"Credenciais inválidas. ({self._tentativas}/5)")


# ══════════════════════════════════════════════════════════════════════════════
#  CARD DE PEÇA (localizador)
# ══════════════════════════════════════════════════════════════════════════════
class CardPeca(ctk.CTkFrame):
    def __init__(self, master, dados: dict, on_click, **kw):
        super().__init__(master, corner_radius=10, fg_color=CARD,
                         border_width=1, border_color=BRD, **kw)
        self._dados = dados
        self._on_click = on_click
        self._build()
        self.bind("<Button-1>", self._clique)

    def _build(self):
        d = self._dados
        prateleira = d.get("prateleira","") or ""
        setor      = d.get("setor","") or ""
        posicao    = d.get("posicao","") or ""
        local_raw  = d.get("localizacao","") or ""
        qty        = d.get("quantidade", 0)
        min_qty    = d.get("qtd_minima", 2)
        cor_local  = _cor_prateleira(prateleira or local_raw)

        stripe = ctk.CTkFrame(self, width=6, corner_radius=0, fg_color=cor_local)
        stripe.pack(side="left", fill="y")
        stripe.bind("<Button-1>", self._clique)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        body.bind("<Button-1>", self._clique)

        partes = []
        if prateleira: partes.append(prateleira)
        if setor:      partes.append(f"Setor {setor}")
        if posicao:    partes.append(f"Cx {posicao}")
        if not partes and local_raw: partes = [_formatar_local(local_raw)]
        loc_txt = "  ·  ".join(partes) if partes else "Localização não definida"

        loc_frame = ctk.CTkFrame(body, fg_color=_hex_claro(cor_local, 0.18), corner_radius=6)
        loc_frame.pack(fill="x", pady=(0,5))
        loc_frame.bind("<Button-1>", self._clique)
        lbl = ctk.CTkLabel(loc_frame, text=f"📍  {loc_txt}",
                            font=ctk.CTkFont(size=14, weight="bold"),
                            text_color=cor_local, anchor="w")
        lbl.pack(padx=10, pady=6, anchor="w")
        lbl.bind("<Button-1>", self._clique)

        nome_lbl = ctk.CTkLabel(body, text=d.get("nome",""),
                                 font=ctk.CTkFont(size=13, weight="bold"),
                                 text_color=TXT, anchor="w", wraplength=340)
        nome_lbl.pack(fill="x")
        nome_lbl.bind("<Button-1>", self._clique)

        aplic = d.get("aplic","") or ""
        if aplic:
            al = ctk.CTkLabel(body, text=f"🚗  {aplic[:80]}{'…' if len(aplic)>80 else ''}",
                               font=ctk.CTkFont(size=11), text_color=MUTED, anchor="w", wraplength=340)
            al.pack(fill="x"); al.bind("<Button-1>", self._clique)

        rodape = ctk.CTkFrame(body, fg_color="transparent")
        rodape.pack(fill="x", pady=(5,0))
        rodape.bind("<Button-1>", self._clique)

        ctk.CTkLabel(rodape, text=f"#{d.get('codigo','')}",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(side="left")
        marca = d.get("marca","")
        if marca:
            ctk.CTkLabel(rodape, text=f"  {marca}", font=ctk.CTkFont(size=10),
                         text_color=MUTED).pack(side="left")

        if qty == 0:
            qtd_cor, qtd_txt, qtd_bg = ERR, "⛔ Zerado",    _hex_claro(ERR, 0.20)
        elif qty <= min_qty:
            qtd_cor, qtd_txt, qtd_bg = WARN, f"⚠ {qty} un.", _hex_claro(WARN, 0.20)
        else:
            qtd_cor, qtd_txt, qtd_bg = OK,  f"✓ {qty} un.", _hex_claro(OK, 0.20)

        badge = ctk.CTkFrame(rodape, fg_color=qtd_bg, corner_radius=6)
        badge.pack(side="right")
        ctk.CTkLabel(badge, text=qtd_txt,
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=qtd_cor).pack(padx=8, pady=2)

        preco = d.get("preco_venda", 0)
        if preco:
            ctk.CTkLabel(rodape, text=fmt_brl(preco),
                         font=ctk.CTkFont(size=11), text_color=MUTED).pack(side="right", padx=8)

    def _clique(self, event=None): self._on_click(self._dados)
    def destacar(self, ativo=True):
        self.configure(border_color=ACC if ativo else BRD, border_width=2 if ativo else 1)


# ══════════════════════════════════════════════════════════════════════════════
#  POPUP DE LOCALIZAÇÃO
# ══════════════════════════════════════════════════════════════════════════════
class PopupLocalizacao(ctk.CTkToplevel):
    def __init__(self, parent, dados: dict):
        super().__init__(parent)
        self.configure(fg_color=BG)
        self.title(f"Localização — {dados.get('nome','')}")
        self.geometry("560x440"); self.resizable(False, False); self.grab_set()
        d = dados
        cor    = _cor_prateleira(d.get("prateleira","") or d.get("localizacao",""))
        partes = []
        if d.get("prateleira"): partes.append(d["prateleira"])
        if d.get("setor"):      partes.append(f"Setor {d['setor']}")
        if d.get("posicao"):    partes.append(f"Caixa {d['posicao']}")
        if not partes and d.get("localizacao"): partes = [d["localizacao"]]

        header = ctk.CTkFrame(self, fg_color=cor, corner_radius=0, height=160)
        header.pack(fill="x"); header.pack_propagate(False)
        ctk.CTkLabel(header, text="📍", font=ctk.CTkFont(size=40)).pack(pady=(20,0))
        ctk.CTkLabel(header, text="  ·  ".join(partes) or "Sem localização",
                     font=ctk.CTkFont(size=28, weight="bold"), text_color="white").pack(pady=4)

        ctk.CTkLabel(self, text=d.get("nome",""),
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=TXT, wraplength=500).pack(pady=(20,6), padx=20)

        info = ctk.CTkFrame(self, fg_color=CARD2, corner_radius=8)
        info.pack(padx=20, fill="x", pady=4)
        for label, val in [("Código:",d.get("codigo","")),
                            ("Marca:", d.get("marca","") or "—"),
                            ("Qtd:",   f"{d.get('quantidade',0)} un.")]:
            col = ctk.CTkFrame(info, fg_color="transparent")
            col.pack(side="left", expand=True, pady=10, padx=10)
            ctk.CTkLabel(col, text=label, font=ctk.CTkFont(size=10), text_color=MUTED).pack()
            ctk.CTkLabel(col, text=str(val), font=ctk.CTkFont(size=14, weight="bold"), text_color=TXT).pack()

        aplic = d.get("aplic","") or ""
        if aplic:
            af = ctk.CTkFrame(self, fg_color=CARD, corner_radius=8, border_width=1, border_color=BRD)
            af.pack(padx=20, fill="x", pady=8)
            ctk.CTkLabel(af, text="🚗  Aplica em:", font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=MUTED).pack(anchor="w", padx=12, pady=(8,2))
            ctk.CTkLabel(af, text=aplic.replace(",","  /  ")[:200],
                         font=ctk.CTkFont(size=12), text_color=TXT, wraplength=480).pack(anchor="w",padx=12,pady=(0,8))

        ctk.CTkButton(self, text="✓  Fechar", command=self.destroy,
                      fg_color=cor, height=42,
                      font=ctk.CTkFont(size=14, weight="bold")).pack(pady=16, padx=20, fill="x")


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL PRATELEIRAS (sidebar)
# ══════════════════════════════════════════════════════════════════════════════
class PainelPrateleiras(ctk.CTkScrollableFrame):
    def __init__(self, master, db, on_filtro, **kw):
        super().__init__(master, width=180, fg_color=CARD, bg_color=CARD, corner_radius=0, **kw)
        self.configure(fg_color=CARD)
        self.db, self.on_filtro = db, on_filtro
        self._ativa = None; self._botoes = {}
        self.atualizar()

    def atualizar(self):
        for w in self.winfo_children(): w.destroy()
        self._botoes.clear()
        ctk.CTkLabel(self, text="PRATELEIRAS",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=MUTED).pack(pady=(14,6), padx=10, anchor="w")
        btn_todas = ctk.CTkButton(self, text="📦  Todas", command=lambda: self._selecionar(""),
                                   fg_color=CARD2, hover_color=BRD, anchor="w", height=34,
                                   font=ctk.CTkFont(size=12))
        btn_todas.pack(fill="x", padx=6, pady=2)
        self._botoes[""] = btn_todas
        for r in self.db.prateleiras():
            nome = r[0] or ""; total=r[1] or 0; zerados=r[2] or 0; baixos=r[3] or 0
            cor = _cor_prateleira(nome)
            alerta = f" 🔴{zerados}" if zerados else (f" 🟡{baixos}" if baixos else "")
            btn = ctk.CTkButton(self, text=f"{nome}{alerta}\n{total} iten{'s' if total!=1 else ''}",
                                command=lambda n=nome: self._selecionar(n),
                                fg_color=CARD2, hover_color=_hex_claro(cor,0.25),
                                text_color=TXT, anchor="w", height=44,
                                border_width=2, border_color=cor, font=ctk.CTkFont(size=11))
            btn.pack(fill="x", padx=6, pady=2)
            self._botoes[nome] = btn
        if not self.db.prateleiras():
            ctk.CTkLabel(self, text="Nenhuma prateleira\nainda.",
                         font=ctk.CTkFont(size=11), text_color=MUTED).pack(padx=10, pady=20)

    def _selecionar(self, nome):
        self._ativa = nome
        for k, b in self._botoes.items():
            cor = _cor_prateleira(k) if k else ACC
            b.configure(fg_color=(_hex_claro(cor,0.45) if k==nome else CARD2))
        self.on_filtro(nome)


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL LOCALIZADOR (centro)
# ══════════════════════════════════════════════════════════════════════════════
class PainelLocalizador(ctk.CTkFrame):
    def __init__(self, master, db, on_selecionar, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._on_selecionar=on_selecionar; self._status=status_cb
        self._filtro_prat=""; self._cards={}; self._selecionado=None
        self._build()

    def _build(self):
        self.grid_columnconfigure(0, weight=1); self.grid_rowconfigure(1, weight=1)
        barra = ctk.CTkFrame(self, fg_color=CARD, corner_radius=0, height=60)
        barra.grid(row=0, column=0, sticky="ew")
        barra.grid_columnconfigure(0, weight=1); barra.grid_propagate(False)
        ctk.CTkLabel(barra, text="🔍", font=ctk.CTkFont(size=18)).grid(row=0,column=0,padx=(14,0),pady=12,sticky="w")
        self._txt_busca = ctk.CTkEntry(barra,
            placeholder_text="Buscar peça, código, carro, marca, localização…",
            height=38, font=ctk.CTkFont(size=15), fg_color=CARD2, border_color=BRD)
        self._txt_busca.grid(row=0, column=0, padx=(44,6), pady=12, sticky="ew")
        self._txt_busca.bind("<KeyRelease>", self._buscar)
        self._filtro_var = tk.StringVar(value="todos")
        ctk.CTkOptionMenu(barra, variable=self._filtro_var,
                          values=["todos","zerados","baixo","ok"],
                          width=120, height=38, command=lambda _: self._buscar()
                          ).grid(row=0, column=1, padx=(0,6), pady=12)
        ctk.CTkButton(barra, text="✕", width=38, height=38, fg_color=CARD2,
                      command=self._limpar).grid(row=0, column=2, padx=(0,14), pady=12)
        self._scroll = ctk.CTkScrollableFrame(self, fg_color=BG, corner_radius=0)
        self._scroll.grid(row=1, column=0, sticky="nsew")
        self._scroll.grid_columnconfigure(0, weight=1)
        self._lbl_count = ctk.CTkLabel(self, text="", font=ctk.CTkFont(size=11), text_color=MUTED)
        self._lbl_count.grid(row=2, column=0, padx=14, pady=4, sticky="w")
        self._txt_busca.focus(); self.atualizar()

    def set_filtro_prateleira(self, nome: str):
        self._filtro_prat = nome; self._buscar()

    def _buscar(self, event=None):
        rows = self.db.buscar_pecas(
            termo=self._txt_busca.get().strip(),
            filtro_local=self._filtro_prat,
            filtro_alerta=self._filtro_var.get() if self._filtro_var.get()!="todos" else "")
        self._renderizar(rows)

    def _limpar(self):
        self._txt_busca.delete(0, tk.END)
        self._filtro_prat = ""; self._filtro_var.set("todos"); self._buscar()

    def _renderizar(self, rows):
        for w in self._scroll.winfo_children(): w.destroy()
        self._cards.clear()
        if not rows:
            ctk.CTkLabel(self._scroll,
                text="Nenhuma peça encontrada.\nTente outro termo ou cadastre a peça.",
                font=ctk.CTkFont(size=14), text_color=MUTED, justify="center").pack(pady=60)
            self._lbl_count.configure(text="0 peças"); return
        alertas = 0
        for r in rows:
            d = {k: r[i] for i,k in enumerate([
                "codigo","nome","localizacao","prateleira","setor","posicao",
                "quantidade","qtd_minima","preco_venda","marca","aplic",
                "fornecedor","preco_custo","categoria","unidade"])}
            if d["quantidade"]==0 or d["quantidade"]<=d["qtd_minima"]: alertas+=1
            card = CardPeca(self._scroll, d, on_click=self._card_clicado)
            card.pack(fill="x", padx=12, pady=4)
            card.bind("<Double-1>", lambda e,dd=d: PopupLocalizacao(self, dd))
            self._cards[d["codigo"]] = card
        n = len(rows)
        av = f"  ·  ⚠ {alertas} com alerta" if alertas else ""
        self._lbl_count.configure(text=f"{n} peça{'s' if n!=1 else ''}{av}")

    def _card_clicado(self, dados):
        if self._selecionado and self._selecionado in self._cards:
            self._cards[self._selecionado].destacar(False)
        self._selecionado = dados.get("codigo","")
        if self._selecionado in self._cards:
            self._cards[self._selecionado].destacar(True)
        self._on_selecionar(dados)

    def atualizar(self): self._buscar()


# ══════════════════════════════════════════════════════════════════════════════
#  JANELA MOVIMENTAÇÃO
# ══════════════════════════════════════════════════════════════════════════════
class JanelaMov(ctk.CTkToplevel):
    def __init__(self, parent, db, dados, callback, tipo_inicial="entrada"):
        super().__init__(parent)
        self.db=db; self.dados=dados; self.callback=callback
        self.title(f"Movimentação — {dados.get('nome','')}"); self.geometry("440x370")
        self.resizable(False,False); self.grab_set(); self.configure(fg_color=BG)
        ctk.CTkLabel(self, text=f"⚙  {dados.get('nome','')}",
                     font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(18,2))
        ctk.CTkLabel(self, text=f"Estoque atual: {dados.get('quantidade',0)} un.", text_color=MUTED).pack()
        self.tipo_var = tk.StringVar(value=tipo_inicial)
        r = ctk.CTkFrame(self, fg_color="transparent"); r.pack(pady=12)
        for txt,val,cor in [("➕ Entrada","entrada",OK),("➖ Saída","saida",ERR),("✏️ Ajuste","ajuste",WARN)]:
            ctk.CTkRadioButton(r,text=txt,variable=self.tipo_var,value=val,text_color=cor).pack(side="left",padx=8)
        ctk.CTkLabel(self, text="Quantidade:", text_color=MUTED).pack()
        self._qty = ctk.CTkEntry(self, placeholder_text="Ex: 5", width=200, height=38)
        self._qty.pack(pady=4); self._qty.focus()
        ctk.CTkLabel(self, text="Motivo (opcional):", text_color=MUTED).pack()
        self._mot = ctk.CTkEntry(self, placeholder_text="NF 1234 / Venda / Quebra", width=340, height=38)
        self._mot.pack(pady=4)
        ctk.CTkButton(self, text="✔  Confirmar", command=self._confirmar,
                      fg_color=ACC, height=42, width=320,
                      font=ctk.CTkFont(size=13,weight="bold")).pack(pady=16)

    def _confirmar(self):
        try:
            qty = int(self._qty.get().strip())
            if qty <= 0: raise ValueError
        except ValueError:
            messagebox.showwarning("Inválido","Quantidade inteira positiva.",parent=self); return
        cod=self.dados.get("codigo",""); tipo=self.tipo_var.get()
        q_atual=self.dados.get("quantidade",0); motivo=self._mot.get().strip()
        if tipo=="entrada":   nova=q_atual+qty
        elif tipo=="saida":
            nova=q_atual-qty
            if nova<0:
                messagebox.showwarning("Insuficiente",f"Atual: {q_atual}. Não é possível remover {qty}.",parent=self); return
        else: nova=qty
        self.db.q("UPDATE pecas SET quantidade=?,atualizado=? WHERE codigo=?",(nova,agora(),cod))
        self.db.q("INSERT INTO movimentacoes(codigo,tipo,quantidade,motivo,usuario,data_hora) VALUES(?,?,?,?,?,?)",
                  (cod,tipo,qty,motivo,"sistema",agora()))
        self.db.commit(); self.destroy(); self.callback()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL EDIÇÃO (direita)
# ══════════════════════════════════════════════════════════════════════════════
class PainelEdicao(ctk.CTkScrollableFrame):
    def __init__(self, master, db, status_cb, refresh_cb, **kw):
        super().__init__(master, width=340, fg_color=CARD, bg_color=CARD,
                          corner_radius=0, border_width=1, border_color=BRD, **kw)
        self.configure(fg_color=CARD)
        self.db=db; self._status=status_cb; self._refresh=refresh_cb
        self.ent: Dict[str,ctk.CTkEntry]={}; self._dados_atuais=None
        self._build()

    def _build(self):
        ctk.CTkLabel(self, text="Cadastro / Edição",
                     font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(14,4),padx=14,anchor="w")

        _lbl_secao(self, "📍  LOCALIZAÇÃO FÍSICA", ACC)
        loc_grid = ctk.CTkFrame(self, fg_color="transparent")
        loc_grid.pack(fill="x", padx=14, pady=2)
        loc_grid.grid_columnconfigure((0,1,2), weight=1)
        for i,(key,ph,dica) in enumerate([("prateleira","Prat.","Ex: Prateleira 1"),
                                           ("setor","Setor","Ex: A"),("posicao","Caixa","Ex: 03")]):
            f=ctk.CTkFrame(loc_grid,fg_color="transparent"); f.grid(row=0,column=i,padx=3,sticky="ew")
            ctk.CTkLabel(f,text=ph,font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w")
            e=ctk.CTkEntry(f,placeholder_text=dica,height=36); e.pack(fill="x")
            self.ent[key]=e; e.bind("<FocusOut>",self._atualizar_local_composto)
        ctk.CTkLabel(self, text="Código de localização:", font=ctk.CTkFont(size=10), text_color=MUTED).pack(anchor="w",padx=14,pady=(6,0))
        self.ent["localizacao"]=ctk.CTkEntry(self,placeholder_text="Ex: P1-A-03",height=36,fg_color=CARD2)
        self.ent["localizacao"].pack(fill="x",padx=14,pady=2)

        _lbl_secao(self, "IDENTIFICAÇÃO")
        row_cod=ctk.CTkFrame(self,fg_color="transparent"); row_cod.pack(fill="x",padx=14,pady=2)
        row_cod.grid_columnconfigure(0,weight=1)
        self.ent["codigo"]=ctk.CTkEntry(row_cod,placeholder_text="Código interno *",height=36)
        self.ent["codigo"].grid(row=0,column=0,sticky="ew",padx=(0,4))
        ctk.CTkButton(row_cod,text="📷",width=36,height=36,command=self._leitor_barcode,
                      fg_color=CARD2).grid(row=0,column=1)
        for key,ph in [("cod_fabricante","Cód. fabricante / EAN"),
                        ("nome","Nome da peça *"),("marca","Marca"),("fornecedor","Fornecedor"),
                        ("categoria","Categoria"),("ncm","NCM (fiscal)")]:
            self.ent[key]=ctk.CTkEntry(self,placeholder_text=ph,height=36)
            self.ent[key].pack(fill="x",padx=14,pady=2)

        _lbl_secao(self, "🚗  APLICA EM (um veículo por linha)")
        self.txt_aplic=ctk.CTkTextbox(self,height=80,corner_radius=6,fg_color=CARD2)
        self.txt_aplic.pack(fill="x",padx=14,pady=2)

        _lbl_secao(self, "ESTOQUE & PREÇOS")
        g2=ctk.CTkFrame(self,fg_color="transparent"); g2.pack(fill="x",padx=14,pady=2)
        g2.grid_columnconfigure((0,1),weight=1)
        for i,(key,ph) in enumerate([("quantidade","Qtd atual"),("qtd_minima","Qtd mínima")]):
            self.ent[key]=ctk.CTkEntry(g2,placeholder_text=ph,height=36)
            self.ent[key].grid(row=0,column=i,padx=3,sticky="ew")
        g3=ctk.CTkFrame(self,fg_color="transparent"); g3.pack(fill="x",padx=14,pady=2)
        g3.grid_columnconfigure((0,1),weight=1)
        for i,(key,ph) in enumerate([("preco_custo","Custo R$"),("preco_venda","Venda R$")]):
            self.ent[key]=ctk.CTkEntry(g3,placeholder_text=ph,height=36)
            self.ent[key].grid(row=0,column=i,padx=3,sticky="ew")

        ctk.CTkLabel(self,text="Observações:",font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w",padx=14,pady=(6,0))
        self.txt_obs=ctk.CTkTextbox(self,height=52,corner_radius=6,fg_color=CARD2)
        self.txt_obs.pack(fill="x",padx=14,pady=2)

        _lbl_secao(self, "AÇÕES")
        for txt,cmd,fg,hv in [
            ("💾  Salvar / Atualizar",self._salvar,ACC,"#1d4ed8"),
            ("➕  Dar Entrada",self._mov_entrada,OK,"#15803d"),
            ("➖  Registrar Saída",self._mov_saida,"#b45309","#92400e"),
            ("🏷  Gerar Etiqueta",self._etiqueta,CARD2,BRD),
            ("🗑  Excluir Peça",self._excluir,ERR,"#b91c1c"),
            ("🧹  Limpar",self._limpar_form,CARD2,BRD),
        ]:
            ctk.CTkButton(self,text=txt,command=cmd,fg_color=fg,hover_color=hv,height=36).pack(fill="x",padx=14,pady=2)

    def _atualizar_local_composto(self, event=None):
        prat=self.ent["prateleira"].get().strip(); setor=self.ent["setor"].get().strip(); pos=self.ent["posicao"].get().strip()
        if prat or setor or pos:
            num=re.sub(r'[^0-9]','',prat) or prat; partes=[]
            if num: partes.append(f"P{num}")
            if setor: partes.append(setor.upper())
            if pos: partes.append(pos.zfill(2))
            self.ent["localizacao"].delete(0,tk.END); self.ent["localizacao"].insert(0,"-".join(partes))

    def carregar(self, dados: dict):
        self._dados_atuais=dados; self._limpar_campos()
        mapa={k:dados.get(k,"") or "" for k in ["codigo","nome","localizacao","prateleira","setor","posicao","marca","fornecedor","categoria","ncm"]}
        mapa["quantidade"]=str(dados.get("quantidade",""))
        mapa["qtd_minima"]=str(dados.get("qtd_minima",""))
        mapa["preco_venda"]=f"{dados.get('preco_venda',0):.2f}".replace(".",",")
        mapa["preco_custo"]=f"{dados.get('preco_custo',0):.2f}".replace(".",",")
        for k,v in mapa.items():
            if k in self.ent:
                self.ent[k].delete(0,tk.END); self.ent[k].insert(0,str(v))
        row=self.db.q("SELECT cod_fabricante,observacoes FROM pecas WHERE codigo=?",(dados.get("codigo",""),)).fetchone()
        if row:
            self.ent["cod_fabricante"].delete(0,tk.END); self.ent["cod_fabricante"].insert(0,row[0] or "")
            self.txt_obs.delete("1.0","end"); self.txt_obs.insert("1.0",row[1] or "")
        apls=self.db.q("SELECT veiculo FROM aplicacoes WHERE codigo=? ORDER BY veiculo",(dados.get("codigo",""),)).fetchall()
        self.txt_aplic.delete("1.0","end"); self.txt_aplic.insert("1.0","\n".join(a[0] for a in apls))

    def _limpar_campos(self):
        for e in self.ent.values(): e.delete(0,tk.END)
        self.txt_aplic.delete("1.0","end"); self.txt_obs.delete("1.0","end")

    def _salvar(self):
        cod=self.ent["codigo"].get().strip(); nome=self.ent["nome"].get().strip()
        if not cod or not nome:
            messagebox.showwarning("Obrigatório","Preencha Código e Nome."); return
        prat=self.ent["prateleira"].get().strip(); setor=self.ent["setor"].get().strip()
        pos=self.ent["posicao"].get().strip(); local=self.ent["localizacao"].get().strip()
        if not local and (prat or setor or pos):
            self._atualizar_local_composto(); local=self.ent["localizacao"].get().strip()
        self.db.q("""INSERT OR REPLACE INTO pecas
            (codigo,nome,localizacao,prateleira,setor,posicao,quantidade,qtd_minima,
             preco_venda,preco_custo,fornecedor,marca,cod_fabricante,categoria,ncm,observacoes,atualizado,ativo)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",(
            cod,nome,local,prat,setor,pos,
            parse_int(self.ent["quantidade"].get()), parse_int(self.ent["qtd_minima"].get()) or 2,
            parse_float(self.ent["preco_venda"].get()), parse_float(self.ent["preco_custo"].get()),
            self.ent["fornecedor"].get().strip(), self.ent["marca"].get().strip(),
            self.ent["cod_fabricante"].get().strip(), self.ent["categoria"].get().strip(),
            self.ent["ncm"].get().strip(), self.txt_obs.get("1.0","end").strip(), agora()))
        self.db.q("DELETE FROM aplicacoes WHERE codigo=?",(cod,))
        for linha in self.txt_aplic.get("1.0","end").strip().splitlines():
            if linha.strip(): self.db.q("INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)",(cod,linha.strip()))
        self.db.commit()
        self._status(f"✅  Peça «{nome}» salva em {_formatar_local(local)}")
        self._refresh()

    def _peca_selecionada(self):
        cod=self.ent["codigo"].get().strip()
        if not cod:
            messagebox.showwarning("Aviso","Selecione uma peça na lista."); return None
        r=self.db.q("SELECT codigo,nome,quantidade,preco_custo,preco_venda FROM pecas WHERE codigo=?",(cod,)).fetchone()
        if not r:
            messagebox.showwarning("Não encontrada",f"Peça {cod} não encontrada."); return None
        return dict(r)

    def _mov_entrada(self):
        d=self._peca_selecionada()
        if d: JanelaMov(self,self.db,d,self._pos_mov,"entrada")

    def _mov_saida(self):
        d=self._peca_selecionada()
        if d: JanelaMov(self,self.db,d,self._pos_mov,"saida")

    def _pos_mov(self):
        self._refresh(); cod=self.ent["codigo"].get().strip()
        if cod:
            r=self.db.q("""SELECT p.codigo,p.nome,p.localizacao,p.prateleira,p.setor,p.posicao,
                                   p.quantidade,p.qtd_minima,p.preco_venda,p.marca,
                                   '' as aplic,p.fornecedor,p.preco_custo,p.categoria,p.unidade
                             FROM pecas p WHERE p.codigo=?""",(cod,)).fetchone()
            if r: self.carregar(dict(r))

    def _excluir(self):
        cod=self.ent["codigo"].get().strip()
        if not cod:
            messagebox.showwarning("Aviso","Selecione uma peça."); return
        if not messagebox.askyesno("Confirmar",f"Excluir a peça {cod}?"): return
        self.db.q("UPDATE pecas SET ativo=0 WHERE codigo=?",(cod,))
        self.db.commit(); self._status(f"🗑  Peça {cod} removida."); self._limpar_form(); self._refresh()

    def _limpar_form(self):
        self._dados_atuais=None; self._limpar_campos()

    def _leitor_barcode(self):
        win=ctk.CTkToplevel(self); win.title("Leitor de Barcode"); win.geometry("380x200")
        win.grab_set(); win.configure(fg_color=BG)
        ctk.CTkLabel(win,text="📷  Passe o leitor USB agora",
                     font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(20,4))
        ctk.CTkLabel(win,text="O leitor age como teclado.",text_color=MUTED).pack()
        ent=ctk.CTkEntry(win,width=300,height=44,font=ctk.CTkFont(size=16)); ent.pack(pady=14); ent.focus()
        def _ok(e=None):
            cod=ent.get().strip()
            if cod:
                self.ent["cod_fabricante"].delete(0,tk.END); self.ent["cod_fabricante"].insert(0,cod)
                if not self.ent["codigo"].get().strip():
                    self.ent["codigo"].delete(0,tk.END); self.ent["codigo"].insert(0,cod)
            win.destroy()
        ent.bind("<Return>",_ok)
        ctk.CTkButton(win,text="Confirmar",command=_ok,fg_color=ACC).pack()

    def _etiqueta(self):
        if DEPS_FALTANDO:
            messagebox.showerror("Libs ausentes",f"Instale: pip install {' '.join(DEPS_FALTANDO)}"); return
        from barcode import Code128; from barcode.writer import ImageWriter
        from PIL import Image, ImageDraw, ImageFont
        cod=self.ent["codigo"].get().strip(); nome=self.ent["nome"].get().strip()
        prat=self.ent["prateleira"].get().strip(); setor=self.ent["setor"].get().strip()
        pos=self.ent["posicao"].get().strip(); local=self.ent["localizacao"].get().strip()
        marca=self.ent["marca"].get().strip()
        partes=[]
        if prat: partes.append(prat)
        if setor: partes.append(f"Setor {setor}")
        if pos: partes.append(f"Cx {pos}")
        loc_txt="  ·  ".join(partes) if partes else _formatar_local(local)
        apls_str=" / ".join([l.strip() for l in self.txt_aplic.get("1.0","end").splitlines() if l.strip()][:3])
        if not cod: messagebox.showwarning("Aviso","Preencha o Código."); return
        try:
            buf=io.BytesIO(); writer=ImageWriter()
            writer.set_options({"module_height":10.0,"module_width":0.7,"font_size":7,"text_distance":3.0,"quiet_zone":4.0,"dpi":200,"write_text":True})
            Code128(cod,writer=writer).write(buf); buf.seek(0)
            img_bc=Image.open(buf).convert("RGB"); W,H_TOP=img_bc.width,120
            cor_rgb=tuple(int(_cor_prateleira(prat or local).lstrip("#")[i:i+2],16) for i in (0,2,4))
            etiqueta=Image.new("RGB",(W,H_TOP+img_bc.height),(255,255,255))
            draw=ImageDraw.Draw(etiqueta)
            def _fnt(sz,bold=False):
                for p in [("arialbd.ttf" if bold else "arial.ttf"),
                           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
                    try: return ImageFont.truetype(p,sz)
                    except: pass
                return ImageFont.load_default()
            draw.rectangle([0,0,W,8],fill=cor_rgb)
            draw.text((10,14),f"📍  {loc_txt}",font=_fnt(15,True),fill=cor_rgb)
            draw.text((10,38),nome,font=_fnt(14,True),fill=(15,15,15))
            y=60
            if marca: draw.text((10,y),f"Marca: {marca}",font=_fnt(11),fill=(80,80,80)); y+=16
            if apls_str: draw.text((10,y),f"Aplica: {apls_str}",font=_fnt(10),fill=(80,80,80)); y+=14
            draw.text((10,y),f"Cód: {cod}",font=_fnt(10),fill=(120,120,120))
            etiqueta.paste(img_bc,(0,H_TOP))
            arq=f"etiqueta_{cod}.png"; etiqueta.save(arq,dpi=(200,200))
            if messagebox.askyesno("Etiqueta gerada ✅",f"Salvo em: {os.path.abspath(arq)}\n\nImprimir agora?"):
                if sys.platform.startswith("win"): os.startfile(arq,"print")
                elif sys.platform=="darwin": os.system(f'lpr "{arq}"')
                else: os.system(f'lpr "{arq}" 2>/dev/null || xdg-open "{arq}"')
        except Exception as exc:
            messagebox.showerror("Erro",f"{type(exc).__name__}: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  PDV — FRENTE DE CAIXA
# ══════════════════════════════════════════════════════════════════════════════
class PainelPDV(ctk.CTkFrame):
    def __init__(self, master, db, usuario, status_cb, refresh_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self.usuario=usuario; self._status=status_cb; self._refresh=refresh_cb
        self._carrinho: List[dict]=[]
        self._build()

    def _build(self):
        self.grid_columnconfigure(0, weight=1); self.grid_columnconfigure(1, weight=0)
        self.grid_rowconfigure(0, weight=1)

        # ── Painel esquerdo: busca + carrinho ────────────────────────────────
        esq=ctk.CTkFrame(self, fg_color=CARD, corner_radius=8); esq.grid(row=0,column=0,sticky="nsew",padx=(12,6),pady=12)
        esq.grid_columnconfigure(0,weight=1); esq.grid_rowconfigure(2,weight=1)

        # Cabeçalho
        cab=ctk.CTkFrame(esq,fg_color=CARD2,corner_radius=6); cab.grid(row=0,column=0,sticky="ew",padx=12,pady=(12,4))
        cab.grid_columnconfigure(0,weight=1)
        ctk.CTkLabel(cab,text="🛒  FRENTE DE CAIXA",font=ctk.CTkFont(size=16,weight="bold"),
                     text_color=ACC).grid(row=0,column=0,padx=14,pady=8,sticky="w")

        # Busca de peça
        busca_row=ctk.CTkFrame(esq,fg_color="transparent"); busca_row.grid(row=1,column=0,sticky="ew",padx=12,pady=4)
        busca_row.grid_columnconfigure(0,weight=1)
        self._busca=ctk.CTkEntry(busca_row,placeholder_text="Buscar peça por nome, código ou carro…",height=38,fg_color=CARD2)
        self._busca.grid(row=0,column=0,sticky="ew",padx=(0,4))
        self._busca.bind("<KeyRelease>",self._buscar_peca)
        ctk.CTkButton(busca_row,text="Limpar",width=70,height=38,fg_color=CARD2,
                      command=lambda:[self._busca.delete(0,tk.END),self._limpar_resultados()]).grid(row=0,column=1)

        # Resultados da busca
        self._frame_res=ctk.CTkScrollableFrame(esq,fg_color=BG,height=200,corner_radius=6)
        self._frame_res.grid(row=2,column=0,sticky="ew",padx=12,pady=4)
        self._frame_res.grid_columnconfigure(0,weight=1)

        # Tabela carrinho
        ctk.CTkLabel(esq,text="Carrinho",font=ctk.CTkFont(size=12,weight="bold"),
                     text_color=MUTED).grid(row=3,column=0,padx=14,pady=(8,2),sticky="w")
        cols=("nome","qtd","preco","desc","sub")
        self.tree=ttk.Treeview(esq,columns=cols,show="headings",style="M.Treeview",height=8)
        for col,(txt,w) in zip(cols,[("Peça",260),("Qtd",50),("Preço",90),("Desc%",60),("Subtotal",90)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.grid(row=4,column=0,sticky="ew",padx=12,pady=4)
        ctk.CTkButton(esq,text="🗑 Remover item",height=32,fg_color=ERR,
                      command=self._remover_item).grid(row=5,column=0,padx=12,pady=(0,4),sticky="w")

        # ── Painel direito: resumo + pagamento ───────────────────────────────
        dir=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8,width=280); dir.grid(row=0,column=1,sticky="nsew",padx=(0,12),pady=12)
        dir.grid_propagate(False); dir.grid_columnconfigure(0,weight=1)

        ctk.CTkLabel(dir,text="RESUMO",font=ctk.CTkFont(size=13,weight="bold"),
                     text_color=MUTED).pack(pady=(14,4),padx=14,anchor="w")

        self._lbl_sub=ctk.CTkLabel(dir,text="Subtotal: R$ 0,00",text_color=TXT)
        self._lbl_sub.pack(padx=14,anchor="w")

        ctk.CTkLabel(dir,text="Desconto %:",text_color=MUTED,font=ctk.CTkFont(size=10)).pack(padx=14,pady=(10,0),anchor="w")
        self._ent_desc=ctk.CTkEntry(dir,placeholder_text="0",height=36,width=120)
        self._ent_desc.pack(padx=14,pady=2,anchor="w")
        self._ent_desc.bind("<KeyRelease>",lambda e:self._atualizar_total())

        self._lbl_total=ctk.CTkLabel(dir,text="TOTAL: R$ 0,00",
                                      font=ctk.CTkFont(size=18,weight="bold"),text_color=OK)
        self._lbl_total.pack(padx=14,pady=8)

        ctk.CTkFrame(dir,height=1,fg_color=BRD).pack(fill="x",padx=14,pady=4)
        ctk.CTkLabel(dir,text="Forma de pagamento:",text_color=MUTED,font=ctk.CTkFont(size=10)).pack(padx=14,anchor="w")
        self._forma=tk.StringVar(value="Dinheiro")
        for f in ["Dinheiro","PIX","Débito","Crédito","Crediário"]:
            ctk.CTkRadioButton(dir,text=f,variable=self._forma,value=f,
                               text_color=TXT,font=ctk.CTkFont(size=11)).pack(padx=20,pady=1,anchor="w")

        ctk.CTkLabel(dir,text="Cliente (opcional):",text_color=MUTED,font=ctk.CTkFont(size=10)).pack(padx=14,pady=(10,0),anchor="w")
        self._ent_cliente=ctk.CTkEntry(dir,placeholder_text="Nome do cliente",height=34)
        self._ent_cliente.pack(padx=14,fill="x",pady=2)

        ctk.CTkFrame(dir,height=1,fg_color=BRD).pack(fill="x",padx=14,pady=8)

        ctk.CTkButton(dir,text="✅  FECHAR VENDA",height=46,
                      fg_color=OK,hover_color="#15803d",
                      font=ctk.CTkFont(size=14,weight="bold"),
                      command=self._fechar_venda).pack(fill="x",padx=14,pady=4)
        ctk.CTkButton(dir,text="📋  Gerar Orçamento",height=36,
                      fg_color=ACC2,command=self._gerar_orcamento).pack(fill="x",padx=14,pady=2)
        ctk.CTkButton(dir,text="🧹  Limpar Carrinho",height=34,
                      fg_color=CARD2,command=self._limpar_carrinho).pack(fill="x",padx=14,pady=2)

    def _buscar_peca(self, event=None):
        self._limpar_resultados()
        termo=self._busca.get().strip()
        if len(termo)<2: return
        rows=self.db.buscar_pecas(termo=termo)[:12]
        for r in rows:
            d={k:r[i] for i,k in enumerate(["codigo","nome","localizacao","prateleira","setor","posicao","quantidade","qtd_minima","preco_venda","marca","aplic","fornecedor","preco_custo","categoria","unidade"])}
            linha=ctk.CTkFrame(self._frame_res,fg_color=CARD2,corner_radius=6)
            linha.pack(fill="x",pady=2,padx=2)
            cor=OK if d["quantidade"]>d["qtd_minima"] else (WARN if d["quantidade"]>0 else ERR)
            txt=f"#{d['codigo']}  {d['nome'][:45]}  [{d['quantidade']} un] — {fmt_brl(d['preco_venda'])}"
            lbl=ctk.CTkLabel(linha,text=txt,font=ctk.CTkFont(size=11),text_color=TXT,anchor="w")
            lbl.pack(side="left",padx=8,pady=6,fill="x",expand=True)
            lbl.bind("<Button-1>",lambda e,dd=d:self._adicionar_item(dd))
            linha.bind("<Button-1>",lambda e,dd=d:self._adicionar_item(dd))

    def _limpar_resultados(self):
        for w in self._frame_res.winfo_children(): w.destroy()

    def _adicionar_item(self, dados: dict):
        cod=dados["codigo"]
        for item in self._carrinho:
            if item["codigo"]==cod:
                if item["quantidade"]>=dados["quantidade"]:
                    messagebox.showwarning("Estoque insuficiente",f"Máx: {dados['quantidade']} un."); return
                item["quantidade"]+=1
                item["subtotal"]=item["quantidade"]*item["preco_unit"]*(1-item["desconto"]/100)
                self._atualizar_tree(); self._atualizar_total(); return
        if dados["quantidade"]<=0:
            if not messagebox.askyesno("Sem estoque","Esta peça está zerada. Adicionar mesmo assim?"): return
        self._carrinho.append({
            "codigo":cod,"nome":dados["nome"],"quantidade":1,
            "preco_unit":dados["preco_venda"],"desconto":0.0,
            "subtotal":dados["preco_venda"],"estoque":dados["quantidade"]
        })
        self._atualizar_tree(); self._atualizar_total()
        self._busca.delete(0,tk.END); self._limpar_resultados()

    def _remover_item(self):
        sel=self.tree.selection()
        if not sel: return
        idx=self.tree.index(sel[0])
        if 0<=idx<len(self._carrinho): self._carrinho.pop(idx)
        self._atualizar_tree(); self._atualizar_total()

    def _atualizar_tree(self):
        self.tree.delete(*self.tree.get_children())
        for item in self._carrinho:
            self.tree.insert("","end",values=(
                item["nome"][:40],item["quantidade"],
                fmt_brl(item["preco_unit"]),f"{item['desconto']:.0f}%",fmt_brl(item["subtotal"])))

    def _atualizar_total(self):
        subtotal=sum(i["subtotal"] for i in self._carrinho)
        try: desc=float(self._ent_desc.get().strip() or "0")
        except: desc=0.0
        total=subtotal*(1-desc/100)
        self._lbl_sub.configure(text=f"Subtotal: {fmt_brl(subtotal)}")
        self._lbl_total.configure(text=f"TOTAL: {fmt_brl(total)}")

    def _calcular_total(self):
        subtotal=sum(i["subtotal"] for i in self._carrinho)
        try: desc=float(self._ent_desc.get().strip() or "0")
        except: desc=0.0
        return subtotal*(1-desc/100), desc

    def _fechar_venda(self):
        if not self._carrinho:
            messagebox.showwarning("Carrinho vazio","Adicione peças ao carrinho."); return
        total, desc = self._calcular_total()
        forma=self._forma.get(); cliente=self._ent_cliente.get().strip()
        num=self.db.prox_numero("prox_pedido","PED")
        if not messagebox.askyesno("Confirmar venda",
            f"Pedido: {num}\nTotal: {fmt_brl(total)}\nPagamento: {forma}\n\nConfirmar?"): return
        self.db.q("""INSERT INTO pedidos(numero,cliente_nome,status,forma_pagto,desconto_pct,total,total_pago,usuario,criado,atualizado)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (num,cliente,"concluido",forma,desc,total,total,self.usuario,agora(),agora()))
        ped_id=self.db.q("SELECT id FROM pedidos WHERE numero=?",(num,)).fetchone()[0]
        for item in self._carrinho:
            self.db.q("INSERT INTO pedido_itens(ped_id,codigo,nome,quantidade,preco_unit,desconto,subtotal) VALUES(?,?,?,?,?,?,?)",
                      (ped_id,item["codigo"],item["nome"],item["quantidade"],
                       item["preco_unit"],item["desconto"],item["subtotal"]))
            self.db.q("UPDATE pecas SET quantidade=MAX(0,quantidade-?),atualizado=? WHERE codigo=?",
                      (item["quantidade"],agora(),item["codigo"]))
            self.db.q("INSERT INTO movimentacoes(codigo,tipo,quantidade,motivo,usuario,data_hora) VALUES(?,?,?,?,?,?)",
                      (item["codigo"],"saida",item["quantidade"],f"Venda {num}",self.usuario,agora()))
        try:
            desc_valor=sum(i["subtotal"] for i in self._carrinho)-total
            venc=(datetime.date.today()+datetime.timedelta(days=30 if forma=="Crediário" else 0)).isoformat()
            self.db.q("""INSERT INTO contas_receber(descricao,cliente_nome,pedido_ref,valor,valor_pago,vencimento,pagamento,status)
                         VALUES(?,?,?,?,?,?,?,?)""",
                      (f"Venda {num}",cliente,num,total,
                       total if forma!="Crediário" else 0.0,
                       venc if forma=="Crediário" else agora(),
                       forma if forma!="Crediário" else "",
                       "quitado" if forma!="Crediário" else "aberto"))
        except: pass
        self.db.commit()
        auditar(self.usuario,f"VENDA {num}",f"Total: {fmt_brl(total)} | {forma}")
        self._status(f"✅  Venda {num} fechada — {fmt_brl(total)}")
        self._refresh(); self._limpar_carrinho()
        messagebox.showinfo("✅  Venda concluída",f"Pedido: {num}\nTotal: {fmt_brl(total)}\nPagamento: {forma}")

    def _gerar_orcamento(self):
        if not self._carrinho:
            messagebox.showwarning("Carrinho vazio","Adicione peças."); return
        total,desc=self._calcular_total(); cliente=self._ent_cliente.get().strip()
        num=self.db.prox_numero("prox_orcamento","ORC")
        self.db.q("""INSERT INTO orcamentos(numero,cliente_nome,status,desconto_pct,total,usuario,criado,atualizado)
                     VALUES(?,?,?,?,?,?,?,?)""",(num,cliente,"aberto",desc,total,self.usuario,agora(),agora()))
        orc_id=self.db.q("SELECT id FROM orcamentos WHERE numero=?",(num,)).fetchone()[0]
        for item in self._carrinho:
            self.db.q("INSERT INTO orcamento_itens(orc_id,codigo,nome,quantidade,preco_unit,desconto,subtotal) VALUES(?,?,?,?,?,?,?)",
                      (orc_id,item["codigo"],item["nome"],item["quantidade"],item["preco_unit"],item["desconto"],item["subtotal"]))
        self.db.commit()
        self._status(f"📋  Orçamento {num} gerado — {fmt_brl(total)}")
        messagebox.showinfo("Orçamento gerado",f"Número: {num}\nTotal: {fmt_brl(total)}\nStatus: Aberto")

    def _limpar_carrinho(self):
        self._carrinho.clear(); self._atualizar_tree(); self._atualizar_total()
        self._ent_desc.delete(0,tk.END); self._ent_cliente.delete(0,tk.END)


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL ORÇAMENTOS / PEDIDOS (genérico)
# ══════════════════════════════════════════════════════════════════════════════
class PainelDocumentos(ctk.CTkFrame):
    """Serve tanto para orçamentos quanto para pedidos de venda."""
    def __init__(self, master, db, tipo, status_cb, refresh_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self.tipo=tipo; self._status=status_cb; self._refresh=refresh_cb
        self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)
        titulo = "📋  Orçamentos" if self.tipo=="orcamento" else "🛒  Pedidos de Venda"
        tabela = "orcamentos" if self.tipo=="orcamento" else "pedidos"
        itens_tab = "orcamento_itens" if self.tipo=="orcamento" else "pedido_itens"
        fk = "orc_id" if self.tipo=="orcamento" else "ped_id"

        # Filtros
        frow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); frow.grid(row=0,column=0,sticky="ew",padx=12,pady=(12,4))
        frow.grid_columnconfigure(1,weight=1)
        ctk.CTkLabel(frow,text=titulo,font=ctk.CTkFont(size=16,weight="bold"),text_color=ACC).grid(row=0,column=0,padx=14,pady=10,sticky="w")
        self._busca=ctk.CTkEntry(frow,placeholder_text="Buscar por número ou cliente…",height=34,fg_color=CARD2)
        self._busca.grid(row=0,column=1,padx=8,pady=10,sticky="ew")
        self._busca.bind("<KeyRelease>",lambda e:self._carregar())
        self._status_var=tk.StringVar(value="todos")
        status_vals=["todos","aberto","aprovado","cancelado"] if self.tipo=="orcamento" else ["todos","pendente","concluido","cancelado"]
        ctk.CTkOptionMenu(frow,variable=self._status_var,values=status_vals,
                          width=130,height=34,command=lambda _:self._carregar()).grid(row=0,column=2,padx=(0,14),pady=10)

        # Tabela
        if self.tipo=="orcamento":
            cols=("numero","cliente_nome","status","desconto_pct","total","criado")
            hdrs=[("Número",90),("Cliente",200),("Status",90),("Desc%",60),("Total",100),("Criado",140)]
        else:
            cols=("numero","cliente_nome","status","forma_pagto","desconto_pct","total","criado")
            hdrs=[("Número",90),("Cliente",180),("Status",90),("Pagto",90),("Desc%",55),("Total",100),("Criado",130)]

        self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,hdrs):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.tag_configure("aberto",    foreground="#60a5fa")
        self.tree.tag_configure("aprovado",  foreground="#4ade80")
        self.tree.tag_configure("pendente",  foreground="#fbbf24")
        self.tree.tag_configure("concluido", foreground="#4ade80")
        self.tree.tag_configure("cancelado", foreground="#f87171")
        self.tree.grid(row=1,column=0,sticky="nsew",padx=12,pady=4)

        # Ações
        arow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); arow.grid(row=2,column=0,sticky="ew",padx=12,pady=(4,12))
        btns=[]
        if self.tipo=="orcamento":
            btns=[("✅ Aprovar","#15803d",self._aprovar),
                  ("🔄 → Pedido",ACC,self._converter_pedido),
                  ("❌ Cancelar",ERR,self._cancelar)]
        else:
            btns=[("✅ Concluir",OK,self._concluir),
                  ("❌ Cancelar",ERR,self._cancelar)]
        btns.append(("📊 PDF",CARD2,self._exportar_pdf))
        for txt,cor,cmd in btns:
            ctk.CTkButton(arow,text=txt,command=cmd,fg_color=cor,height=32,width=120).pack(side="left",padx=4,pady=8)

        self._lbl=ctk.CTkLabel(arow,text="",text_color=MUTED,font=ctk.CTkFont(size=11))
        self._lbl.pack(side="right",padx=14)
        self._carregar()

    def _carregar(self):
        self.tree.delete(*self.tree.get_children())
        tabela = "orcamentos" if self.tipo=="orcamento" else "pedidos"
        conds=[]; params={}
        busca=self._busca.get().strip() if hasattr(self,"_busca") else ""
        if busca:
            conds.append("(numero LIKE :b OR cliente_nome LIKE :b)"); params["b"]=f"%{busca}%"
        st=self._status_var.get()
        if st!="todos": conds.append("status=:s"); params["s"]=st
        where="WHERE "+" AND ".join(conds) if conds else ""
        if self.tipo=="orcamento":
            rows=self.db.q(f"SELECT numero,cliente_nome,status,desconto_pct,total,criado FROM orcamentos {where} ORDER BY id DESC LIMIT 200",params).fetchall()
        else:
            rows=self.db.q(f"SELECT numero,cliente_nome,status,forma_pagto,desconto_pct,total,criado FROM pedidos {where} ORDER BY id DESC LIMIT 200",params).fetchall()
        for r in rows:
            vals=list(r)
            vals[-1]=(vals[-1] or "")[:16]  # trunca data
            # formata total
            idx_total=4 if self.tipo=="orcamento" else 5
            vals[idx_total]=fmt_brl(vals[idx_total])
            tag=vals[2] if vals[2] in ("aberto","aprovado","cancelado","pendente","concluido") else ""
            self.tree.insert("","end",values=tuple(vals),tags=(tag,))
        self._lbl.configure(text=f"{len(rows)} registro(s)")

    def _sel_numero(self):
        sel=self.tree.selection()
        if not sel: return None
        return self.tree.item(sel[0])["values"][0]

    def _aprovar(self):
        n=self._sel_numero()
        if not n: return
        self.db.q("UPDATE orcamentos SET status='aprovado',atualizado=? WHERE numero=?",(agora(),n))
        self.db.commit(); self._carregar()

    def _converter_pedido(self):
        n=self._sel_numero()
        if not n: return
        orc=self.db.q("SELECT * FROM orcamentos WHERE numero=?",(n,)).fetchone()
        if not orc: return
        num_ped=self.db.prox_numero("prox_pedido","PED")
        self.db.q("""INSERT INTO pedidos(numero,cliente_id,cliente_nome,status,desconto_pct,total,orc_origem,usuario,criado,atualizado)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (num_ped,orc["cliente_id"] or None,orc["cliente_nome"],"pendente",
                   orc["desconto_pct"],orc["total"],n,orc["usuario"],agora(),agora()))
        ped_id=self.db.q("SELECT id FROM pedidos WHERE numero=?",(num_ped,)).fetchone()[0]
        for item in self.db.q("SELECT * FROM orcamento_itens WHERE orc_id=?",(orc["id"],)).fetchall():
            self.db.q("INSERT INTO pedido_itens(ped_id,codigo,nome,quantidade,preco_unit,desconto,subtotal) VALUES(?,?,?,?,?,?,?)",
                      (ped_id,item["codigo"],item["nome"],item["quantidade"],item["preco_unit"],item["desconto"],item["subtotal"]))
        self.db.q("UPDATE orcamentos SET status='aprovado',atualizado=? WHERE numero=?",(agora(),n))
        self.db.commit(); self._carregar()
        self._status(f"✅  Orçamento {n} convertido em Pedido {num_ped}")
        messagebox.showinfo("Pedido criado",f"Pedido {num_ped} criado a partir do orçamento {n}.")

    def _concluir(self):
        n=self._sel_numero()
        if not n: return
        self.db.q("UPDATE pedidos SET status='concluido',atualizado=? WHERE numero=?",(agora(),n))
        self.db.commit(); self._carregar()

    def _cancelar(self):
        n=self._sel_numero()
        if not n: return
        if not messagebox.askyesno("Cancelar",f"Cancelar {n}?"): return
        tabela="orcamentos" if self.tipo=="orcamento" else "pedidos"
        self.db.q(f"UPDATE {tabela} SET status='cancelado',atualizado=? WHERE numero=?",(agora(),n))
        self.db.commit(); self._carregar()

    def _exportar_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4,landscape
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import cm
        except ImportError:
            messagebox.showerror("Erro","pip install reportlab"); return
        tabela="orcamentos" if self.tipo=="orcamento" else "pedidos"
        label="Orçamentos" if self.tipo=="orcamento" else "Pedidos"
        nome=f"mecatrack_{tabela}_{hoje()}.pdf"
        if self.tipo=="orcamento":
            rows=self.db.q("SELECT numero,cliente_nome,status,desconto_pct,total,criado FROM orcamentos ORDER BY id DESC LIMIT 300").fetchall()
            hdrs=["Número","Cliente","Status","Desc%","Total","Criado"]
        else:
            rows=self.db.q("SELECT numero,cliente_nome,status,forma_pagto,desconto_pct,total,criado FROM pedidos ORDER BY id DESC LIMIT 300").fetchall()
            hdrs=["Número","Cliente","Status","Pagto","Desc%","Total","Criado"]
        doc=SimpleDocTemplate(nome,pagesize=landscape(A4),leftMargin=1*cm,rightMargin=1*cm,topMargin=1.5*cm,bottomMargin=1*cm)
        styles=getSampleStyleSheet()
        data=[hdrs]+[[str(c) for c in r] for r in rows]
        t=Table(data)
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A8A")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),8),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#EFF6FF")]),
            ("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#CBD5E1")),
        ]))
        doc.build([Paragraph(f"<b>MecaTrack ERP — {label}</b>",styles["Title"]),
                   Paragraph(f"Gerado: {agora()}",styles["Normal"]),Spacer(1,0.5*cm),t])
        messagebox.showinfo("PDF gerado",f"Salvo em:\n{os.path.abspath(nome)}")


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL COMPRAS
# ══════════════════════════════════════════════════════════════════════════════
class PainelCompras(ctk.CTkFrame):
    def __init__(self, master, db, usuario, status_cb, refresh_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self.usuario=usuario; self._status=status_cb; self._refresh=refresh_cb
        self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)

        frow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); frow.grid(row=0,column=0,sticky="ew",padx=12,pady=(12,4))
        frow.grid_columnconfigure(1,weight=1)
        ctk.CTkLabel(frow,text="📦  Pedidos de Compra",font=ctk.CTkFont(size=16,weight="bold"),text_color=PURP).grid(row=0,column=0,padx=14,pady=10,sticky="w")
        self._busca=ctk.CTkEntry(frow,placeholder_text="Buscar…",height=34,fg_color=CARD2)
        self._busca.grid(row=0,column=1,padx=8,pady=10,sticky="ew")
        self._busca.bind("<KeyRelease>",lambda e:self._carregar())
        self._st=tk.StringVar(value="todos")
        ctk.CTkOptionMenu(frow,variable=self._st,values=["todos","pendente","recebido","cancelado"],
                          width=120,height=34,command=lambda _:self._carregar()).grid(row=0,column=2,padx=(0,14),pady=10)

        cols=("numero","fornecedor_nome","status","total","previsao","criado")
        self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,[("Número",90),("Fornecedor",200),("Status",90),("Total",100),("Previsão",110),("Criado",140)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.tag_configure("pendente",foreground="#fbbf24")
        self.tree.tag_configure("recebido",foreground="#4ade80")
        self.tree.tag_configure("cancelado",foreground="#f87171")
        self.tree.grid(row=1,column=0,sticky="nsew",padx=12,pady=4)

        arow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); arow.grid(row=2,column=0,sticky="ew",padx=12,pady=(4,12))
        ctk.CTkButton(arow,text="➕ Novo Pedido",fg_color=PURP,height=34,command=self._novo).pack(side="left",padx=4,pady=8)
        ctk.CTkButton(arow,text="✅ Marcar Recebido",fg_color=OK,height=34,command=self._receber).pack(side="left",padx=4,pady=8)
        ctk.CTkButton(arow,text="❌ Cancelar",fg_color=ERR,height=34,command=self._cancelar).pack(side="left",padx=4,pady=8)
        self._lbl=ctk.CTkLabel(arow,text="",text_color=MUTED,font=ctk.CTkFont(size=11)); self._lbl.pack(side="right",padx=14)
        self._carregar()

    def _carregar(self):
        self.tree.delete(*self.tree.get_children())
        conds=[]; params={}
        busca=self._busca.get().strip()
        if busca: conds.append("(numero LIKE :b OR fornecedor_nome LIKE :b)"); params["b"]=f"%{busca}%"
        st=self._st.get()
        if st!="todos": conds.append("status=:s"); params["s"]=st
        where="WHERE "+" AND ".join(conds) if conds else ""
        rows=self.db.q(f"SELECT numero,fornecedor_nome,status,total,previsao,criado FROM pedidos_compra {where} ORDER BY id DESC LIMIT 200",params).fetchall()
        for r in rows:
            vals=list(r); vals[3]=fmt_brl(vals[3]); vals[-1]=(vals[-1] or "")[:16]
            self.tree.insert("","end",values=tuple(vals),tags=(vals[2],))
        self._lbl.configure(text=f"{len(rows)} pedido(s)")

    def _novo(self):
        JanelaNovaCompra(self,self.db,self.usuario,self._status,lambda:[self._carregar(),self._refresh()])

    def _receber(self):
        sel=self.tree.selection()
        if not sel: return
        n=self.tree.item(sel[0])["values"][0]
        if not messagebox.askyesno("Confirmar","Marcar como recebido e dar entrada no estoque?"): return
        compra=self.db.q("SELECT id FROM pedidos_compra WHERE numero=?",(n,)).fetchone()
        if not compra: return
        items=self.db.q("SELECT codigo,quantidade FROM compra_itens WHERE compra_id=?",(compra[0],)).fetchall()
        for cod,qty in items:
            self.db.q("UPDATE pecas SET quantidade=quantidade+?,atualizado=? WHERE codigo=?",(qty,agora(),cod))
            self.db.q("INSERT INTO movimentacoes(codigo,tipo,quantidade,motivo,usuario,data_hora) VALUES(?,?,?,?,?,?)",
                      (cod,"entrada",qty,f"Compra {n}",self.usuario,agora()))
        self.db.q("UPDATE pedidos_compra SET status='recebido' WHERE numero=?",(n,))
        self.db.commit(); self._carregar(); self._refresh()
        self._status(f"✅  Compra {n} recebida — estoque atualizado.")

    def _cancelar(self):
        sel=self.tree.selection()
        if not sel: return
        n=self.tree.item(sel[0])["values"][0]
        if not messagebox.askyesno("Cancelar",f"Cancelar pedido {n}?"): return
        self.db.q("UPDATE pedidos_compra SET status='cancelado' WHERE numero=?",(n,))
        self.db.commit(); self._carregar()


class JanelaNovaCompra(ctk.CTkToplevel):
    def __init__(self, parent, db, usuario, status_cb, callback):
        super().__init__(parent)
        self.db=db; self.usuario=usuario; self._status=status_cb; self.callback=callback
        self.title("Nova Ordem de Compra"); self.geometry("680x560"); self.grab_set(); self.configure(fg_color=BG)
        self._itens: List[dict]=[]
        self._build()

    def _build(self):
        ctk.CTkLabel(self,text="📦  Nova Ordem de Compra",font=ctk.CTkFont(size=16,weight="bold"),text_color=PURP).pack(pady=(14,8),padx=20,anchor="w")
        f=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); f.pack(fill="x",padx=20,pady=4)
        f.grid_columnconfigure((0,1,2),weight=1)
        for i,(key,ph) in enumerate([("fornecedor","Fornecedor *"),("previsao","Previsão (AAAA-MM-DD)"),("obs","Observações")]):
            ctk.CTkLabel(f,text=ph,font=ctk.CTkFont(size=10),text_color=MUTED).grid(row=0,column=i,padx=8,pady=(8,0),sticky="w")
        self._forn=ctk.CTkEntry(f,placeholder_text="Nome do fornecedor",height=34); self._forn.grid(row=1,column=0,padx=8,pady=(0,8),sticky="ew")
        self._prev=ctk.CTkEntry(f,placeholder_text=hoje(),height=34); self._prev.grid(row=1,column=1,padx=8,pady=(0,8),sticky="ew")
        self._obs=ctk.CTkEntry(f,placeholder_text="Observação",height=34); self._obs.grid(row=1,column=2,padx=8,pady=(0,8),sticky="ew")

        ctk.CTkLabel(self,text="Adicionar peça:",font=ctk.CTkFont(size=11),text_color=MUTED).pack(anchor="w",padx=20,pady=(8,0))
        ar=ctk.CTkFrame(self,fg_color="transparent"); ar.pack(fill="x",padx=20,pady=2); ar.grid_columnconfigure(0,weight=1)
        self._busca_p=ctk.CTkEntry(ar,placeholder_text="Código ou nome da peça",height=34,fg_color=CARD2)
        self._busca_p.grid(row=0,column=0,sticky="ew",padx=(0,4)); self._busca_p.bind("<KeyRelease>",self._buscar)
        self._qty_ent=ctk.CTkEntry(ar,placeholder_text="Qtd",height=34,width=70); self._qty_ent.grid(row=0,column=1,padx=(0,4))
        self._preco_ent=ctk.CTkEntry(ar,placeholder_text="Preço",height=34,width=90); self._preco_ent.grid(row=0,column=2,padx=(0,4))
        ctk.CTkButton(ar,text="Adicionar",height=34,fg_color=PURP,command=self._add_item).grid(row=0,column=3)

        self._frame_res=ctk.CTkScrollableFrame(self,fg_color=BG,height=120,corner_radius=6); self._frame_res.pack(fill="x",padx=20,pady=2)
        self._frame_res.grid_columnconfigure(0,weight=1)

        cols=("codigo","nome","qtd","preco","sub")
        self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview",height=6)
        for col,(txt,w) in zip(cols,[("Código",90),("Peça",250),("Qtd",60),("Preço",90),("Subtotal",90)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.pack(fill="x",padx=20,pady=4)
        ctk.CTkButton(self,text="🗑 Remover",fg_color=ERR,height=30,command=self._rem_item).pack(anchor="w",padx=20)

        self._lbl_total=ctk.CTkLabel(self,text="Total: R$ 0,00",font=ctk.CTkFont(size=14,weight="bold"),text_color=PURP)
        self._lbl_total.pack(pady=4)
        ctk.CTkButton(self,text="✅  Criar Pedido de Compra",height=42,fg_color=PURP,
                      font=ctk.CTkFont(size=13,weight="bold"),command=self._criar).pack(fill="x",padx=20,pady=8)

    def _buscar(self, event=None):
        for w in self._frame_res.winfo_children(): w.destroy()
        t=self._busca_p.get().strip()
        if len(t)<2: return
        for r in self.db.buscar_pecas(termo=t)[:8]:
            d={k:r[i] for i,k in enumerate(["codigo","nome","localizacao","prateleira","setor","posicao","quantidade","qtd_minima","preco_venda","marca","aplic","fornecedor","preco_custo","categoria","unidade"])}
            linha=ctk.CTkFrame(self._frame_res,fg_color=CARD2,corner_radius=4)
            linha.pack(fill="x",pady=1)
            lbl=ctk.CTkLabel(linha,text=f"#{d['codigo']}  {d['nome'][:50]}  [Custo: {fmt_brl(d['preco_custo'])}]",
                              text_color=TXT,font=ctk.CTkFont(size=11),anchor="w")
            lbl.pack(side="left",padx=8,pady=4,fill="x",expand=True)
            lbl.bind("<Button-1>",lambda e,dd=d: self._selecionar(dd))
            linha.bind("<Button-1>",lambda e,dd=d: self._selecionar(dd))

    def _selecionar(self, d):
        self._busca_p.delete(0,tk.END); self._busca_p.insert(0,d["codigo"])
        self._preco_ent.delete(0,tk.END); self._preco_ent.insert(0,f"{d['preco_custo']:.2f}".replace(".",","))
        for w in self._frame_res.winfo_children(): w.destroy()

    def _add_item(self):
        cod=self._busca_p.get().strip()
        if not cod: return
        r=self.db.q("SELECT codigo,nome,preco_custo FROM pecas WHERE codigo=?",(cod,)).fetchone()
        if not r: messagebox.showwarning("Não encontrada",f"Peça {cod} não encontrada."); return
        qty=parse_int(self._qty_ent.get()) or 1
        preco=parse_float(self._preco_ent.get()) or (r["preco_custo"] or 0.0)
        for item in self._itens:
            if item["codigo"]==cod: item["quantidade"]+=qty; item["subtotal"]=item["quantidade"]*item["preco"]; self._atualizar_tree(); return
        self._itens.append({"codigo":cod,"nome":r["nome"],"quantidade":qty,"preco":preco,"subtotal":qty*preco})
        self._atualizar_tree()
        self._busca_p.delete(0,tk.END); self._qty_ent.delete(0,tk.END); self._preco_ent.delete(0,tk.END)

    def _rem_item(self):
        sel=self.tree.selection()
        if not sel: return
        idx=self.tree.index(sel[0])
        if 0<=idx<len(self._itens): self._itens.pop(idx); self._atualizar_tree()

    def _atualizar_tree(self):
        self.tree.delete(*self.tree.get_children())
        for item in self._itens:
            self.tree.insert("","end",values=(item["codigo"],item["nome"],item["quantidade"],fmt_brl(item["preco"]),fmt_brl(item["subtotal"])))
        total=sum(i["subtotal"] for i in self._itens)
        self._lbl_total.configure(text=f"Total: {fmt_brl(total)}")

    def _criar(self):
        if not self._itens: messagebox.showwarning("Vazio","Adicione peças."); return
        forn=self._forn.get().strip()
        if not forn: messagebox.showwarning("Obrigatório","Informe o fornecedor."); return
        total=sum(i["subtotal"] for i in self._itens)
        num=self.db.prox_numero("prox_compra","CMP")
        self.db.q("INSERT INTO pedidos_compra(numero,fornecedor_nome,status,total,previsao,observacoes,usuario,criado) VALUES(?,?,?,?,?,?,?,?)",
                  (num,forn,"pendente",total,self._prev.get().strip(),self._obs.get().strip(),self.usuario,agora()))
        cmp_id=self.db.q("SELECT id FROM pedidos_compra WHERE numero=?",(num,)).fetchone()[0]
        for item in self._itens:
            self.db.q("INSERT INTO compra_itens(compra_id,codigo,nome,quantidade,preco_unit,subtotal) VALUES(?,?,?,?,?,?)",
                      (cmp_id,item["codigo"],item["nome"],item["quantidade"],item["preco"],item["subtotal"]))
        # Contas a pagar
        venc=(datetime.date.today()+datetime.timedelta(days=30)).isoformat()
        self.db.q("INSERT INTO contas_pagar(descricao,fornecedor_nome,compra_ref,valor,vencimento,status) VALUES(?,?,?,?,?,?)",
                  (f"Compra {num}",forn,num,total,venc,"aberto"))
        self.db.commit()
        self._status(f"📦  Pedido de compra {num} criado — {fmt_brl(total)}")
        self.callback(); self.destroy()
        messagebox.showinfo("Criado ✅",f"Pedido {num} criado com sucesso.\nTotal: {fmt_brl(total)}")


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL FINANCEIRO
# ══════════════════════════════════════════════════════════════════════════════
class PainelFinanceiro(ctk.CTkFrame):
    def __init__(self, master, db, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._status=status_cb
        self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)
        ctk.CTkLabel(self,text="💰  Financeiro",font=ctk.CTkFont(size=18,weight="bold"),
                     text_color=OK).grid(row=0,column=0,padx=18,pady=(14,4),sticky="w")
        self._tabs=ctk.CTkTabview(self,fg_color=CARD,corner_radius=8)
        self._tabs.grid(row=1,column=0,sticky="nsew",padx=12,pady=4)
        self._tabs.add("Contas a Receber"); self._tabs.add("Contas a Pagar"); self._tabs.add("Resumo")
        self._build_receber(self._tabs.tab("Contas a Receber"))
        self._build_pagar(self._tabs.tab("Contas a Pagar"))
        self._build_resumo(self._tabs.tab("Resumo"))

    def _build_receber(self, parent):
        parent.grid_columnconfigure(0,weight=1); parent.grid_rowconfigure(1,weight=1)
        frow=ctk.CTkFrame(parent,fg_color=CARD2,corner_radius=6); frow.grid(row=0,column=0,sticky="ew",padx=8,pady=(8,4))
        frow.grid_columnconfigure(0,weight=1)
        self._bus_rec=ctk.CTkEntry(frow,placeholder_text="Buscar…",height=34,fg_color=CARD); self._bus_rec.grid(row=0,column=0,padx=8,pady=8,sticky="ew")
        self._bus_rec.bind("<KeyRelease>",lambda e:self._load_receber())
        self._st_rec=tk.StringVar(value="todos")
        ctk.CTkOptionMenu(frow,variable=self._st_rec,values=["todos","aberto","quitado","vencido"],
                          width=110,height=34,command=lambda _:self._load_receber()).grid(row=0,column=1,padx=(0,4),pady=8)
        ctk.CTkButton(frow,text="➕ Novo",height=34,fg_color=OK,command=self._nova_rec).grid(row=0,column=2,padx=(0,8),pady=8)
        cols=("descricao","cliente_nome","valor","vencimento","status","pedido_ref")
        self.tree_rec=ttk.Treeview(parent,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,[("Descrição",200),("Cliente",160),("Valor",90),("Vencimento",110),("Status",80),("Referência",100)]):
            self.tree_rec.heading(col,text=txt); self.tree_rec.column(col,width=w)
        self.tree_rec.tag_configure("aberto",foreground="#60a5fa")
        self.tree_rec.tag_configure("quitado",foreground="#4ade80")
        self.tree_rec.tag_configure("vencido",foreground="#f87171")
        self.tree_rec.grid(row=1,column=0,sticky="nsew",padx=8,pady=4)
        ctk.CTkButton(parent,text="✅ Quitar selecionado",height=34,fg_color=OK,
                      command=self._quitar_rec).grid(row=2,column=0,padx=8,pady=(4,8),sticky="w")
        self._load_receber()

    def _load_receber(self):
        self.tree_rec.delete(*self.tree_rec.get_children())
        conds=[]; params={}
        b=self._bus_rec.get().strip()
        if b: conds.append("(descricao LIKE :b OR cliente_nome LIKE :b OR pedido_ref LIKE :b)"); params["b"]=f"%{b}%"
        st=self._st_rec.get()
        if st=="vencido":
            conds.append("status='aberto' AND vencimento < DATE('now')")
        elif st!="todos":
            conds.append("status=:s"); params["s"]=st
        where="WHERE "+" AND ".join(conds) if conds else ""
        rows=self.db.q(f"SELECT descricao,cliente_nome,valor,vencimento,status,pedido_ref FROM contas_receber {where} ORDER BY vencimento DESC LIMIT 300",params).fetchall()
        for r in rows:
            vals=list(r); vals[2]=fmt_brl(vals[2]); tag=vals[4] if vals[4] in ("aberto","quitado") else "vencido"
            self.tree_rec.insert("","end",values=tuple(vals),tags=(tag,))

    def _nova_rec(self):
        JanelaContaForm(self,"receber",self.db,self._load_receber)

    def _quitar_rec(self):
        sel=self.tree_rec.selection()
        if not sel: return
        desc=self.tree_rec.item(sel[0])["values"][0]
        self.db.q("UPDATE contas_receber SET status='quitado',pagamento=? WHERE descricao=?",(agora(),desc))
        self.db.commit(); self._load_receber(); self._build_resumo_data()

    def _build_pagar(self, parent):
        parent.grid_columnconfigure(0,weight=1); parent.grid_rowconfigure(1,weight=1)
        frow=ctk.CTkFrame(parent,fg_color=CARD2,corner_radius=6); frow.grid(row=0,column=0,sticky="ew",padx=8,pady=(8,4))
        frow.grid_columnconfigure(0,weight=1)
        self._bus_pag=ctk.CTkEntry(frow,placeholder_text="Buscar…",height=34,fg_color=CARD); self._bus_pag.grid(row=0,column=0,padx=8,pady=8,sticky="ew")
        self._bus_pag.bind("<KeyRelease>",lambda e:self._load_pagar())
        self._st_pag=tk.StringVar(value="todos")
        ctk.CTkOptionMenu(frow,variable=self._st_pag,values=["todos","aberto","pago","vencido"],
                          width=110,height=34,command=lambda _:self._load_pagar()).grid(row=0,column=1,padx=(0,4),pady=8)
        ctk.CTkButton(frow,text="➕ Novo",height=34,fg_color=ERR,command=self._nova_pag).grid(row=0,column=2,padx=(0,8),pady=8)
        cols=("descricao","fornecedor_nome","valor","vencimento","status","compra_ref")
        self.tree_pag=ttk.Treeview(parent,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,[("Descrição",200),("Fornecedor",160),("Valor",90),("Vencimento",110),("Status",80),("Referência",100)]):
            self.tree_pag.heading(col,text=txt); self.tree_pag.column(col,width=w)
        self.tree_pag.tag_configure("aberto",foreground="#60a5fa")
        self.tree_pag.tag_configure("pago",foreground="#4ade80")
        self.tree_pag.tag_configure("vencido",foreground="#f87171")
        self.tree_pag.grid(row=1,column=0,sticky="nsew",padx=8,pady=4)
        ctk.CTkButton(parent,text="✅ Marcar Pago",height=34,fg_color=OK,
                      command=self._quitar_pag).grid(row=2,column=0,padx=8,pady=(4,8),sticky="w")
        self._load_pagar()

    def _load_pagar(self):
        self.tree_pag.delete(*self.tree_pag.get_children())
        conds=[]; params={}
        b=self._bus_pag.get().strip()
        if b: conds.append("(descricao LIKE :b OR fornecedor_nome LIKE :b)"); params["b"]=f"%{b}%"
        st=self._st_pag.get()
        if st=="vencido": conds.append("status='aberto' AND vencimento < DATE('now')")
        elif st!="todos": conds.append("status=:s"); params["s"]=st
        where="WHERE "+" AND ".join(conds) if conds else ""
        rows=self.db.q(f"SELECT descricao,fornecedor_nome,valor,vencimento,status,compra_ref FROM contas_pagar {where} ORDER BY vencimento DESC LIMIT 300",params).fetchall()
        for r in rows:
            vals=list(r); vals[2]=fmt_brl(vals[2]); tag=vals[4] if vals[4] in ("aberto","pago") else "vencido"
            self.tree_pag.insert("","end",values=tuple(vals),tags=(tag,))

    def _nova_pag(self):
        JanelaContaForm(self,"pagar",self.db,self._load_pagar)

    def _quitar_pag(self):
        sel=self.tree_pag.selection()
        if not sel: return
        desc=self.tree_pag.item(sel[0])["values"][0]
        self.db.q("UPDATE contas_pagar SET status='pago',pagamento=? WHERE descricao=?",(agora(),desc))
        self.db.commit(); self._load_pagar()

    def _build_resumo(self, parent):
        parent.grid_columnconfigure(0,weight=1)
        self._frame_resumo=ctk.CTkScrollableFrame(parent,fg_color=BG,corner_radius=0)
        self._frame_resumo.pack(fill="both",expand=True)
        self._build_resumo_data()

    def _build_resumo_data(self):
        for w in self._frame_resumo.winfo_children(): w.destroy()
        rec_open=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_receber WHERE status='aberto'").fetchone()[0]
        rec_quitado=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_receber WHERE status='quitado'").fetchone()[0]
        pag_open=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_pagar WHERE status='aberto'").fetchone()[0]
        pag_pago=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_pagar WHERE status='pago'").fetchone()[0]
        venc_rec=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_receber WHERE status='aberto' AND vencimento<DATE('now')").fetchone()[0]
        venc_pag=self.db.q("SELECT COALESCE(SUM(valor),0) FROM contas_pagar WHERE status='aberto' AND vencimento<DATE('now')").fetchone()[0]
        v_mes=self.db.q("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE strftime('%Y-%m',criado)=strftime('%Y-%m','now') AND status!='cancelado'").fetchone()[0]

        cards=[
            ("A Receber (aberto)",fmt_brl(rec_open),OK,ACC2),
            ("Recebido (quitado)",fmt_brl(rec_quitado),OK,OK),
            ("A Pagar (aberto)",fmt_brl(pag_open),ERR,PURP),
            ("Pago",fmt_brl(pag_pago),MUTED,MUTED),
            ("Vencidos a Receber",fmt_brl(venc_rec),WARN,WARN),
            ("Vencidos a Pagar",fmt_brl(venc_pag),ERR,ERR),
            ("Vendas do Mês",fmt_brl(v_mes),ACC,ACC),
        ]
        ctk.CTkLabel(self._frame_resumo,text="Resumo Financeiro",font=ctk.CTkFont(size=16,weight="bold"),
                     text_color=TXT).pack(pady=(16,8),padx=20,anchor="w")
        for titulo,valor,cor_v,cor_brd in cards:
            card=ctk.CTkFrame(self._frame_resumo,fg_color=CARD,corner_radius=8,border_width=2,border_color=cor_brd)
            card.pack(fill="x",padx=20,pady=4)
            ctk.CTkLabel(card,text=titulo,font=ctk.CTkFont(size=11),text_color=MUTED).pack(anchor="w",padx=14,pady=(8,0))
            ctk.CTkLabel(card,text=valor,font=ctk.CTkFont(size=20,weight="bold"),text_color=cor_v).pack(anchor="w",padx=14,pady=(0,8))


class JanelaContaForm(ctk.CTkToplevel):
    def __init__(self, parent, tipo, db, callback):
        super().__init__(parent)
        self.db=db; self.tipo=tipo; self.callback=callback
        titulo="Nova Conta a Receber" if tipo=="receber" else "Nova Conta a Pagar"
        self.title(titulo); self.geometry("440x360"); self.grab_set(); self.configure(fg_color=BG)
        ctk.CTkLabel(self,text=titulo,font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(16,8),padx=20,anchor="w")
        self.ent={}
        campos=[("descricao","Descrição *"),("cliente_nome" if tipo=="receber" else "fornecedor_nome","Cliente" if tipo=="receber" else "Fornecedor"),
                ("valor","Valor R$ *"),("vencimento","Vencimento (AAAA-MM-DD) *")]
        for key,ph in campos:
            e=ctk.CTkEntry(self,placeholder_text=ph,height=36); e.pack(fill="x",padx=20,pady=4); self.ent[key]=e
        venc=(datetime.date.today()+datetime.timedelta(days=30)).isoformat()
        self.ent["vencimento"].insert(0,venc)
        ctk.CTkButton(self,text="💾  Salvar",height=40,fg_color=OK if tipo=="receber" else ERR,
                      command=self._salvar).pack(fill="x",padx=20,pady=12)

    def _salvar(self):
        desc=self.ent["descricao"].get().strip(); valor=parse_float(self.ent["valor"].get()); venc=self.ent["vencimento"].get().strip()
        if not desc or not venc or valor<=0:
            messagebox.showwarning("Obrigatório","Preencha descrição, valor e vencimento."); return
        if self.tipo=="receber":
            cli=list(self.ent.values())[1].get().strip()
            self.db.q("INSERT INTO contas_receber(descricao,cliente_nome,valor,vencimento,status) VALUES(?,?,?,?,?)",(desc,cli,valor,venc,"aberto"))
        else:
            forn=list(self.ent.values())[1].get().strip()
            self.db.q("INSERT INTO contas_pagar(descricao,fornecedor_nome,valor,vencimento,status) VALUES(?,?,?,?,?)",(desc,forn,valor,venc,"aberto"))
        self.db.commit(); self.callback(); self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL CLIENTES / FORNECEDORES (genérico)
# ══════════════════════════════════════════════════════════════════════════════
class PainelCadastro(ctk.CTkFrame):
    """Genérico para Clientes e Fornecedores."""
    def __init__(self, master, db, tipo, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self.tipo=tipo; self._status=status_cb
        self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)
        cor = CYAN if self.tipo=="cliente" else PINK
        titulo = "👤  Clientes" if self.tipo=="cliente" else "🏭  Fornecedores"
        tabela = "clientes" if self.tipo=="cliente" else "fornecedores"

        frow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); frow.grid(row=0,column=0,sticky="ew",padx=12,pady=(12,4))
        frow.grid_columnconfigure(1,weight=1)
        ctk.CTkLabel(frow,text=titulo,font=ctk.CTkFont(size=16,weight="bold"),text_color=cor).grid(row=0,column=0,padx=14,pady=10,sticky="w")
        self._busca=ctk.CTkEntry(frow,placeholder_text="Buscar por nome, CPF/CNPJ…",height=34,fg_color=CARD2)
        self._busca.grid(row=0,column=1,padx=8,pady=10,sticky="ew")
        self._busca.bind("<KeyRelease>",lambda e:self._carregar())
        ctk.CTkButton(frow,text=f"➕ Novo",height=34,fg_color=cor,command=self._novo).grid(row=0,column=2,padx=(0,14),pady=10)

        if self.tipo=="cliente":
            cols=("nome","tipo","cpf_cnpj","telefone","email","cidade","tabela_preco","limite_credito")
            hdrs=[("Nome",200),("Tipo",45),("CPF/CNPJ",140),("Telefone",120),("Email",180),("Cidade",120),("Tabela",70),("Limite",80)]
        else:
            cols=("razao_social","cnpj","representante","telefone","email","cidade","prazo_entrega")
            hdrs=[("Razão Social",200),("CNPJ",140),("Representante",150),("Telefone",120),("Email",180),("Cidade",120),("Prazo",60)]

        self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,hdrs):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.grid(row=1,column=0,sticky="nsew",padx=12,pady=4)
        self.tree.bind("<Double-1>",self._editar)

        arow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); arow.grid(row=2,column=0,sticky="ew",padx=12,pady=(4,12))
        ctk.CTkButton(arow,text="✏️ Editar",height=34,fg_color=CARD2,command=self._editar).pack(side="left",padx=4,pady=8)
        ctk.CTkButton(arow,text="🗑 Inativar",height=34,fg_color=ERR,command=self._inativar).pack(side="left",padx=4,pady=8)
        self._lbl=ctk.CTkLabel(arow,text="",text_color=MUTED,font=ctk.CTkFont(size=11)); self._lbl.pack(side="right",padx=14)
        self._carregar()

    def _carregar(self):
        self.tree.delete(*self.tree.get_children())
        tabela="clientes" if self.tipo=="cliente" else "fornecedores"
        busca=self._busca.get().strip(); params={}
        if self.tipo=="cliente":
            where="WHERE ativo=1" + (" AND (nome LIKE :b OR cpf_cnpj LIKE :b)" if busca else "")
            if busca: params["b"]=f"%{busca}%"
            rows=self.db.q(f"SELECT nome,tipo,cpf_cnpj,telefone,email,cidade,tabela_preco,limite_credito FROM clientes {where} ORDER BY nome LIMIT 300",params).fetchall()
        else:
            where="WHERE ativo=1" + (" AND (razao_social LIKE :b OR cnpj LIKE :b)" if busca else "")
            if busca: params["b"]=f"%{busca}%"
            rows=self.db.q(f"SELECT razao_social,cnpj,representante,telefone,email,cidade,prazo_entrega FROM fornecedores {where} ORDER BY razao_social LIMIT 300",params).fetchall()
        for r in rows:
            vals=list(r)
            if self.tipo=="cliente": vals[-1]=fmt_brl(vals[-1])
            self.tree.insert("","end",values=tuple(vals))
        self._lbl.configure(text=f"{len(rows)} registro(s)")

    def _novo(self):
        JanelaCadForm(self,self.db,self.tipo,None,self._carregar)

    def _editar(self, event=None):
        sel=self.tree.selection()
        if not sel: return
        nome_ou_razao=self.tree.item(sel[0])["values"][0]
        tabela="clientes" if self.tipo=="cliente" else "fornecedores"
        col="nome" if self.tipo=="cliente" else "razao_social"
        r=self.db.q(f"SELECT * FROM {tabela} WHERE {col}=?",(nome_ou_razao,)).fetchone()
        if r: JanelaCadForm(self,self.db,self.tipo,dict(r),self._carregar)

    def _inativar(self):
        sel=self.tree.selection()
        if not sel: return
        nome=self.tree.item(sel[0])["values"][0]
        tabela="clientes" if self.tipo=="cliente" else "fornecedores"
        col="nome" if self.tipo=="cliente" else "razao_social"
        if not messagebox.askyesno("Inativar",f"Inativar {nome}?"): return
        self.db.q(f"UPDATE {tabela} SET ativo=0 WHERE {col}=?",(nome,))
        self.db.commit(); self._carregar()


class JanelaCadForm(ctk.CTkToplevel):
    def __init__(self, parent, db, tipo, dados, callback):
        super().__init__(parent)
        self.db=db; self.tipo=tipo; self.dados=dados; self.callback=callback
        titulo=("Novo Cliente" if not dados else "Editar Cliente") if tipo=="cliente" else ("Novo Fornecedor" if not dados else "Editar Fornecedor")
        self.title(titulo); self.geometry("500x520"); self.grab_set(); self.configure(fg_color=BG)
        self.ent={}; self._build()

    def _build(self):
        cor=CYAN if self.tipo=="cliente" else PINK
        ctk.CTkLabel(self,text=self.title(),font=ctk.CTkFont(size=14,weight="bold"),text_color=cor).pack(pady=(14,8),padx=20,anchor="w")
        scroll=ctk.CTkScrollableFrame(self,fg_color="transparent"); scroll.pack(fill="both",expand=True,padx=20)
        if self.tipo=="cliente":
            campos=[("nome","Nome *"),("nome_fantasia","Nome Fantasia"),("cpf_cnpj","CPF/CNPJ"),
                    ("telefone","Telefone"),("email","Email"),("endereco","Endereço"),
                    ("bairro","Bairro"),("cidade","Cidade"),("uf","UF"),("cep","CEP"),
                    ("limite_credito","Limite de Crédito R$"),("observacoes","Observações")]
        else:
            campos=[("razao_social","Razão Social *"),("nome_fantasia","Nome Fantasia"),("cnpj","CNPJ"),
                    ("representante","Representante"),("telefone","Telefone"),("email","Email"),
                    ("endereco","Endereço"),("cidade","Cidade"),("uf","UF"),
                    ("prazo_entrega","Prazo Entrega (dias)"),("cond_pagamento","Condição Pagamento"),("observacoes","Observações")]
        for key,ph in campos:
            e=ctk.CTkEntry(scroll,placeholder_text=ph,height=34); e.pack(fill="x",pady=3)
            if self.dados and key in self.dados: e.insert(0,str(self.dados[key] or ""))
            self.ent[key]=e
        ctk.CTkButton(self,text="💾  Salvar",height=42,fg_color=cor,
                      command=self._salvar,font=ctk.CTkFont(size=13,weight="bold")).pack(fill="x",padx=20,pady=12)

    def _salvar(self):
        if self.tipo=="cliente":
            nome=self.ent["nome"].get().strip()
            if not nome: messagebox.showwarning("Obrigatório","Nome é obrigatório."); return
            vals=tuple(self.ent[k].get().strip() for k in ["nome","nome_fantasia","cpf_cnpj","telefone","email","endereco","bairro","cidade","uf","cep"])
            limite=parse_float(self.ent["limite_credito"].get()); obs=self.ent["observacoes"].get().strip()
            if self.dados and "id" in self.dados:
                self.db.q("UPDATE clientes SET nome=?,nome_fantasia=?,cpf_cnpj=?,telefone=?,email=?,endereco=?,bairro=?,cidade=?,uf=?,cep=?,limite_credito=?,observacoes=? WHERE id=?",
                          (*vals,limite,obs,self.dados["id"]))
            else:
                self.db.q("INSERT INTO clientes(nome,nome_fantasia,cpf_cnpj,telefone,email,endereco,bairro,cidade,uf,cep,limite_credito,observacoes,ativo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (*vals,limite,obs))
        else:
            razao=self.ent["razao_social"].get().strip()
            if not razao: messagebox.showwarning("Obrigatório","Razão Social é obrigatória."); return
            vals=tuple(self.ent[k].get().strip() for k in ["razao_social","nome_fantasia","cnpj","representante","telefone","email","endereco","cidade","uf"])
            prazo=parse_int(self.ent["prazo_entrega"].get()) or 7; cond=self.ent["cond_pagamento"].get().strip(); obs=self.ent["observacoes"].get().strip()
            if self.dados and "id" in self.dados:
                self.db.q("UPDATE fornecedores SET razao_social=?,nome_fantasia=?,cnpj=?,representante=?,telefone=?,email=?,endereco=?,cidade=?,uf=?,prazo_entrega=?,cond_pagamento=?,observacoes=? WHERE id=?",
                          (*vals,prazo,cond,obs,self.dados["id"]))
            else:
                self.db.q("INSERT INTO fornecedores(razao_social,nome_fantasia,cnpj,representante,telefone,email,endereco,cidade,uf,prazo_entrega,cond_pagamento,observacoes,ativo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (*vals,prazo,cond,obs))
        self.db.commit(); self.callback(); self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL RELATÓRIOS
# ══════════════════════════════════════════════════════════════════════════════
class PainelRelatorios(ctk.CTkScrollableFrame):
    def __init__(self, master, db, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._status=status_cb
        self._build()

    def _build(self):
        ctk.CTkLabel(self,text="📊  Relatórios & Exportações",font=ctk.CTkFont(size=18,weight="bold"),
                     text_color=TXT).pack(pady=(16,8),padx=20,anchor="w")
        est=self.db.estatisticas()
        # Painel de métricas
        m_frame=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); m_frame.pack(fill="x",padx=20,pady=8)
        m_frame.grid_columnconfigure((0,1,2,3),weight=1)
        metricas=[
            ("Itens cadastrados",str(est["itens"]),ACC),
            ("Unidades em estoque",str(est["unidades"]),OK),
            ("Zerados",str(est["zerados"]),ERR),
            ("Vendas hoje",fmt_brl(est["vendas_hoje"]),CYAN),
        ]
        for i,(titulo,valor,cor) in enumerate(metricas):
            f=ctk.CTkFrame(m_frame,fg_color=CARD2,corner_radius=8); f.grid(row=0,column=i,padx=8,pady=12,sticky="ew")
            ctk.CTkLabel(f,text=titulo,font=ctk.CTkFont(size=10),text_color=MUTED).pack(pady=(8,0),padx=10)
            ctk.CTkLabel(f,text=valor,font=ctk.CTkFont(size=18,weight="bold"),text_color=cor).pack(pady=(0,8),padx=10)

        # Exportar estoque
        c1=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10,border_width=1,border_color=BRD); c1.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(c1,text="📤  Exportar Estoque",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        r1=ctk.CTkFrame(c1,fg_color="transparent"); r1.pack(fill="x",padx=14,pady=(0,12))
        ctk.CTkButton(r1,text="CSV",command=self._exp_csv,fg_color=ACC).pack(side="left",padx=4)
        ctk.CTkButton(r1,text="Excel (.xlsx)",command=self._exp_excel,fg_color=CARD2).pack(side="left",padx=4)
        ctk.CTkButton(r1,text="PDF (relatório)",command=self._exp_pdf,fg_color=CARD2).pack(side="left",padx=4)

        # Importar
        c2=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10,border_width=1,border_color=BRD); c2.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(c2,text="📥  Importar Estoque (CSV)",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        ctk.CTkLabel(c2,text="Colunas: Código; Nome; Prateleira; Setor; Posição; Qtd; QtdMin; Custo; Venda; Marca; Fornecedor; CódFab; Aplicações",
                     font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w",padx=14)
        r2=ctk.CTkFrame(c2,fg_color="transparent"); r2.pack(fill="x",padx=14,pady=(4,12))
        ctk.CTkButton(r2,text="Selecionar e Importar",command=self._importar,fg_color=OK).pack(side="left",padx=4)
        ctk.CTkButton(r2,text="Baixar modelo",command=self._modelo,fg_color=CARD2).pack(side="left",padx=4)

        # Estoque baixo
        c3=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10,border_width=1,border_color=BRD); c3.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(c3,text="⚠️  Relatório de Estoque Baixo / Zerado",font=ctk.CTkFont(size=13,weight="bold"),text_color=WARN).pack(anchor="w",padx=14,pady=(12,4))
        r3=ctk.CTkFrame(c3,fg_color="transparent"); r3.pack(fill="x",padx=14,pady=(0,12))
        ctk.CTkButton(r3,text="Exportar CSV",command=self._exp_alertas_csv,fg_color=WARN,text_color=BG).pack(side="left",padx=4)

        # Log
        ctk.CTkLabel(self,text="Log:",text_color=MUTED,font=ctk.CTkFont(size=11)).pack(anchor="w",padx=22,pady=(12,2))
        self._txt=ctk.CTkTextbox(self,fg_color=CARD,font=ctk.CTkFont(family="Consolas",size=10),corner_radius=8,height=120)
        self._txt.pack(fill="x",padx=20,pady=(0,16))

    def _log(self, msg):
        self._txt.configure(state="normal"); self._txt.insert("end",f"{agora()} — {msg}\n"); self._txt.see("end")

    def _exp_csv(self):
        rows=self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.localizacao,
                   p.quantidade,p.qtd_minima,p.preco_custo,p.preco_venda,p.marca,p.fornecedor,
                   p.cod_fabricante,p.categoria,GROUP_CONCAT(a.veiculo,' / ')
            FROM pecas p LEFT JOIN aplicacoes a ON a.codigo=p.codigo WHERE p.ativo=1
            GROUP BY p.codigo ORDER BY p.prateleira,p.setor,p.posicao
        """).fetchall()
        nome=f"mecatrack_estoque_{hoje()}.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f,delimiter=";")
            w.writerow(["Código","Nome","Prateleira","Setor","Posição","Localização","Qtd","QtdMin","Custo","Venda","Marca","Fornecedor","CódFab","Categoria","Aplicações"])
            w.writerows(rows)
        self._log(f"CSV exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("Exportado ✅",f"Salvo em:\n{os.path.abspath(nome)}")

    def _exp_excel(self):
        try:
            import openpyxl
            from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
        except ImportError:
            messagebox.showerror("Erro","pip install openpyxl"); return
        wb=openpyxl.Workbook(); ws=wb.active; ws.title="Estoque"
        h_font=Font(bold=True,color="FFFFFF",size=11); h_fill=PatternFill("solid",fgColor="1E3A8A")
        thin=Side(border_style="thin",color="CBD5E1"); brd=openpyxl.styles.Border(left=thin,right=thin,top=thin,bottom=thin)
        hdrs=["Código","Nome","Prateleira","Setor","Posição","Qtd","QtdMin","Custo R$","Venda R$","Margem%","Marca","Fornecedor","Categoria","Aplicações"]
        ws.append(hdrs)
        for cell in ws[1]: cell.font=h_font; cell.fill=h_fill; cell.border=brd; cell.alignment=Alignment(horizontal="center")
        rows=self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.quantidade,p.qtd_minima,
                   p.preco_custo,p.preco_venda,p.marca,p.fornecedor,p.categoria,
                   GROUP_CONCAT(a.veiculo,' / ')
            FROM pecas p LEFT JOIN aplicacoes a ON a.codigo=p.codigo WHERE p.ativo=1
            GROUP BY p.codigo ORDER BY p.prateleira,p.setor,p.posicao
        """).fetchall()
        alt=PatternFill("solid",fgColor="EFF6FF")
        for idx,r in enumerate(rows,2):
            custo,venda=r[7],r[8]; margem=round((venda-custo)/venda*100,1) if venda else 0
            ws.append([r[0],r[1],r[2],r[3],r[4],r[5],r[6],custo,venda,margem,r[9],r[10],r[11],r[12] or ""])
            if idx%2==0:
                for cell in ws[idx]: cell.fill=alt
            for cell in ws[idx]: cell.border=brd
            qty_cell=ws[idx][5]
            if r[5]==0: qty_cell.font=Font(color="EF4444",bold=True)
            elif r[5]<=r[6]: qty_cell.font=Font(color="F59E0B",bold=True)
        from openpyxl.utils import get_column_letter
        for ci,col in enumerate(ws.columns,1):
            w2=min(max(len(str(c.value or "")) for c in col)+4,40)
            ws.column_dimensions[get_column_letter(ci)].width=w2
        ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
        ws2=wb.create_sheet("Resumo"); est=self.db.estatisticas()
        ws2.append(["Métrica","Valor"])
        for k,v in [("Total itens",est["itens"]),("Zerados",est["zerados"]),("Baixos",est["baixos"]),
                    ("Unidades",est["unidades"]),("Valor de custo",est["custo"]),("Valor de venda",est["venda"])]:
            ws2.append([k,v])
        nome=f"mecatrack_estoque_{hoje()}.xlsx"
        wb.save(nome)
        self._log(f"Excel exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("Excel gerado ✅",f"Salvo em:\n{os.path.abspath(nome)}")

    def _exp_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4,landscape
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
            from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib.units import cm
        except ImportError:
            messagebox.showerror("Erro","pip install reportlab"); return
        nome=f"mecatrack_estoque_{hoje()}.pdf"
        doc=SimpleDocTemplate(nome,pagesize=landscape(A4),leftMargin=1*cm,rightMargin=1*cm,topMargin=1.5*cm,bottomMargin=1*cm)
        styles=getSampleStyleSheet()
        rows=self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.setor,p.posicao,p.quantidade,p.qtd_minima,
                   p.preco_custo,p.preco_venda,p.marca
            FROM pecas p WHERE p.ativo=1 ORDER BY p.prateleira,p.setor,p.posicao LIMIT 500
        """).fetchall()
        hdrs=["Código","Nome","Prateleira","Setor","Posição","Qtd","Qtd Min","Custo","Venda","Marca"]
        data=[hdrs]+[[str(c) for c in r] for r in rows]
        t=Table(data,colWidths=[2*cm,5*cm,2.8*cm,1.5*cm,1.8*cm,1.2*cm,1.5*cm,2*cm,2*cm,2.5*cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A8A")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),
            ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
            ("FONTSIZE",(0,0),(-1,-1),8),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#EFF6FF")]),
            ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#CBD5E1")),
        ]))
        est=self.db.estatisticas()
        doc.build([
            Paragraph(f"<b>MecaTrack ERP — Estoque por Localização</b>",styles["Title"]),
            Paragraph(f"Gerado: {agora()}  ·  {est['itens']} itens  ·  {est['unidades']} unidades  ·  Custo: {fmt_brl(est['custo'])}",styles["Normal"]),
            Spacer(1,0.5*cm),t
        ])
        self._log(f"PDF exportado: {os.path.abspath(nome)}")
        messagebox.showinfo("PDF gerado ✅",f"Salvo em:\n{os.path.abspath(nome)}")

    def _exp_alertas_csv(self):
        rows=self.db.q("""
            SELECT p.codigo,p.nome,p.prateleira,p.quantidade,p.qtd_minima,p.fornecedor,p.marca
            FROM pecas p WHERE p.ativo=1 AND (p.quantidade=0 OR p.quantidade<=p.qtd_minima)
            ORDER BY p.quantidade,p.prateleira
        """).fetchall()
        nome=f"mecatrack_alertas_{hoje()}.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f,delimiter=";"); w.writerow(["Código","Nome","Prateleira","Qtd","Qtd Mín","Fornecedor","Marca"]); w.writerows(rows)
        self._log(f"Alertas exportados: {os.path.abspath(nome)}")
        messagebox.showinfo("Exportado",f"Salvo em:\n{os.path.abspath(nome)}")

    def _importar(self):
        path=filedialog.askopenfilename(title="Selecionar CSV",filetypes=[("CSV","*.csv"),("Todos","*.*")])
        if not path: return
        criados=atualizados=erros=0; self._log(f"Importando: {path}")
        try:
            for enc in ["utf-8-sig","utf-8","latin-1","cp1252"]:
                try:
                    with open(path,newline="",encoding=enc) as ff: sample=ff.read(2048)
                    encoding=enc; break
                except: pass
            with open(path,newline="",encoding=encoding) as ff:
                try:
                    import csv as _csv; dialect=_csv.Sniffer().sniff(sample,delimiters=";,\t"); reader=_csv.DictReader(ff,dialect=dialect)
                except Exception: ff.seek(0); reader=_csv.DictReader(ff,delimiter=";")
                col={k.lower().strip():k for k in (reader.fieldnames or [])}
                def gc(alts):
                    for a in alts:
                        if a in col: return col[a]
                    return None
                F={"cod":gc(["código","codigo","code","id"]),"nome":gc(["nome","name","descrição"]),
                   "prat":gc(["prateleira","shelf","prat"]),"setor":gc(["setor","sector","area"]),
                   "pos":gc(["posição","posicao","caixa","cx","pos"]),"local":gc(["localização","localizacao","local"]),
                   "qty":gc(["quantidade","qtd","qty","estoque"]),"min":gc(["qtd mínima","qtdmin","min","mínimo"]),
                   "custo":gc(["custo r$","custo","cost"]),"venda":gc(["venda r$","venda","price","preço"]),
                   "marca":gc(["marca","brand"]),"forn":gc(["fornecedor","supplier"]),
                   "ean":gc(["cód fabricante","ean","barcode"]),"aplic":gc(["aplicações","veículos","cars"])}
                for row in reader:
                    rl={k.lower().strip():v for k,v in row.items()}
                    def gv(field):
                        fk=F.get(field); return (rl.get(fk.lower().strip(),"") if fk else "").strip()
                    cod=gv("cod"); nome=gv("nome")
                    if not cod or not nome: erros+=1; self._log(f"  ⚠ Linha sem código/nome"); continue
                    prat=gv("prat"); setor=gv("setor"); pos=gv("pos"); local=gv("local")
                    if not local and (prat or setor or pos):
                        num=re.sub(r'[^0-9]','',prat) or prat; partes=[]
                        if num: partes.append(f"P{num}")
                        if setor: partes.append(setor.upper())
                        if pos: partes.append(pos.zfill(2))
                        local="-".join(partes)
                    existe=self.db.q("SELECT codigo FROM pecas WHERE codigo=?",(cod,)).fetchone()
                    try:
                        self.db.q("""INSERT OR REPLACE INTO pecas
                            (codigo,nome,localizacao,prateleira,setor,posicao,quantidade,qtd_minima,
                             preco_custo,preco_venda,marca,fornecedor,cod_fabricante,atualizado,ativo)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",
                            (cod,nome,local,prat,setor,pos,parse_int(gv("qty")),parse_int(gv("min")) or 2,
                             parse_float(gv("custo")),parse_float(gv("venda")),gv("marca"),gv("forn"),gv("ean"),agora()))
                        self.db.q("DELETE FROM aplicacoes WHERE codigo=?",(cod,))
                        for aplic in (gv("aplic") or "").split("/"):
                            if aplic.strip(): self.db.q("INSERT INTO aplicacoes(codigo,veiculo) VALUES(?,?)",(cod,aplic.strip()))
                        if existe: atualizados+=1
                        else: criados+=1
                    except Exception as ex: erros+=1; self._log(f"  ❌ {cod}: {ex}")
            self.db.commit()
            msg=f"✅ {criados} criados, {atualizados} atualizados, {erros} erros."
            self._log(msg); messagebox.showinfo("Concluído",msg)
        except Exception as exc: self._log(f"❌ Falha: {exc}"); messagebox.showerror("Erro",str(exc))

    def _modelo(self):
        nome="mecatrack_modelo.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f,delimiter=";")
            w.writerow(["Código","Nome","Prateleira","Setor","Posição","Qtd","QtdMin","Custo","Venda","Marca","Fornecedor","CódFab","Aplicações"])
            w.writerow(["FLT-001","Filtro de óleo Mahle","Prateleira 1","A","03","10","2","12,50","29,90","Mahle","Distribuidora XYZ","OC 222","Gol 1.0/Palio 1.0"])
        self._log(f"Modelo criado: {os.path.abspath(nome)}")
        messagebox.showinfo("Modelo criado",f"Arquivo:\n{os.path.abspath(nome)}")


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL HISTÓRICO
# ══════════════════════════════════════════════════════════════════════════════
class PainelHistorico(ctk.CTkFrame):
    def __init__(self, master, db, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)
        frow=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8); frow.grid(row=0,column=0,sticky="ew",padx=12,pady=(12,4))
        frow.grid_columnconfigure(1,weight=1)
        ctk.CTkLabel(frow,text="🕒  Histórico de Movimentações",font=ctk.CTkFont(size=16,weight="bold"),text_color=ACC2).grid(row=0,column=0,padx=14,pady=10,sticky="w")
        self._ent_f=ctk.CTkEntry(frow,placeholder_text="Código ou nome da peça…",height=34,fg_color=CARD2)
        self._ent_f.grid(row=0,column=1,padx=8,pady=10,sticky="ew"); self._ent_f.bind("<KeyRelease>",lambda e:self._carregar())
        self._tipo_var=tk.StringVar(value="todos")
        ctk.CTkOptionMenu(frow,variable=self._tipo_var,values=["todos","entrada","saida","ajuste"],
                          width=120,height=34,command=lambda _:self._carregar()).grid(row=0,column=2,padx=(0,4),pady=10)
        ctk.CTkButton(frow,text="CSV",width=60,height=34,fg_color=CARD2,command=self._exp_csv).grid(row=0,column=3,padx=4,pady=10)
        ctk.CTkButton(frow,text="PDF",width=60,height=34,fg_color=CARD2,command=self._exp_pdf).grid(row=0,column=4,padx=(0,14),pady=10)
        cols=("data_hora","codigo","nome","tipo","qtd","motivo","usuario")
        self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview")
        for col,(txt,w) in zip(cols,[("Data/Hora",140),("Código",90),("Peça",180),("Tipo",70),("Qtd",50),("Motivo",230),("Usuário",90)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.tag_configure("entrada",foreground="#4ade80"); self.tree.tag_configure("saida",foreground="#f87171"); self.tree.tag_configure("ajuste",foreground="#fbbf24")
        sb=ttk.Scrollbar(self,orient="vertical",command=self.tree.yview); self.tree.configure(yscroll=sb.set)
        self.tree.grid(row=1,column=0,sticky="nsew",padx=(12,0),pady=4); sb.grid(row=1,column=1,sticky="ns",pady=4,padx=(0,8))
        self._lbl=ctk.CTkLabel(self,text="",text_color=MUTED,font=ctk.CTkFont(size=11)); self._lbl.grid(row=2,column=0,padx=14,pady=(2,8),sticky="w")
        self._carregar()

    def _carregar(self):
        self.tree.delete(*self.tree.get_children())
        filtro=self._ent_f.get().strip(); tipo=self._tipo_var.get()
        conds=[]; params={}
        if filtro: conds.append("(m.codigo LIKE :f OR p.nome LIKE :f)"); params["f"]=f"%{filtro}%"
        if tipo!="todos": conds.append("m.tipo=:tp"); params["tp"]=tipo
        where="WHERE "+" AND ".join(conds) if conds else ""
        rows=self.db.q(f"""SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
                            FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo
                            {where} ORDER BY m.id DESC LIMIT 1000""",params).fetchall()
        for r in rows:
            tag=r[3] if r[3] in ("entrada","saida","ajuste") else "ajuste"
            self.tree.insert("","end",values=tuple(r),tags=(tag,))
        self._lbl.configure(text=f"{len(rows)} registros")

    def _exp_csv(self):
        rows=self.db.q("""SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
                           FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo ORDER BY m.id DESC""").fetchall()
        nome=f"mecatrack_historico_{hoje()}.csv"
        with open(nome,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f,delimiter=";"); w.writerow(["Data/Hora","Código","Peça","Tipo","Qtd","Motivo","Usuário"]); w.writerows(rows)
        messagebox.showinfo("Exportado",f"Salvo em:\n{os.path.abspath(nome)}")

    def _exp_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4,landscape; from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
            from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib.units import cm
        except ImportError:
            messagebox.showerror("Erro","pip install reportlab"); return
        nome=f"mecatrack_historico_{hoje()}.pdf"
        doc=SimpleDocTemplate(nome,pagesize=landscape(A4),leftMargin=1*cm,rightMargin=1*cm,topMargin=1.5*cm,bottomMargin=1*cm)
        styles=getSampleStyleSheet()
        rows=self.db.q("""SELECT m.data_hora,m.codigo,COALESCE(p.nome,'—'),m.tipo,m.quantidade,m.motivo,m.usuario
                           FROM movimentacoes m LEFT JOIN pecas p ON p.codigo=m.codigo ORDER BY m.id DESC LIMIT 500""").fetchall()
        data=[["Data/Hora","Código","Peça","Tipo","Qtd","Motivo","Usuário"]]+[list(r) for r in rows]
        t=Table(data,colWidths=[3.5*cm,2.2*cm,5*cm,1.8*cm,1.2*cm,7*cm,2*cm])
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1E3A8A")),("TEXTCOLOR",(0,0),(-1,0),colors.white),
                                ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),
                                ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#EFF6FF")]),
                                ("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#CBD5E1"))]))
        doc.build([Paragraph("<b>MecaTrack ERP — Histórico de Movimentações</b>",styles["Title"]),
                   Paragraph(f"Gerado: {agora()}",styles["Normal"]),Spacer(1,0.5*cm),t])
        messagebox.showinfo("PDF gerado ✅",f"Salvo em:\n{os.path.abspath(nome)}")


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL USUÁRIOS
# ══════════════════════════════════════════════════════════════════════════════
class PainelUsuarios(ctk.CTkFrame):
    def __init__(self, master, db, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._build()

    def _build(self):
        self.grid_columnconfigure(0,weight=1); self.grid_rowconfigure(1,weight=1)
        ctk.CTkLabel(self,text="👥  Usuários do Sistema",font=ctk.CTkFont(size=16,weight="bold"),
                     text_color=TXT).grid(row=0,column=0,padx=14,pady=(14,4),sticky="w")
        cols=("login","perfil","ativo","criado"); self.tree=ttk.Treeview(self,columns=cols,show="headings",style="M.Treeview",height=10)
        for col,(txt,w) in zip(cols,[("Login",180),("Perfil",100),("Ativo",60),("Criado",160)]):
            self.tree.heading(col,text=txt); self.tree.column(col,width=w)
        self.tree.grid(row=1,column=0,sticky="nsew",padx=14,pady=4)
        form=ctk.CTkFrame(self,fg_color=CARD2,corner_radius=8); form.grid(row=2,column=0,fill="x",padx=14,pady=8)
        form.grid_columnconfigure((0,1,2,3),weight=1)
        self._ent_l=ctk.CTkEntry(form,placeholder_text="Login",height=36,width=140)
        self._ent_s=ctk.CTkEntry(form,placeholder_text="Senha",height=36,width=140,show="*")
        self._pv=tk.StringVar(value="operador")
        self._ent_l.grid(row=0,column=0,padx=8,pady=8); self._ent_s.grid(row=0,column=1,padx=4)
        ctk.CTkOptionMenu(form,variable=self._pv,values=["operador","gerente","admin"],width=110,height=36).grid(row=0,column=2,padx=4)
        br=ctk.CTkFrame(form,fg_color="transparent"); br.grid(row=0,column=3,padx=8)
        ctk.CTkButton(br,text="➕ Adicionar",width=110,height=36,fg_color=OK,command=self._add).pack(side="left",padx=2)
        ctk.CTkButton(br,text="🚫 Desativar",width=110,height=36,fg_color=ERR,command=self._desat).pack(side="left",padx=2)
        self._refresh()

    def _refresh(self):
        self.tree.delete(*self.tree.get_children())
        for r in self.db.q("SELECT login,perfil,ativo,criado FROM usuarios ORDER BY login").fetchall():
            self.tree.insert("","end",iid=r[0],values=(r[0],r[1],"✅" if r[2] else "❌",r[3] or "—"))

    def _add(self):
        l=self._ent_l.get().strip(); s=self._ent_s.get().strip(); p=self._pv.get()
        if not l or not s: messagebox.showwarning("Aviso","Preencha login e senha."); return
        try:
            self.db.q("INSERT INTO usuarios(login,senha,perfil,ativo) VALUES(?,?,?,1)",(l,sha256(s),p)); self.db.commit()
            self._ent_l.delete(0,tk.END); self._ent_s.delete(0,tk.END); self._refresh()
        except sqlite3.IntegrityError: messagebox.showwarning("Aviso","Login já existe.")

    def _desat(self):
        sel=self.tree.selection()
        if not sel: return
        if sel[0]=="admin": messagebox.showwarning("Aviso","Não é possível desativar admin."); return
        self.db.q("UPDATE usuarios SET ativo=0 WHERE login=?",(sel[0],)); self.db.commit(); self._refresh()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL CONFIGURAÇÕES
# ══════════════════════════════════════════════════════════════════════════════
class PainelConfiguracoes(ctk.CTkScrollableFrame):
    def __init__(self, master, db, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._status=status_cb; self._build()

    def _build(self):
        ctk.CTkLabel(self,text="⚙  Configurações",font=ctk.CTkFont(size=18,weight="bold"),
                     text_color=TXT).pack(pady=(16,8),padx=20,anchor="w")
        # Dados da empresa
        card=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); card.pack(fill="x",padx=20,pady=8)
        ctk.CTkLabel(card,text="🏢  Dados da Empresa",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        self.ent_cfg={}
        campos=[("empresa_nome","Nome da Empresa"),("empresa_cnpj","CNPJ"),
                ("empresa_ie","Inscrição Estadual"),("empresa_fone","Telefone"),
                ("empresa_endereco","Endereço"),("empresa_cidade","Cidade"),("empresa_uf","UF")]
        for key,ph in campos:
            ctk.CTkLabel(card,text=ph,font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w",padx=14,pady=(4,0))
            e=ctk.CTkEntry(card,placeholder_text=ph,height=36); e.pack(fill="x",padx=14,pady=2)
            e.insert(0,self.db.cfg(key)); self.ent_cfg[key]=e
        ctk.CTkButton(card,text="💾  Salvar Dados da Empresa",height=38,fg_color=ACC,
                      command=self._salvar_empresa).pack(fill="x",padx=14,pady=(4,12))

        # NF-e config
        card_nfe=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); card_nfe.pack(fill="x",padx=20,pady=8)
        ctk.CTkLabel(card_nfe,text="🧾  Configuração NF-e",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        ctk.CTkLabel(card_nfe,text="Ambiente",font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w",padx=14,pady=(4,0))
        self._var_amb=ctk.StringVar(value=self.db.cfg("nfe_ambiente","2"))
        fr_amb=ctk.CTkFrame(card_nfe,fg_color="transparent"); fr_amb.pack(anchor="w",padx=14)
        for txt,val in [("🔸 Homologação (testes)","2"),("🔴 Produção (real)","1")]:
            ctk.CTkRadioButton(fr_amb,text=txt,variable=self._var_amb,value=val,
                               text_color=MUTED,font=ctk.CTkFont(size=11)).pack(side="left",padx=8,pady=6)
        ctk.CTkButton(card_nfe,text="💾  Salvar Config NF-e",height=36,fg_color=CARD2,
                      command=lambda:self.db.set_cfg("nfe_ambiente",self._var_amb.get()) or
                              self._status("✅  Ambiente NF-e salvo.")).pack(fill="x",padx=14,pady=(0,12))

        # Backup
        card2=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); card2.pack(fill="x",padx=20,pady=8)
        ctk.CTkLabel(card2,text="💾  Backup do Banco de Dados",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        ctk.CTkLabel(card2,text="O backup automático é criado diariamente na pasta mecatrack_backups/",
                     text_color=MUTED,font=ctk.CTkFont(size=10)).pack(anchor="w",padx=14)
        ctk.CTkButton(card2,text="📋  Fazer Backup Agora",height=38,fg_color=CARD2,
                      command=self._backup_manual).pack(fill="x",padx=14,pady=(4,12))

        # Demo
        card_demo=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); card_demo.pack(fill="x",padx=20,pady=8)
        ctk.CTkLabel(card_demo,text="🎲  Dados de Demonstração",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        ctk.CTkLabel(card_demo,text="Popula clientes, fornecedores e produtos de exemplo para testes.",
                     text_color=MUTED,font=ctk.CTkFont(size=10)).pack(anchor="w",padx=14)
        ctk.CTkButton(card_demo,text="🎲  Popular Dados de Demo",height=38,fg_color=PURP,
                      command=self._popular_demo).pack(fill="x",padx=14,pady=(4,12))

        # Info versão
        card3=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10); card3.pack(fill="x",padx=20,pady=8)
        ctk.CTkLabel(card3,text="ℹ️  Sobre",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).pack(anchor="w",padx=14,pady=(12,4))
        info=[f"Versão: {APP_VERSION}",f"Banco: {os.path.abspath(DB_FILE)}",
              f"Python: {sys.version.split()[0]}","Libs: customtkinter, sqlite3"]
        if DEPS_FALTANDO: info.append(f"⚠ Faltando: {', '.join(DEPS_FALTANDO)}")
        for txt in info:
            ctk.CTkLabel(card3,text=txt,font=ctk.CTkFont(size=11),text_color=MUTED).pack(anchor="w",padx=14,pady=1)
        ctk.CTkLabel(card3,text="").pack(pady=8)

    def _salvar_empresa(self):
        for key,e in self.ent_cfg.items(): self.db.set_cfg(key,e.get().strip())
        self._status("✅  Dados da empresa salvos.")
        messagebox.showinfo("Salvo","Dados da empresa atualizados.")

    def _popular_demo(self):
        msg=_popular_demo(self.db)
        self._status(f"✅  {msg}")
        messagebox.showinfo("Dados de Demo",msg)

    def _backup_manual(self):
        os.makedirs(BACKUP_DIR,exist_ok=True)
        dest=os.path.join(BACKUP_DIR,f"mecatrack_{agora().replace(':','-').replace(' ','_')}.db")
        if os.path.exists(DB_FILE):
            shutil.copy2(DB_FILE,dest)
            self._status(f"✅  Backup criado: {dest}")
            messagebox.showinfo("Backup criado",f"Salvo em:\n{os.path.abspath(dest)}")
        else:
            messagebox.showwarning("Aviso","Banco de dados não encontrado.")


# ══════════════════════════════════════════════════════════════════════════════
#  DASHBOARD (tela principal do módulo)
# ══════════════════════════════════════════════════════════════════════════════
class PainelDashboard(ctk.CTkScrollableFrame):
    def __init__(self, master, db, status_cb, on_nav, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._status=status_cb; self._on_nav=on_nav
        self._build()

    def _build(self):
        empresa=self.db.cfg("empresa_nome","MecaTrack ERP")
        ctk.CTkLabel(self,text=f"⚙  {empresa}",font=ctk.CTkFont(size=22,weight="bold"),
                     text_color=ACC).pack(pady=(20,4),padx=24,anchor="w")
        ctk.CTkLabel(self,text=f"MecaTrack ERP {APP_VERSION}  ·  {hoje()}",
                     text_color=MUTED,font=ctk.CTkFont(size=12)).pack(padx=24,anchor="w",pady=(0,16))
        self._refresh()

    def _refresh(self):
        # Remove widgets dinâmicos exceto os primeiros 2 (título e subtítulo)
        kids=self.winfo_children()
        for w in kids[2:]: w.destroy()
        est=self.db.estatisticas()
        # Cards métricas
        m=ctk.CTkFrame(self,fg_color="transparent"); m.pack(fill="x",padx=24,pady=4)
        for i in range(4): m.grid_columnconfigure(i,weight=1)
        metricas=[
            ("📦 Peças","Itens cadastrados",str(est["itens"]),ACC),
            ("📊 Unidades","Em estoque",str(est["unidades"]),OK),
            ("⚠️ Alertas",f"Zerados: {est['zerados']}  Baixos: {est['baixos']}",
             str(est["zerados"]+est["baixos"]),WARN),
            ("💰 Vendas Hoje","Total",fmt_brl(est["vendas_hoje"]),CYAN),
        ]
        for i,(icone,titulo,valor,cor) in enumerate(metricas):
            f=ctk.CTkFrame(m,fg_color=CARD,corner_radius=10,border_width=2,border_color=cor)
            f.grid(row=0,column=i,padx=6,pady=4,sticky="ew")
            ctk.CTkLabel(f,text=f"{icone}  {titulo}",font=ctk.CTkFont(size=11),text_color=MUTED).pack(pady=(12,2),padx=14,anchor="w")
            ctk.CTkLabel(f,text=valor,font=ctk.CTkFont(size=22,weight="bold"),text_color=cor).pack(pady=(0,12),padx=14,anchor="w")

        # Peças com alerta
        alertas=self.db.q("SELECT codigo,nome,prateleira,quantidade,qtd_minima FROM pecas WHERE ativo=1 AND (quantidade=0 OR quantidade<=qtd_minima) ORDER BY quantidade LIMIT 8").fetchall()
        if alertas:
            ctk.CTkLabel(self,text="⚠️  Peças que precisam de reposição",font=ctk.CTkFont(size=13,weight="bold"),
                         text_color=WARN).pack(padx=24,pady=(16,4),anchor="w")
            for r in alertas:
                cor=ERR if r[3]==0 else WARN
                f=ctk.CTkFrame(self,fg_color=CARD,corner_radius=8)
                f.pack(fill="x",padx=24,pady=2)
                f.grid_columnconfigure(1,weight=1)
                ctk.CTkLabel(f,text="⛔" if r[3]==0 else "⚠",text_color=cor,font=ctk.CTkFont(size=14)).grid(row=0,column=0,padx=12,pady=8)
                ctk.CTkLabel(f,text=f"{r[1]} — Prat: {r[2] or '?'}",text_color=TXT,font=ctk.CTkFont(size=12),anchor="w").grid(row=0,column=1,sticky="ew",padx=4)
                ctk.CTkLabel(f,text=f"Qtd: {r[3]} / Mín: {r[4]}",text_color=cor,font=ctk.CTkFont(size=11)).grid(row=0,column=2,padx=12)

        # Atalhos rápidos
        ctk.CTkLabel(self,text="🚀  Acesso Rápido",font=ctk.CTkFont(size=13,weight="bold"),
                     text_color=MUTED).pack(padx=24,pady=(20,6),anchor="w")
        atalhos_frame=ctk.CTkFrame(self,fg_color="transparent"); atalhos_frame.pack(fill="x",padx=24,pady=4)
        atalhos=[
            ("🔍 Localizador","localizador",ACC),("🛒 PDV","pdv",OK),
            ("📋 Orçamentos","orcamentos",ACC2),("📦 Compras","compras",PURP),
            ("💰 Financeiro","financeiro",CYAN),("📊 Relatórios","relatorios",WARN),
        ]
        for i,(txt,nav,cor) in enumerate(atalhos):
            ctk.CTkButton(atalhos_frame,text=txt,command=lambda n=nav:self._on_nav(n),
                          fg_color=cor,height=42,corner_radius=8,
                          font=ctk.CTkFont(size=12,weight="bold")).grid(row=i//3,column=i%3,padx=4,pady=4,sticky="ew")
        for i in range(3): atalhos_frame.grid_columnconfigure(i,weight=1)


# ══════════════════════════════════════════════════════════════════════════════
#  APLICAÇÃO PRINCIPAL — NavBar + Módulos
# ══════════════════════════════════════════════════════════════════════════════
class AppMecatrackERP(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1400x820"); self.minsize(1100,680); self.configure(fg_color=BG)
        self.db=Database()
        self._usuario="sistema"; self._perfil="operador"
        self._backup_auto()
        self._modulo_atual=None
        self._paineis={}
        self._build_ui()
        self.after(100, self._mostrar_login)

    def _backup_auto(self):
        def _f():
            os.makedirs(BACKUP_DIR,exist_ok=True)
            dest=os.path.join(BACKUP_DIR,f"mecatrack_{hoje()}.db")
            if not os.path.exists(dest) and os.path.exists(DB_FILE): shutil.copy2(DB_FILE,dest)
            baks=sorted(os.listdir(BACKUP_DIR))
            for b in baks[:-30]: os.remove(os.path.join(BACKUP_DIR,b))
        threading.Thread(target=_f,daemon=True).start()

    def _build_ui(self):
        self.grid_columnconfigure(0,weight=0)  # sidebar nav
        self.grid_columnconfigure(1,weight=1)  # conteúdo principal
        self.grid_rowconfigure(0,weight=1)
        self.grid_rowconfigure(1,weight=0)     # statusbar

        # ── Sidebar de navegação ──────────────────────────────────────────────
        self._nav=ctk.CTkScrollableFrame(self,width=190,fg_color=CARD,corner_radius=0)
        self._nav.grid(row=0,column=0,sticky="nsew")
        self._nav.configure(fg_color=CARD)

        # Logo
        logo_f=ctk.CTkFrame(self._nav,fg_color=CARD2,corner_radius=8)
        logo_f.pack(fill="x",padx=8,pady=(14,8))
        ctk.CTkLabel(logo_f,text="⚙",font=ctk.CTkFont(size=26)).pack(pady=(10,0))
        ctk.CTkLabel(logo_f,text="MecaTrack ERP",font=ctk.CTkFont(size=13,weight="bold"),text_color=ACC).pack(pady=(2,10))

        # Menu de navegação
        self._nav_btns={}
        menu=[
            ("dashboard",   "🏠  Dashboard",   ACC),
            ("localizador", "🔍  Localizador",  ACC),
            ("pdv",         "🛒  PDV / Caixa",  OK),
            ("orcamentos",  "📋  Orçamentos",   ACC2),
            ("pedidos",     "🛍  Pedidos",       ACC2),
            ("compras",     "📦  Compras",       PURP),
            ("financeiro",  "💰  Financeiro",    CYAN),
            ("clientes",    "👤  Clientes",      CYAN),
            ("fornecedores","🏭  Fornecedores",  PINK),
            ("historico",   "🕒  Histórico",     MUTED),
            ("relatorios",  "📊  Relatórios",    WARN),
            ("fiscal",      "🧾  NF-e Fiscal",   WARN),
            ("tabelas",     "💲  Tab. Preço",     OK),
            ("usuarios",    "👥  Usuários",      MUTED),
            ("config",      "⚙  Config",         MUTED),
        ]
        for key,txt,cor in menu:
            btn=ctk.CTkButton(self._nav,text=txt,command=lambda k=key:self._navegar(k),
                              fg_color=CARD2,hover_color=BRD,anchor="w",height=38,
                              border_width=0,font=ctk.CTkFont(size=12))
            btn.pack(fill="x",padx=6,pady=2)
            self._nav_btns[key]=btn

        # ── Área de conteúdo ─────────────────────────────────────────────────
        self._content=ctk.CTkFrame(self,fg_color=BG,corner_radius=0)
        self._content.grid(row=0,column=1,sticky="nsew")
        self._content.grid_columnconfigure(0,weight=1); self._content.grid_rowconfigure(0,weight=1)

        # ── Status bar ───────────────────────────────────────────────────────
        self._bar=ctk.CTkFrame(self,height=34,corner_radius=0,fg_color=CARD,border_width=1,border_color=BRD)
        self._bar.grid(row=1,column=0,columnspan=2,sticky="ew")
        self._bar.grid_columnconfigure(1,weight=1)
        self._status_var=tk.StringVar(value=f"{APP_NAME} {APP_VERSION}  ·  {hoje()}")
        ctk.CTkLabel(self._bar,textvariable=self._status_var,font=ctk.CTkFont(size=10),
                     text_color=MUTED,anchor="e").grid(row=0,column=2,padx=14,sticky="e")
        self._lbl_user=ctk.CTkLabel(self._bar,text="",font=ctk.CTkFont(size=10),text_color=ACC)
        self._lbl_user.grid(row=0,column=0,padx=14,sticky="w")
        if DEPS_FALTANDO:
            ctk.CTkLabel(self._bar,text=f"⚠ pip install {' '.join(DEPS_FALTANDO)}",
                         font=ctk.CTkFont(size=10),text_color=WARN).grid(row=0,column=1,padx=8)

        # Forçar repintura Windows
        self.after(60, self._forcar_cores)

    def _forcar_cores(self):
        self.configure(fg_color=BG)
        for w in self.winfo_children():
            try:
                if "Frame" in w.__class__.__name__: w.configure(fg_color=w.cget("fg_color"))
            except: pass
        self.update_idletasks()

    def _mostrar_login(self):
        TelaLogin(self.db, self._pos_login)

    def _pos_login(self, usuario, perfil):
        self._usuario=usuario; self._perfil=perfil
        self._lbl_user.configure(text=f"👤  {usuario}  ({perfil})")
        self._status_var.set(f"{APP_NAME} {APP_VERSION}  ·  {hoje()}  ·  {usuario}")
        self._navegar("dashboard")

    def _navegar(self, modulo: str):
        if self._modulo_atual==modulo: return

        # Atualiza visual dos botões
        for k,b in self._nav_btns.items():
            b.configure(fg_color=(BRD if k==modulo else CARD2))

        # Remove painel atual
        for w in self._content.winfo_children(): w.grid_forget()

        # Cria ou recupera o painel
        if modulo not in self._paineis:
            self._paineis[modulo]=self._criar_painel(modulo)

        painel=self._paineis[modulo]
        if painel:
            painel.grid(row=0,column=0,sticky="nsew")
            # Atualiza dados ao entrar no módulo
            try: painel.atualizar() if hasattr(painel,"atualizar") else None
            except: pass

        self._modulo_atual=modulo

    def _criar_painel(self, modulo: str):
        kw={"master":self._content}
        if modulo=="dashboard":
            return PainelDashboard(self._content,self.db,self._set_status,self._navegar)
        elif modulo=="localizador":
            # Painel composto: prateleiras + localizador + edição
            f=ctk.CTkFrame(self._content,fg_color=BG); f.grid_columnconfigure(1,weight=1); f.grid_rowconfigure(0,weight=1)
            pp=PainelPrateleiras(f,self.db,on_filtro=lambda n:pl.set_filtro_prateleira(n))
            pp.grid(row=0,column=0,sticky="nsew")
            pl=PainelLocalizador(f,self.db,on_selecionar=lambda d:pe.carregar(d),status_cb=self._set_status)
            pl.grid(row=0,column=1,sticky="nsew")
            pe=PainelEdicao(f,self.db,status_cb=self._set_status,refresh_cb=lambda:[pl.atualizar(),pp.atualizar()])
            pe.grid(row=0,column=2,sticky="nsew")
            # Adiciona método atualizar ao frame composto
            f.atualizar=lambda:pl.atualizar() or pp.atualizar()
            return f
        elif modulo=="pdv":
            return PainelPDV(self._content,self.db,self._usuario,self._set_status,self._refresh_global)
        elif modulo=="orcamentos":
            return PainelDocumentos(self._content,self.db,"orcamento",self._set_status,self._refresh_global)
        elif modulo=="pedidos":
            return PainelDocumentos(self._content,self.db,"pedido",self._set_status,self._refresh_global)
        elif modulo=="compras":
            return PainelCompras(self._content,self.db,self._usuario,self._set_status,self._refresh_global)
        elif modulo=="financeiro":
            return PainelFinanceiro(self._content,self.db,self._set_status)
        elif modulo=="clientes":
            return PainelCadastro(self._content,self.db,"cliente",self._set_status)
        elif modulo=="fornecedores":
            return PainelCadastro(self._content,self.db,"fornecedor",self._set_status)
        elif modulo=="historico":
            return PainelHistorico(self._content,self.db)
        elif modulo=="relatorios":
            return PainelRelatorios(self._content,self.db,self._set_status)
        elif modulo=="usuarios":
            return PainelUsuarios(self._content,self.db)
        elif modulo=="config":
            return PainelConfiguracoes(self._content,self.db,self._set_status)
        elif modulo=="fiscal":
            return PainelFiscal(self._content,self.db,self._usuario,self._set_status)
        elif modulo=="tabelas":
            return PainelTabelasPreco(self._content,self.db,self._set_status)
        return None

    def _set_status(self, msg): self._status_var.set(msg)

    def _refresh_global(self):
        """Invalida painéis que dependem de estoque/pedidos."""
        for mod in ["dashboard","localizador"]:
            if mod in self._paineis:
                try:
                    p=self._paineis[mod]
                    if hasattr(p,"atualizar"): p.atualizar()
                except: pass

    def on_closing(self):
        self.db.close(); self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL FISCAL — NF-e Simulada
# ══════════════════════════════════════════════════════════════════════════════
class PainelFiscal(ctk.CTkFrame):
    def __init__(self, master, db, usuario, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._usuario=usuario; self._status=status_cb
        self.grid_rowconfigure(1,weight=1); self.grid_columnconfigure(0,weight=1)
        self._build()

    def _build(self):
        # Topo
        topo=ctk.CTkFrame(self,fg_color=CARD,corner_radius=0,height=56)
        topo.grid(row=0,column=0,sticky="ew"); topo.grid_propagate(False)
        ctk.CTkLabel(topo,text="🧾  Notas Fiscais (NF-e Simulado)",
                     font=ctk.CTkFont(size=16,weight="bold"),text_color=TXT).pack(side="left",padx=16,pady=14)
        amb=self.db.cfg("nfe_ambiente","2")
        cor_amb=WARN if amb=="2" else ERR
        ctk.CTkLabel(topo,text="🔸 HOMOLOGAÇÃO" if amb=="2" else "🔴 PRODUÇÃO",
                     text_color=cor_amb,font=ctk.CTkFont(size=11,weight="bold")).pack(side="left",padx=8,pady=14)
        ctk.CTkButton(topo,text="+ Nova NF-e",fg_color=OK,height=34,width=120,
                      command=self._nova_nfe).pack(side="right",padx=16,pady=11)

        # Filtro
        filt=ctk.CTkFrame(self,fg_color=CARD2,corner_radius=0,height=46)
        filt.grid(row=1,column=0,sticky="ew"); filt.grid_propagate(False)
        self._var_status=ctk.StringVar(value="Todos")
        for s in ["Todos","rascunho","autorizada","cancelada"]:
            rb=ctk.CTkRadioButton(filt,text=s.capitalize(),variable=self._var_status,
                                  value=s,command=self.atualizar,text_color=MUTED,
                                  font=ctk.CTkFont(size=11))
            rb.pack(side="left",padx=10,pady=13)

        # Tabela
        cont=ctk.CTkFrame(self,fg_color=BG); cont.grid(row=2,column=0,sticky="nsew",padx=12,pady=8)
        self.grid_rowconfigure(2,weight=1); cont.grid_rowconfigure(0,weight=1); cont.grid_columnconfigure(0,weight=1)
        cols=("numero","cliente_nome","valor_total","status","criado")
        self._tree=ttk.Treeview(cont,columns=cols,show="headings",style="M.Treeview",selectmode="browse")
        hdrs={"numero":"Nº NF-e","cliente_nome":"Cliente","valor_total":"Valor","status":"Status","criado":"Emitida em"}
        wids={"numero":80,"cliente_nome":220,"valor_total":100,"status":90,"criado":140}
        for c in cols:
            self._tree.heading(c,text=hdrs[c]); self._tree.column(c,width=wids[c],minwidth=60)
        sb=ttk.Scrollbar(cont,orient="vertical",command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.grid(row=0,column=0,sticky="nsew"); sb.grid(row=0,column=1,sticky="ns")
        self._tree.bind("<Double-1>",self._abrir_nfe)

        # Botões ação
        btn_fr=ctk.CTkFrame(self,fg_color=CARD,corner_radius=0,height=52)
        btn_fr.grid(row=3,column=0,sticky="ew"); btn_fr.grid_propagate(False)
        for txt,cmd,cor in [("✅ Autorizar (Simular)",self._autorizar,OK),
                             ("❌ Cancelar",self._cancelar,ERR),
                             ("🖨️ Imprimir DANFe",self._imprimir,ACC)]:
            ctk.CTkButton(btn_fr,text=txt,command=cmd,fg_color=cor,height=36,width=180).pack(side="left",padx=8,pady=8)
        self.atualizar()

    def atualizar(self):
        self._tree.delete(*self._tree.get_children())
        st=self._var_status.get()
        where="" if st=="Todos" else f" WHERE status='{st}'"
        rows=self.db.q(f"SELECT numero,cliente_nome,valor_total,status,criado FROM nfe{where} ORDER BY id DESC LIMIT 200").fetchall()
        for r in rows:
            tag={"rascunho":"warn","autorizada":"ok","cancelada":"err"}.get(r[3],"")
            self._tree.insert("","end",values=(r[0],r[1],fmt_brl(r[2]),r[3].upper(),r[4]),tags=(tag,))
        self._tree.tag_configure("ok",foreground=OK)
        self._tree.tag_configure("warn",foreground=WARN)
        self._tree.tag_configure("err",foreground=ERR)

    def _sel(self):
        sel=self._tree.selection()
        if not sel: messagebox.showwarning("Aviso","Selecione uma NF-e."); return None
        return self._tree.item(sel[0])["values"][0]

    def _nova_nfe(self):
        JanelaNFe(self,self.db,self._usuario,callback=self.atualizar)

    def _abrir_nfe(self,evt):
        num=self._sel()
        if num:
            r=self.db.q("SELECT * FROM nfe WHERE numero=?",(num,)).fetchone()
            if r: JanelaNFe(self,self.db,self._usuario,dados=dict(r),callback=self.atualizar)

    def _autorizar(self):
        num=self._sel()
        if not num: return
        r=self.db.q("SELECT status FROM nfe WHERE numero=?",(num,)).fetchone()
        if r and r[0]=="rascunho":
            import random,string
            chave="3524"+num.replace("NFe","")+"".join(random.choices(string.digits,k=30))
            self.db.q("UPDATE nfe SET status='autorizada',chave=? WHERE numero=?",(chave,num))
            self.db.conn.commit()
            auditar(self._usuario,"NF-e AUTORIZADA",num)
            self._status(f"✅  NF-e {num} autorizada (simulação). Chave: {chave[:20]}…")
            self.atualizar()
        else:
            messagebox.showwarning("Aviso","Somente rascunhos podem ser autorizados.")

    def _cancelar(self):
        num=self._sel()
        if not num: return
        r=self.db.q("SELECT status FROM nfe WHERE numero=?",(num,)).fetchone()
        if r and r[0]=="autorizada":
            if messagebox.askyesno("Cancelar NF-e",f"Cancelar NF-e {num}?"):
                self.db.q("UPDATE nfe SET status='cancelada' WHERE numero=?",(num,))
                self.db.conn.commit()
                auditar(self._usuario,"NF-e CANCELADA",num)
                self._status(f"✅  NF-e {num} cancelada.")
                self.atualizar()
        else:
            messagebox.showwarning("Aviso","Somente NF-es autorizadas podem ser canceladas.")

    def _imprimir(self):
        num=self._sel()
        if not num: return
        r=self.db.q("SELECT * FROM nfe WHERE numero=?",(num,)).fetchone()
        if not r: return
        r=dict(r)
        empresa=self.db.cfg("empresa_nome","Empresa")
        txt=f"""
╔══════════════════════════════════════════════╗
║              DANFE SIMPLIFICADO               ║
╚══════════════════════════════════════════════╝
  NF-e: {r['numero']}    Série: {r['serie']}
  Ambiente: {'HOMOLOGAÇÃO - SEM VALOR FISCAL' if r['ambiente']=='2' else 'PRODUÇÃO'}
  Emitente: {empresa}
  Destinatário: {r['cliente_nome']}
  Pedido origem: {r['pedido_ref'] or '—'}
  Valor Total: {fmt_brl(r['valor_total'])}
  Status: {r['status'].upper()}
  Chave: {r['chave'] or 'Não autorizada'}
  Emitida: {r['criado']}
  Observações: {r['observacoes'] or '—'}

  {'⚠ ESTE DOCUMENTO NÃO TEM VALOR FISCAL' if r['ambiente']=='2' else ''}
"""
        top=ctk.CTkToplevel(self); top.title(f"DANFe — {num}"); top.geometry("560x380")
        top.configure(fg_color=BG)
        ctk.CTkLabel(top,text="📄  DANFe (Simulado)",font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(12,4))
        txt_w=ctk.CTkTextbox(top,fg_color=CARD,text_color=TXT,font=("Consolas",11)); txt_w.pack(fill="both",expand=True,padx=12,pady=4)
        txt_w.insert("1.0",txt); txt_w.configure(state="disabled")
        ctk.CTkButton(top,text="Fechar",command=top.destroy,fg_color=CARD2).pack(pady=8)


class JanelaNFe(ctk.CTkToplevel):
    def __init__(self, master, db, usuario, dados=None, callback=None, **kw):
        super().__init__(master, **kw)
        self.db=db; self._usuario=usuario; self._dados=dados or {}; self._cb=callback
        self.title("Nova NF-e" if not dados else f"NF-e {dados.get('numero','')}"); self.geometry("560x500")
        self.configure(fg_color=BG); self.grab_set(); self._build()

    def _build(self):
        ctk.CTkLabel(self,text="🧾  Emitir NF-e (Simulado)",font=ctk.CTkFont(size=14,weight="bold"),text_color=TXT).pack(pady=(14,4))
        f=ctk.CTkScrollableFrame(self,fg_color=CARD,corner_radius=10); f.pack(fill="both",expand=True,padx=14,pady=8)
        self._ent={}
        campos=[("cliente_nome","Cliente / Destinatário"),("pedido_ref","Pedido de Origem"),
                ("valor_total","Valor Total (R$)"),("serie","Série NF"),("observacoes","Observações")]
        for key,ph in campos:
            ctk.CTkLabel(f,text=ph,font=ctk.CTkFont(size=10),text_color=MUTED).pack(anchor="w",padx=12,pady=(6,0))
            e=ctk.CTkEntry(f,placeholder_text=ph,height=36); e.pack(fill="x",padx=12,pady=2)
            e.insert(0,str(self._dados.get(key,"") or "")); self._ent[key]=e

        # Preencher pedido automaticamente
        if not self._dados:
            self.ent_ped=self._ent["pedido_ref"]
            self._ent["serie"].delete(0,"end"); self._ent["serie"].insert(0,"1")

        ctk.CTkButton(self,text="💾  Salvar NF-e",fg_color=OK,height=40,command=self._salvar).pack(fill="x",padx=14,pady=6)
        ctk.CTkButton(self,text="Fechar",fg_color=CARD2,height=36,command=self.destroy).pack(fill="x",padx=14,pady=(0,12))

    def _salvar(self):
        cliente=self._ent["cliente_nome"].get().strip()
        if not cliente: messagebox.showwarning("Aviso","Informe o destinatário.",parent=self); return
        valor=parse_float(self._ent["valor_total"].get())
        pedido=self._ent["pedido_ref"].get().strip()
        serie=self._ent["serie"].get().strip() or "1"
        obs=self._ent["observacoes"].get().strip()
        amb=self.db.cfg("nfe_ambiente","2")
        if self._dados.get("id"):
            self.db.q("UPDATE nfe SET cliente_nome=?,pedido_ref=?,valor_total=?,serie=?,observacoes=? WHERE id=?",
                      (cliente,pedido,valor,serie,obs,self._dados["id"]))
        else:
            num=f"NFe{int(self.db.cfg('prox_nfe','1')):06d}"
            self.db.set_cfg("prox_nfe",str(int(self.db.cfg("prox_nfe","1"))+1))
            self.db.q("INSERT INTO nfe(numero,serie,pedido_ref,cliente_nome,valor_total,ambiente,observacoes,usuario) VALUES(?,?,?,?,?,?,?,?)",
                      (num,serie,pedido,cliente,valor,amb,obs,self._usuario))
        self.db.conn.commit()
        auditar(self._usuario,"NF-e CRIADA",cliente)
        if self._cb: self._cb()
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════
#  PAINEL TABELAS & CONDIÇÕES
# ══════════════════════════════════════════════════════════════════════════════
class PainelTabelasPreco(ctk.CTkFrame):
    """Gerencia tabelas de preço e condições de pagamento."""
    def __init__(self, master, db, status_cb, **kw):
        super().__init__(master, fg_color=BG, **kw)
        self.db=db; self._status=status_cb
        self.grid_rowconfigure(0,weight=1); self.grid_columnconfigure(0,weight=1)
        self.grid_columnconfigure(1,weight=1); self._build()

    def _build(self):
        # Tabelas de preço
        col_tab=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10)
        col_tab.grid(row=0,column=0,sticky="nsew",padx=(12,6),pady=12)
        col_tab.grid_rowconfigure(2,weight=1)
        ctk.CTkLabel(col_tab,text="💲  Tabelas de Preço",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).grid(row=0,column=0,columnspan=2,padx=14,pady=(14,6),sticky="w")

        self._tree_tab=ttk.Treeview(col_tab,columns=("nome","desconto"),show="headings",style="M.Treeview",height=8)
        self._tree_tab.heading("nome",text="Nome"); self._tree_tab.heading("desconto",text="Desconto %")
        self._tree_tab.column("nome",width=160); self._tree_tab.column("desconto",width=90)
        self._tree_tab.grid(row=2,column=0,columnspan=2,sticky="nsew",padx=12,pady=4)

        ctk.CTkButton(col_tab,text="+ Adicionar",fg_color=OK,height=34,command=self._add_tab).grid(row=3,column=0,padx=8,pady=8,sticky="ew")
        ctk.CTkButton(col_tab,text="🗑 Excluir",fg_color=ERR,height=34,command=self._del_tab).grid(row=3,column=1,padx=8,pady=8,sticky="ew")

        # Condições de pagamento
        col_cond=ctk.CTkFrame(self,fg_color=CARD,corner_radius=10)
        col_cond.grid(row=0,column=1,sticky="nsew",padx=(6,12),pady=12)
        col_cond.grid_rowconfigure(2,weight=1)
        ctk.CTkLabel(col_cond,text="💳  Condições de Pagamento",font=ctk.CTkFont(size=13,weight="bold"),text_color=TXT).grid(row=0,column=0,columnspan=2,padx=14,pady=(14,6),sticky="w")

        self._tree_cond=ttk.Treeview(col_cond,columns=("nome","parcelas","intervalo","desc_avista"),show="headings",style="M.Treeview",height=8)
        for c,t,w in [("nome","Condição",150),("parcelas","Parc.",55),("intervalo","Intervalo(d)",90),("desc_avista","Desc.%",65)]:
            self._tree_cond.heading(c,text=t); self._tree_cond.column(c,width=w)
        self._tree_cond.grid(row=2,column=0,columnspan=2,sticky="nsew",padx=12,pady=4)

        ctk.CTkButton(col_cond,text="+ Adicionar",fg_color=OK,height=34,command=self._add_cond).grid(row=3,column=0,padx=8,pady=8,sticky="ew")
        ctk.CTkButton(col_cond,text="🗑 Excluir",fg_color=ERR,height=34,command=self._del_cond).grid(row=3,column=1,padx=8,pady=8,sticky="ew")

        self.atualizar()

    def atualizar(self):
        self._tree_tab.delete(*self._tree_tab.get_children())
        for r in self.db.q("SELECT nome,desconto_percentual FROM tabelas_preco WHERE ativo=1 ORDER BY nome").fetchall():
            self._tree_tab.insert("","end",values=(r[0],f"{r[1]:.1f}%"))
        self._tree_cond.delete(*self._tree_cond.get_children())
        for r in self.db.q("SELECT nome,parcelas,intervalo_dias,desconto_avista FROM condicoes_pagamento WHERE ativo=1 ORDER BY parcelas").fetchall():
            self._tree_cond.insert("","end",values=(r[0],r[1],f"{r[2]}d",f"{r[3]:.1f}%"))

    def _add_tab(self):
        top=ctk.CTkToplevel(self); top.title("Nova Tabela de Preço"); top.geometry("340x200"); top.configure(fg_color=BG); top.grab_set()
        ctk.CTkLabel(top,text="Nome da tabela",text_color=MUTED,font=ctk.CTkFont(size=10)).pack(anchor="w",padx=16,pady=(16,0))
        en=ctk.CTkEntry(top,placeholder_text="Ex: Revenda",height=38); en.pack(fill="x",padx=16,pady=4)
        ctk.CTkLabel(top,text="Desconto (%)",text_color=MUTED,font=ctk.CTkFont(size=10)).pack(anchor="w",padx=16,pady=(8,0))
        ed=ctk.CTkEntry(top,placeholder_text="0.0",height=38); ed.pack(fill="x",padx=16,pady=4)
        def _salvar():
            nome=en.get().strip(); desc=parse_float(ed.get())
            if nome:
                try: self.db.q("INSERT INTO tabelas_preco(nome,desconto_percentual) VALUES(?,?)",(nome,desc)); self.db.conn.commit()
                except: messagebox.showwarning("Aviso","Já existe uma tabela com esse nome.",parent=top)
                self.atualizar(); top.destroy()
        ctk.CTkButton(top,text="Salvar",fg_color=OK,height=38,command=_salvar).pack(fill="x",padx=16,pady=10)

    def _del_tab(self):
        sel=self._tree_tab.selection()
        if not sel: return
        nome=self._tree_tab.item(sel[0])["values"][0]
        if nome in ("Varejo","Atacado","VIP"): messagebox.showwarning("Aviso","Tabela padrão não pode ser excluída."); return
        self.db.q("UPDATE tabelas_preco SET ativo=0 WHERE nome=?",(nome,)); self.db.conn.commit(); self.atualizar()

    def _add_cond(self):
        top=ctk.CTkToplevel(self); top.title("Nova Condição"); top.geometry("340x280"); top.configure(fg_color=BG); top.grab_set()
        ents={}
        for key,ph in [("nome","Ex: 60 dias"),("parcelas","1"),("intervalo","60"),("desconto","0.0")]:
            ctk.CTkLabel(top,text=ph,text_color=MUTED,font=ctk.CTkFont(size=10)).pack(anchor="w",padx=16,pady=(8,0))
            e=ctk.CTkEntry(top,placeholder_text=ph,height=36); e.pack(fill="x",padx=16,pady=2); ents[key]=e
        def _salvar():
            nome=ents["nome"].get().strip()
            if nome:
                try:
                    self.db.q("INSERT INTO condicoes_pagamento(nome,parcelas,intervalo_dias,desconto_avista) VALUES(?,?,?,?)",
                              (nome,parse_int(ents["parcelas"].get()),parse_int(ents["intervalo"].get()),parse_float(ents["desconto"].get())))
                    self.db.conn.commit()
                except: messagebox.showwarning("Aviso","Já existe essa condição.",parent=top)
                self.atualizar(); top.destroy()
        ctk.CTkButton(top,text="Salvar",fg_color=OK,height=38,command=_salvar).pack(fill="x",padx=16,pady=10)

    def _del_cond(self):
        sel=self._tree_cond.selection()
        if not sel: return
        nome=self._tree_cond.item(sel[0])["values"][0]
        self.db.q("UPDATE condicoes_pagamento SET ativo=0 WHERE nome=?",(nome,)); self.db.conn.commit(); self.atualizar()


# ══════════════════════════════════════════════════════════════════════════════
#  SETUP INICIAL — Popula dados de demonstração
# ══════════════════════════════════════════════════════════════════════════════
def _popular_demo(db: "Database") -> str:
    """Insere dados de exemplo no banco local. Idempotente (OR IGNORE)."""
    msgs=[]

    # Clientes
    clientes=[
        ("PJ","Auto Mecânica Rodrigues Ltda","Mecânica Rodrigues","12.345.678/0001-99","(51) 3333-1111","contato@mecanicarodrigues.com.br","Porto Alegre","RS","Varejo",5000.0),
        ("PJ","Garage do Carlos Ltda","","98.765.432/0001-11","(51) 3333-2222","","Porto Alegre","RS","Atacado",10000.0),
        ("PJ","Oficina Sul Serviços","Oficina Sul","55.432.100/0001-87","(51) 3333-3333","","Porto Alegre","RS","Varejo",8000.0),
        ("PF","Carlos Alberto Mendes","","123.456.789-00","(51) 99000-1111","carlos@email.com","Porto Alegre","RS","Varejo",0.0),
    ]
    n_cli=0
    for tp,nome,nf,doc,tel,email,cid,uf,tab,lim in clientes:
        r=db.q("SELECT id FROM clientes WHERE cpf_cnpj=?",(doc,)).fetchone()
        if not r:
            db.q("INSERT INTO clientes(tipo,nome,nome_fantasia,cpf_cnpj,telefone,email,cidade,uf,tabela_preco,limite_credito) VALUES(?,?,?,?,?,?,?,?,?,?)",
                 (tp,nome,nf,doc,tel,email,cid,uf,tab,lim))
            n_cli+=1
    db.conn.commit()
    if n_cli: msgs.append(f"✓ {n_cli} clientes de demo criados")

    # Fornecedores
    fornecs=[
        ("Mann Filter Brasil Ltda","Mann Filter","01.234.567/0001-01","Roberto Alves","(11) 3333-4444","vendas@mann.com.br","São Paulo","SP",7,"30 dias"),
        ("Robert Bosch Ltda","Bosch","59.104.422/0001-50","Ana Paula Souza","(11) 4444-5555","autoparts@bosch.com.br","São Paulo","SP",10,"30 dias"),
        ("Gates Distribuidora de Peças Ltda","Gates","03.456.789/0001-03","Paulo Mendes","(11) 5555-6666","","São Paulo","SP",5,"30 dias"),
        ("Monroe Sul Amortecedores Ltda","Monroe Sul","04.567.890/0001-04","Carlos Lima","(51) 3333-7777","","Porto Alegre","RS",14,"30/60 dias"),
    ]
    n_for=0
    for razao,fantasia,cnpj,rep,tel,email,cid,uf,prazo,cond in fornecs:
        if not db.q("SELECT id FROM fornecedores WHERE cnpj=?",(cnpj,)).fetchone():
            db.q("INSERT INTO fornecedores(razao_social,nome_fantasia,cnpj,representante,telefone,email,cidade,uf,prazo_entrega,cond_pagamento) VALUES(?,?,?,?,?,?,?,?,?,?)",
                 (razao,fantasia,cnpj,rep,tel,email,cid,uf,prazo,cond))
            n_for+=1
    db.conn.commit()
    if n_for: msgs.append(f"✓ {n_for} fornecedores de demo criados")

    # Produtos de exemplo
    prods=[
        ("0034-FO","Filtro de Óleo Mann W712/75","A1-01","A1","01","1",2,10,47.80,18.00,"Mann Filter","Mann","W712/75","Filtros","84212300","UN"),
        ("0035-FA","Filtro de Ar WIX WA6720","A1-02","A1","01","2",18,8,55.00,22.00,"Mann Filter","WIX","WA6720","Filtros","84213100","UN"),
        ("0036-FC","Filtro Combustível Mahle KL147","A1-03","A1","01","3",12,8,38.50,15.00,"Gates","Mahle","KL147","Filtros","84212300","UN"),
        ("0128-PF","Pastilha Freio Dianteira Bosch","B2-01","B2","02","1",5,8,89.90,42.00,"Robert Bosch Ltda","Bosch","BP1140","Freios","68138110","PC"),
        ("0129-PT","Pastilha Freio Traseira Bosch","B2-02","B2","02","2",8,6,74.90,35.00,"Robert Bosch Ltda","Bosch","BP880","Freios","68138110","PC"),
        ("0055-VI","Vela Ignição NGK BKR6E (kit 4)","C3-01","C3","03","1",24,10,124.00,58.00,"Robert Bosch Ltda","NGK","BKR6E","Elétrica","85112000","KT"),
        ("0056-CB","Cabo de Vela Bosch 0986356304","C3-02","C3","03","2",9,5,138.00,65.00,"Robert Bosch Ltda","Bosch","0986356304","Elétrica","85449000","KT"),
        ("0089-AM","Amortecedor Dianteiro Monroe Gas-Magnum","D4-01","D4","04","1",0,4,389.00,180.00,"Monroe Sul Amortecedores Ltda","Monroe","G8097","Suspensão","87088000","UN"),
        ("0210-CD","Correia Dentada Gates K015487XS","E5-01","E5","05","1",1,5,140.00,55.00,"Gates","Gates","K015487XS","Motor","40103900","UN"),
        ("0211-JV","Junta de Cabeçote Mahle MLS","E5-02","E5","05","2",6,3,210.00,95.00,"Gates","Mahle","JC330","Motor","84841000","UN"),
    ]
    n_prd=0
    for dados in prods:
        if not db.q("SELECT codigo FROM pecas WHERE codigo=?",(dados[0],)).fetchone():
            db.q("""INSERT INTO pecas(codigo,nome,localizacao,prateleira,setor,posicao,quantidade,qtd_minima,
                     preco_venda,preco_custo,fornecedor,marca,cod_fabricante,categoria,ncm,unidade)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", dados)
            n_prd+=1
    db.conn.commit()
    if n_prd: msgs.append(f"✓ {n_prd} produtos de demo criados")

    return "\n".join(msgs) if msgs else "Dados de demonstração já existentes."


# ── Estilos ttk ─────────────────────────────────────────────────────────────
def _aplicar_estilo():
    style=ttk.Style(); style.theme_use("default")
    style.configure("M.Treeview",background=CARD,foreground=TXT,fieldbackground=CARD,rowheight=28,font=("Consolas",10))
    style.configure("M.Treeview.Heading",background=CARD2,foreground="#94a3b8",font=("Consolas",10,"bold"),relief="flat")
    style.map("M.Treeview",background=[("selected","#1e3a5f")],foreground=[("selected","white")])


# ── Entry-point ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    _aplicar_estilo()
    app=AppMecatrackERP()
    app.protocol("WM_DELETE_WINDOW",app.on_closing)
    app.mainloop()
